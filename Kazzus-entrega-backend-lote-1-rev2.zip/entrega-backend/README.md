# Entrega backend Kazzus CRM - modulos kz (Lote 1)

Data: 16/11/2026 (America/Fortaleza). Contrato: Kazzus-prompt-backend-outra-IA.md
(commit 56f3aca). Nada foi aplicado na arvore real: sem commit, sem push, sem
editar arquivo existente.

**Revisao 2 (17/11/2026):** rodada de revisao externa (50 achados de outra IA sobre
as migracoes e a documentacao). Aplicadas as correcoes procedentes (grants
apendice-only em recibos/outbox/auditoria/tentativas com gatilhos de imutabilidade,
CHECKs de coerencia nas 8 migracoes, guardas de foto/checklist de OS, unit_ref
obrigatorio na aprovacao de usado, acoplamento order_kind/order_id no crediario,
formato fechado de storage_ref, indice redundante de taxas removido) e rebatidos
com evidencia os achados ja garantidos por servico/zod. Suite revalidada: 111
testes/111 pass, tsc 0 erros. Detalhe por achado no RELATORIO.md (Revisao 2).

## Conteudo

- `fase-0/mapa.md` - inventario e decisoes das 30 entregas P1 (Fase 0 do contrato),
  com as duvidas D1 a D15 consolidadas.
- `fase-1/arquivos-novos/` - 59 arquivos para copiar na arvore real: 2
  compartilhados (kz-common, kz-flags), 7 modulos de dominio (caixa, taxas, os,
  usados, pagamento-misto, crediario, seguranca), 8 migracoes (094..101) e os
  testes node:test com helpers. Hashes em `arquivos-novos/MANIFEST.sha256`
  (`sha256sum -c MANIFEST.sha256`).
- `fase-1/ligacao.patch` - as UNICAS alteracoes em arquivos existentes (secao 2.11
  do contrato): registro das migracoes em src/database-migrations.ts e
  controllers/providers em src/app.ts. main.ts fica para a Fase 2.
- `fase-1/RELATORIO.md` - o que foi entregue, evidencias de validacao (111 testes
  OK, tsc limpo, RLS provada com papel crm_app), desvios justificados, a Revisao 2
  ponto a ponto e o que nao pode ser validado fora da arvore real.
- `fase-1/rotas-para-o-proxy-v21.md` - as 50 rotas kz para o serve-v21.py repassar
  (sem edita-lo).
- `fase-1/validador-local/` - ambiente reproduzivel que valida tudo fora da arvore
  real: `npm install && npm test && npm run check` (111 testes, tsc sem erros).
  Arquivos proprios do validador sao claramente marcados (nao copiar).

## Notas operacionais da Revisao 2

- Recibos de idempotencia, outbox kz, auditoria kz e tentativas de PIN sao
  APENDICE-ONLY: o papel crm_app so tem SELECT/INSERT nelas, e gatilhos bloqueiam
  UPDATE/DELETE ate para o owner da base. A deteccao de adulteracao da trilha
  continua valendo (kzVerifyAuditChain) e tem teste proprio.
- Nenhuma tabela kz tem ON DELETE CASCADE nem DELETE concedido: limpeza de
  workspace de teste e manual, das folhas para a raiz (payments_splits -> sets,
  checklists/parts/photos -> orders, installments -> plans, terms -> evaluations),
  ou por archived_at. Em producao nada precisa ser apagado: arquiva-se.

## Ordem de leitura sugerida

1. RELATORIO.md (visao geral, evidencias e a Revisao 2)
2. fase-0/mapa.md (decisoes por item)
3. ligacao.patch (o que toca arquivo existente)
4. rotas-para-o-proxy-v21.md (integracao com o front)

## Como rodar o validador

```bash
cd fase-1/validador-local
npm install
npm test        # 111 testes (modulos + guardas de banco + contrato estatico + RLS + owner + fumaca HTTP)
npm run check   # tsc --noEmit sem erros
```
