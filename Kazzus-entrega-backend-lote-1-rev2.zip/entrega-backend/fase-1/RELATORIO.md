# RELATORIO - Lote 1 dos modulos kz (backend de funcoes novas do Kazzus CRM)

**Data:** 16/11/2026 (America/Fortaleza, UTC-3). **Revisao 1:** 17/11/2026 - correcao
de teste dependente de data no kz-crediario (helper `dataISO` agora usa o dia de
calendario em America/Fortaleza, a mesma referencia do servico; antes, o calculo em
UTC quebrava a cobranca de "parcela atrasada" na janela 21h-24h local). **Revisao 2:**
17/11/2026 - rodada de REVISAO EXTERNA (outra IA, 50 achados sobre migracoes e
documentacao; ver secao 9): grants apendice-only + gatilhos de imutabilidade,
CHECKs de coerencia, guardas de OS e defesas em profundidade; suite 111/111 e tsc
0 erros revalidados apos as mudancas. **Base do contrato:** commit 56f3aca.
**Escopo:** Fase 0 (mapa em `../fase-0/mapa.md`) + Lote 1 da Fase 1: infraestrutura
kz (migracao 094) e 8 das 15 funcoes P1, em 7 modulos de dominio (itens 1, 2, 3, 4,
5, 6, 8 e 14 da tabela do contrato). Nada foi aplicado na arvore real: sem commit,
sem push, sem tocar em arquivo existente.

---

## 1. Resumo da validacao (evidencia real, rodada neste ambiente)

| Verificacao | Resultado |
|---|---|
| `npm test` (tsx --test, PGlite em memoria) | **111 testes / 111 pass / 0 falha** (inclui 9 testes de guardas de banco e 2 de gatilhos no nivel owner, ambos da Revisao 2) |
| `npm run check` (tsc --noEmit, strict + noUnusedLocals + verbatimModuleSyntax) | **0 erros** |
| Smoke HTTP com app NestJS 11 de pe (middleware demo + filtro de erros) | 4/4 testes OK (MODULE_DISABLED, ciclo do caixa, mapa de erros 401/403/404/409/422, RLS entre lojas por HTTP) |
| RLS provada com papel `crm_app` (nao so filtro de servico) | OK: sem `app.workspace_id` o SELECT devolve 0 linhas; loja B nao ve a loja A; `DELETE` negado (42501) |
| Catalogo do banco | 24 tabelas kz, todas com `ENABLE`+`FORCE ROW LEVEL SECURITY`, policy `workspace_scope` e `GRANT SELECT, INSERT` (+ `UPDATE` so nas mutaveis); recibos, outbox, auditoria e tentativas de PIN APENDICE-ONLY (Revisao 2) |
| Imutabilidade no nivel owner (Revisao 2) | OK: UPDATE/DELETE nas 4 tabelas apendice-only derrubam ate para o superuser (gatilhos kz_*_imutavel) |
| Migracao ausente/parcial | `KZ_MIGRATION_REQUIRED` 503 (base sem as kz) e `KZ_CAIXA_MIGRATION_REQUIRED` 503 (base so ate 094) |
| Guardas estaticos de contrato (testes `kz-contract.test.ts`) | 11/11 OK: nenhum INSERT/UPDATE fora de `crm.kz_*`, nenhuma chamada de rede, env vars so no namespace `KAZZUS_KZ_*`, DDL so aditivo, numeracao 094..101, prefixo `kz/` em toda rota, eventos `kz.*`, zod `.strict()`, imports permitidos apenas (@nestjs/common, zod, node:*, kz) |
| Dependencias | **Nenhuma nova**: zod 4.6.7, @nestjs/* 11.2.7, @electric-sql/pglite 0.3.16, tsx 4.23.15, typescript 5.9.3 (as versoes do contrato). `package.json` do projeto permanece intocado |

Ambiente: Node v24.22.3, npm 11.19.1, Linux. Os mesmos SQL e codigo foram escritos
para PGlite e PostgreSQL (parametros `$n`, sem extensao alem de `pgcrypto` nativa
do `gen_random_uuid()` do Postgres 13+).

## 2. O que foi entregue

### 2.1 Infraestrutura comum (migracao 094) - `src/modules/kz-common.ts` e `kz-flags.ts`

`kz_feature_flags` (flag por loja; liga so com `KAZZUS_KZ_<MODULO>=YES` no processo
E linha habilitada), `kz_settings` (chave/valor da loja, ex.: nome para o termo),
`kz_counters` (numeros legiveis OS-/CR-/AT-), `kz_command_receipts` (idempotencia
com hash do input; mesma chave devolve o mesmo recibo, input diferente da
`IDEMPOTENCY_CONFLICT`), `kz_outbox_events` (eventos `kz.*` com dedupe por
`dedupe_key`) e `kz_audit_events` (trilha append-only com hash encadeado e
verificacao `kzVerifyAuditChain`, protegida por advisory lock).

`kz-flags` tambem expoe o plano de controle (`GET/POST kz/flags`, `kz/settings`) e
o registro unico de modulos (`KZ_MODULES`). Kill switch geral: `KAZZUS_KZ_AUTOMATIONS`.

### 2.2 Modulos de dominio

| Modulo (migracao) | Item do contrato | O que faz |
|---|---|---|
| kz-caixa (095) | 1 | Caixa do dia: abertura, sangria, reforco, fechamento com conferencia cega (esperado e diferenca so apos a contagem); uma sessao aberta por loja (indice unico parcial) |
| kz-pagamento-misto (099) | 2 | Divide o pagamento em varias formas com troco; `soma - troco = total` obrigatorio (`PAYMENT_SPLIT_MISMATCH`); adaptador injetavel de total real do pedido pronto para o Lote 2; redivisao arquiva o conjunto anterior |
| kz-taxas (096) | 3 | Tabela de taxas por bandeira/parcela editada pelo Anderson + simulador (taxa, liquido, parcelas e lucro real) com matematica inteira em centavos; simulacao nao grava nada (R1) |
| kz-os (097) | 4 | OS com numero legivel, checklist, pecas (custo interno), fotos por referencia e senha do aparelho cifrada em AES-256-GCM (nunca devolvida, nunca em evento/auditoria/log); fluxo de status com transicoes fechadas |
| kz-usados (098) | 5 e 6 | Avaliacao de usado com IMEI validado por Luhn, tabela de referencia por modelo/grau (faixa so sugere; fora da faixa marca `out_of_range`, nunca bloqueia), aprovacao/recusa com `unit_ref` e termo de compra em RASCUNHO com aceite |
| kz-crediario (100) | 8 | Carne com parcelas mensais (divisao inteira, ajuste de fim de mes), limite por cliente, baixa manual, quitacao, cancelamento so sem pagamento; job diario PREPARADO (emite `kz.parcela.vence_amanha`/`kz.parcela.atrasada` com dedupe; registro no agendador so na Fase 2, atras do kill switch) |
| kz-seguranca (101) | 14 | PIN (scrypt, 4-8 digitos) com concessoes de 5 minutos por proposito, consumo unico, trava de 5 tentativas em 15 min (tentativas persistem em transacao propria) e historico proprio; helper `kzGrantValido` pronto para os modulos que vao exigir passo extra |

### 2.3 Contagem

- **59 arquivos entregues** em `arquivos-novos/` (SHA-256 em `MANIFEST.sha256`):
  2 compartilhados + 7 modulos (36 arquivos: 28 ts + 7 README + 1 jobs.ts do
  crediario) + 8 migracoes + 11 arquivos de teste (10 da Revisao 1 +
  kz-guards.test.ts da Revisao 2) + 2 helpers de teste.
- **50 rotas** `kz/...` (detalhe e exemplos de payload em `rotas-para-o-proxy-v21.md`).
- **24 tabelas kz** e **32 tipos de evento** `kz.*`.
- Validador local reproduzivel em `validador-local/` (`npm install && npm test`).

## 3. Decisoes e desvios justificados (tudo codificado, nada escondido)

1. **Recibos/eventos/auditoria em tabelas kz proprias (094).** O contrato manda
   usar `command()`/`event()`/`writeAuditEvent()`, mas os schemas reais de
   `crm.command_receipts`, `crm.outbox_events` e da trilha oficial nao foram
   enviados; inventar colunas quebraria a base viva. As copias seguem o mesmo
   comportamento documentado (idempotencia por chave, dedupe por `dedupe_key`,
   hash encadeado) e a troca pelas oficiais fica em UM ponto (`kz-common.ts`).
   Duvidas D2/D3.
2. **`DomainError` e checagem de papel como copias fieis** (secoes 2.5/2.6) em
   `kz-common`, sem import de caminho desconhecido. Se o filtro real usar
   `instanceof` da classe original, o ajuste e de 1 linha (duvida D1; o filtro do
   validador aceita pelos dois caminhos e esta testado).
3. **Escrita kz so para operator/admin** (copia conservadora da regra
   documentada). Abrir para vendedor exige editar `authorization.ts` (holdout) -
   duvida D7, igual a duvida 2 do contrato.
4. **`kz/flags` e `kz/settings` sem flag propria** (plano de controle): sem isso
   seria impossivel ligar qualquer modulo por loja, ja que a flag da loja mora na
   tabela que o modulo gerencia. Duvida D9.
5. **Nenhum preco gravado (R1).** A OS nao tem campo de valor de servico; taxa e
   faixa de usado sao leitura/sugestao; o total do crediario e o financiamento de
   venda ja fechada. Guarda estatica: nenhum INSERT/UPDATE fora de `crm.kz_*`.
6. **Senha da OS e PIN fora de qualquer caminho de saida**: criptografia
   AES-256-GCM com chave `KAZZUS_KZ_DATA_KEY`; redacao automatica de payloads
   (`kzRedact`); testes provam que evento e auditoria nao carregam segredo. No
   recibo de idempotencia do PIN, o valor entra como `[segredo]` (o hash do recibo
   fica estavel e o PIN nao existe nem indireto na base).
7. **Tentativa de PIN persiste mesmo com erro** (transacao propria antes da
   principal), senao o rollback apagaria a falha e a trava nao funcionaria.
8. **Nada automatico no Lote 1**: o job do crediario so emite eventos internos,
   exige flag de modulo + kill switch e nao esta registrado em `main.ts` (a ligacao
   e Fase 2, conforme o contrato).
9. **FKs logicas** para orders/quotes/contacts ate confirmar os schemas reais
   (duvida D4); `contact_id`, `order_id` e afins sao `uuid` sem FK fisica.

## 4. O que NAO pode ser validado neste ambiente (honestidade total)

- `npm test` da arvore real (524 arquivos, 7+5 falhas conhecidas): a arvore do
  Kazzus nao foi enviada. Os testes entregues rodam la com um ajuste de 1 linha se
  o caminho do `Database` nao estiver na lista do resolver (duvida D1).
- `npm run lint:ci` com a configuracao real do eslint (nao enviada).
- A aplicacao literal do `ligacao.patch` (as linhas de contexto reais nao existem
  aqui; o patch e do tipo instrucao, bloco por bloco).
- Execucao contra PostgreSQL real (o SQL foi escrito para os dois, com parametros
  `$n` e sem recursos exclusivos de PGlite; testado em PGlite 0.3.16, que e
  Postgres 16 compilado).
- Hashes dos holdouts (`src/authorization.ts`, `src/sales-*`, `package.json`):
  inalterados POR CONSTRUCAO (nenhum arquivo existente foi tocado), mas o confer
  com SHA-256 so pode ser feito na arvore real.

## 5. Como aplicar (resumo; detalhe no ligacao.patch)

1. Conferir se 094..101 estao livres (duvida D6) e criar worktree de 56f3aca.
2. Backup datado com SHA-256 da base e da arvore.
3. Copiar `arquivos-novos/` (src/modules, migrations, tests/modules) para a arvore.
4. Aplicar o `ligacao.patch` (database-migrations.ts, app.ts; main.ts fica para a
   Fase 2).
5. `npm run check` e `npm test -- --filter kz-` na copia isolada (os testes kz
   criam PGlite em memoria; nao tocam a base viva).
6. Subir API de teste na porta 3201 apontando para banco de teste (duvida D8) e
   validar com o front V21 de teste.
7. Base viva: migracao manual com API parada e flag desligada, so com OK escrito
   do Anderson, com plano de volta testado.

## 6. Melhorias incluidas alem do contrato

- Testes de CONTRATO estaticos (`kz-contract.test.ts`) que codificam R1, R2, R5,
  R7, R8 e o molde das migracoes - continuam guardando as regras no repo real.
- Resolver de `Database` nos testes (`kz-database.ts`) com override por ambiente,
  para os testes rodarem na arvore real com ajuste de 1 linha.
- Matematica inteira exata em centavos (`kzSplitCents`, taxa com `floor` inteiro),
  sem erro de ponto flutuante em parcela e taxa.
- Validacao Luhn de IMEI e ajuste de fim de mes nas parcelas do crediario.
- Advisory lock na trilha de auditoria (sem corrida no sequencial por loja).
- `MANIFEST.sha256` com o hash de cada arquivo entregue (`sha256sum -c`).
- Validador local 100% reproduzivel (`npm install && npm test && npm run check`).

## 7. Duvidas para o Anderson

D1 a D13 consolidadas no `../fase-0/mapa.md` (secao 6). As que bloqueiam algo do
Lote 1 em producao: D1 (caminho do DomainError/Database), D2/D3 (tabelas oficiais
de recibo/outbox/auditoria), D6 (094 livre?), D8 (porta de teste) e D9 (plano de
controle sem flag propria).

## 8. Proximos passos

1. OK do Anderson sobre este lote e as duvidas acima.
2. Lote 2: orcamento-venda, financeiro, vale-troca, custos, analise ABC, estoque
   disponivel e teste de backup (todos dependem de schema real - ver mapa).
3. Fase 2: motor de regras lendo outbox oficial + kz, com dry-run, log de desfazer
   e kill switch.

---

## 9. Revisao 2 - rodada de revisao externa (os 50 achados e as disposicoes)

Uma IA revisora externa varreu as migracoes e a documentacao visiveis (o arquivo
enviado truncou no meio da 100; as camadas TypeScript nao foram revisadas por ela)
e listou 50 achados. Triagem item a item contra o codigo REAL (servicos, schemas e
testes, que a revisora nao viu): **24 corrigidos no codigo**, **6 em
documentacao**, **13 rebatidos com evidencia** (o servico/zod ja garantia, com
teste provando), **5 documentados como decisao de projeto** e **2 encaminhados ao
Anderson (D14)**. Disposicoes: CORRIGIDO / DOC CORRIGIDA / JA GARANTIDO
(rebatido com evidencia) / DESIGN DOCUMENTADO / ADIADO (duvida).

| # | Achado | Disposicao | O que foi feito |
|---|---|---|---|
| 1 | GRANT UPDATE em kz_audit_events (critica) | CORRIGIDO | Grant agora so SELECT, INSERT + gatilho kz_auditoria_imutavel bloqueia UPDATE/DELETE ate para owner; testes 42501 (crm_app) e owner (zz) |
| 2 | GRANT UPDATE em kz_outbox_events | CORRIGIDO | Grant SELECT, INSERT + gatilho kz_outbox_imutavel; evento imutavel, dedupe por chave unica |
| 3 | GRANT UPDATE em kz_command_receipts | CORRIGIDO | Grant SELECT, INSERT + gatilho kz_recibos_imutavel; kzCommand trocou SELECT...FOR UPDATE por pg_advisory_xact_lock(9450, hash(ws\|chave)) - FOR UPDATE exigiria privilegio UPDATE |
| 4 | outbox sem status/processed_at | DESIGN DOCUMENTADO (D15) | Consumidor da Fase 2 guarda posicao propria em kz_rule_cursors (multiplos consumidores independentes); documentado na 094 e no mapa |
| 5 | vale_troca (SQL) vs vale-troca (doc A4) | DOC CORRIGIDA | Codigo era consistente (vale_troca no SQL e no zod); so o exemplo da A4 dizia vale-troca. Corrigido |
| 6 | falta CHECK da equacao do pagamento | CORRIGIDO | CHECK kz_payment_equacao (payments - change = total) na 099 + teste 23514 |
| 7 | falta CHECK paid_cents <= total_cents | CORRIGIDO | CHECK kz_credit_pago_coerente na 100 (+ quitado/cancelado coerentes) + testes |
| 8 | unico aberto por closed_at IS NULL | CORRIGIDO | Indice agora WHERE status='aberta' AND archived_at IS NULL, amarrado ao CHECK de coerencia |
| 9 | sem CHECK status aberta/fechada coerente | CORRIGIDO | CHECK kz_cash_status_coerente ((status='aberta') = (closed_at IS NULL)) + fechada exige closed_by |
| 10 | sem CHECK da formula da diferenca | CORRIGIDO | CHECK kz_cash_fechamento_coerente: fechada exige counted/expected/difference e difference = counted - expected |
| 11 | movimento em sessao fechada | CORRIGIDO (defesa extra) | Servico ja negava (INVALID_STATE com FOR UPDATE); adicionado gatilho kz_cash_movimento_aberto + teste |
| 12 | PK de kz_credit_limits impede arquivar+recriar | JA GARANTIDO | Fluxo e upsert (SELECT FOR UPDATE -> UPDATE/INSERT), um limite por cliente atualizado no lugar; nao existe fluxo arquivar+recriar |
| 13 | installments em dinheiro/pix/debito/vale_troca | CORRIGIDO (SQL) | zod ja recusava com 422 (refine no schema); CHECK kz_payment_parcelas_metodo como segunda barreira + teste |
| 14 | change_cents > payments_total | JA GARANTIDO | Subsumido pelo CHECK #6: payments - change = total > 0 implica payments > change sempre |
| 15 | soma dos splits vs total do conjunto | CORRIGIDO | CONSTRAINT TRIGGER diferido kz_payment_splits_soma confere no COMMIT (splits entram um a um) + teste de commit rejeitado |
| 16 | IMEI em texto puro | ADIADO (D14) | IMEI nunca vai para evento/auditoria/log (payloads conferidos); criptografia em repouso pendente decisao do Anderson (R9 so exige cifrar senha do aparelho e RG) |
| 17 | termo com dados pessoais em claro | ADIADO (D14) | Termo precisa ser exibido/impresso; retencao LGPD ja era duvida D10; cifrar em repouso = D14 |
| 18 | checklist jsonb sem schema | CORRIGIDO (SQL) | zod ja tipava array {label, ok, note}; CHECK kz_usados_checklist_lista (jsonb_typeof = 'array') + teste |
| 19 | decided_at/by nao amarrados ao status | CORRIGIDO | CHECK kz_usados_decisao_coerente; cancelamento futuro devera registrar decided_at/by (comentado na 098) |
| 20 | aprovada sem stocked_unit_ref | CORRIGIDO | unit_ref agora OBRIGATORIO no zod (spec: aprovacao entra como unidade serial used; testes ja usavam) + CHECK kz_usados_aprovada_com_unidade + doc A4 |
| 21 | UPDATE reescreve termo aceito | JA GARANTIDO + defesa | Servico gera o termo UMA vez (ON CONFLICT DO NOTHING) e aceite so grava accepted_at; gatilho kz_termo_texto_imutavel adicionado + teste |
| 22 | delivered_at nao amarrado a entregue | CORRIGIDO | CHECK kz_os_entrega_coerente (bicondicional; entregue e final na lista de transicoes) |
| 23 | done sem done_at; posicao apos arquivar | CORRIGIDO / JA GARANTIDO | CHECK kz_os_check_concluido (done = done_at = done_by; servico ja zerava ao desmarcar). Nao ha fluxo de arquivar item de checklist: unique total e intencionalmente mais estrito |
| 24 | storage_ref texto livre | CORRIGIDO | zod kzOsStorageRef (charset fechado, sem .., sem caminho absoluto) + CHECK kz_os_foto_ref_fmt + teste |
| 25 | peca/foto em OS entregue/cancelada | CORRIGIDO (e pior do que reportado) | Pecas ja bloqueavam; FOTOS nao bloqueavam nada e CHECKLIST so bloqueava cancelada. Servico corrigido (ambos bloqueiam entregue/cancelada) + gatilho kz_os_*_ativa nas 3 tabelas filhas + testes |
| 26 | brand exige minusculas | JA GARANTIDO | zod kzTaxaBrand ja recusa com 422 claro (bandeira em minusculas); SQL CHECK e a segunda barreira; A4 documenta |
| 27 | active=false nao libera slot (taxas) | JA GARANTIDO | Fluxo e upsert (nunca precisa liberar slot); arquivar define active=false E archived_at juntos; desativar isolado e pausa temporaria reativavel (design) |
| 28 | idem referencia de usados | JA GARANTIDO | Mesma evidencia do #27 (refSet upsert + refArquivar com archived_at) |
| 29 | kz_counters fora do molde | CORRIGIDO + DESIGN | created_at adicionado; version/created_by/archived_at ficam de fora por design (contador interno atomico, sem ator por incremento) - desvio documentado na 094 e no mapa; prefixo maiusculo ja era so formatacao (mapa, secao 4) |
| 30 | kz_settings pode guardar segredo | DESIGN DOCUMENTADO | Escrita so operator/admin; evento e auditoria registram SO a chave (nunca o valor); README orienta nao guardar segredo. Allowlist travaria ajustes futuros |
| 31 | mudanca de flag sem auditoria | JA GARANTIDO | kz-flags.set() JA grava evento kz.flags.alteradas E auditoria (a revisora nao viu o arquivo); idem settings |
| 32 | order_kind/order_id incoerentes | CORRIGIDO | refine no zod (ambos ou nenhum) + CHECK kz_credit_vinculo_coerente + teste + doc A4 |
| 33 | quitado sem paid=total | CORRIGIDO | CHECK kz_credit_quitado_coerente + teste |
| 34 | cancelado com paid>0 | CORRIGIDO | CHECK kz_credit_cancelado_coerente (servico ja exigia paid=0) + teste |
| 35 | first_due no passado | JA GARANTIDO | Intencional: carne retroativo e cenario real; o proprio teste cria parcela com vencimento no passado para exercitar kz.parcela.atrasada. Documentado na 100 |
| 36 | updated_at sem trigger | JA GARANTIDO | Todos os UPDATEs de servico ja setam updated_at=now() (padrao auditado por grep); trigger global so adicionaria risco |
| 37 | version sem trigger | JA GARANTIDO | Todos os UPDATEs fazem version = version + 1 E kzSameVersion compara o esperado; trigger de incremento causaria dupla-contagem e quebraria a concorrencia otimista |
| 38 | DomainError instanceof no filtro real | DESIGN DOCUMENTADO (D1) | Risco conhecido e documentado no patch (ajuste de 1 linha: aceitar err.name === 'DomainError'); validador prova o padrao por nome; nao corrigivel sem a arvore real (R7) |
| 39 | 9 controllers | DOC CORRIGIDA | Sao 8 controllers (kz-flags + 7 dominios) com 50 handlers; o 9 estava no INDICE gerado para a revisao, nao na entrega. Corrigido no indice |
| 40 | 32 vs 30 eventos | DOC CORRIGIDA | O certo e 32: 30 tipos nos events.ts + kz.flags.alteradas + kz.settings.alteradas (kz-flags.ts). O RELATORIO estava certo; o 30 estava no indice gerado |
| 41 | 58 vs 57 arquivos | DOC CORRIGIDA | Sao 59 arquivos novos + MANIFEST (58 da Revisao 1 + kz-guards.test.ts da Revisao 2; a decomposicao do proprio README ja somava 58). Padronizado |
| 42 | exemplo device_password literal | DOC CORRIGIDA | A4 agora omite o campo do exemplo e nota que e opcional, cifrado em AES-256-GCM e nunca volta na resposta |
| 43 | crediario sem order_kind/order_id na doc | DOC CORRIGIDA | A4 agora documenta os dois campos opcionais (e acoplados) |
| 44 | IF NOT EXISTS parcial entre CREATE e indice | JA GARANTIDO | Cada migracao roda inteira numa unica mensagem de consulta (transacao implicita do protocolo); na arvore real, seguir o runner do projeto |
| 45 | gen_random_uuid exige PG13+ | JA GARANTIDO | Requisito do contrato, ja declarado na secao 1 deste relatorio |
| 46 | crm_app deve existir | JA GARANTIDO | Papel da aplicacao descrito no contrato (secoes 2.6/2.7); a base 000 so do validador o cria porque o banco local nas limpo; CREATE ROLE na migracao real seria risco |
| 47 | FORCE RLS afeta owner | DESIGN DOCUMENTADO | Comentario na 094; manutencao precisa de set_config igual ao app |
| 48 | sem CHECK de formato do hash | CORRIGIDO | CHECK kz_audit_events_hash_fmt (64 hex) e kz_audit_events_prev_fmt |
| 49 | genesis do prev_hash indefinido | CORRIGIDO | Genesis e a string vazia (kz-common, kzAudit); CHECK permite '' ou 64 hex; comentado na 094 |
| 50 | sem ON DELETE cascade | DESIGN DOCUMENTADO | Intencional (arquiva, nao apaga; crm_app sem DELETE); ordem de limpeza documentada no README |

Achados EXTRAS encontrados na auto-revisao desta rodada (alem dos 50):

- EX1: indice redundante kz_card_fee_tables_por_bandeira (mesmas colunas e
  predicado do unico) - REMOVIDO da 096.
- EX2: kz_stepup_attempts (101) era log append-only com GRANT UPDATE - CORRIGIDO
  (grant SELECT, INSERT + gatilho kz_tentativas_imutavel).
- EX3: CHECKs de coerencia nas concessoes do kz-seguranca (used = used_at;
  expires_at > created_at) - ADICIONADOS na 101; o teste de concessao expirada
  foi reescrito para simular de forma realista (nascer ja vencida em vez de
  empurrar expires_at para antes de created_at).

Como validar tudo isto: `npm test` roda 111 testes, entre eles
`kz-guards.test.ts` (9 testes de guardas de banco como crm_app: 42501, 23514 e
gatilhos) e `zz-validador-guardas.test.ts` (2 testes no nivel owner/superuser +
catalogo de gatilhos e CHECKs).
