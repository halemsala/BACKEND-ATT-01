# Validador local - Lote 1 dos modulos kz (Kazzus CRM)

ATENCAO: esta pasta e um ambiente de VALIDACAO independente. Ela NAO faz parte do
projeto Kazzus e NENHUM arquivo daqui (exceto os que tambem existem em
`../arquivos-novos/`, identicos) deve ser copiado para a arvore real.

## O que e

Reproducao fiel do contrato para validar os modulos kz fora da arvore real:

- PGlite 0.3.16 em memoria + migrations 094..101 identicas as entregues;
- `Database.workspace()` com `app.workspace_id` + papel `crm_app` (RLS de verdade,
  provada em teste, nao so filtro de servico);
- padrao de escrita da secao 2.4: recibo de idempotencia (advisory lock na Revisao
  2), `FOR UPDATE`, `version+1`, evento no outbox kz e trilha de auditoria kz com
  hash encadeado;
- app NestJS 11 com os controllers kz, middleware de demo (Bearer demo-a/demo-b e
  x-kazzus-role) e filtro de erros no padrao do ApiErrors (secao 2.5).

A base sintetica cria duas lojas (DEMO_A e DEMO_B) para provar isolamento por RLS.

## Como rodar

```bash
npm install        # sem dependencia nova alem das que o projeto ja usa
npm test           # 111 testes: modulos + guardas de banco + contrato estatico + RLS + owner + fumaca HTTP
npm run check      # tsc --noEmit (zero erros)
```

Versoes usadas (as mesmas do contrato): zod 4.6.7, @nestjs/* 11.2.7,
@electric-sql/pglite 0.3.16, tsx 4.23.15, typescript 5.9.3. Node >= 22
(testado no 24.22.3).

## Layout

- `src/app.ts`, `src/database.ts`, `src/seed.ts`, `src/contracts.ts`,
  `src/database-migrations.ts`, `migrations/000_validador_base.sql`: SO do
  validador (nao copiar para o projeto).
- `src/modules/**`, `migrations/094..101`, `tests/modules/**`: arquivos ENTREGUES
  (identicos a `../arquivos-novos/`; conferir com o MANIFEST.sha256).
- `tests/zz-validador-*.test.ts`: testes so do validador (RLS bruta com papel
  crm_app, gatilhos de imutabilidade no nivel owner via `db.adminTx`, catalogo de
  CHECKs/gatilhos da Revisao 2, migracao parcial e fumaça HTTP com o app Nest de pe).

## Variaveis de ambiente usadas nos testes

- `KAZZUS_KZ_<MODULO>=YES` - liga a flag de processo do modulo no teste.
- `KAZZUS_KZ_AUTOMATIONS=YES` - kill switch dos jobs (testado no kz-crediario).
- `KAZZUS_KZ_DATA_KEY` - chave efemera e sintetica gerada pelo proprio teste.
- `KZ_DATABASE_MODULE` - override do caminho do Database para o resolver de testes
  (duvida D1 do RELATORIO quando rodar na arvore real).
