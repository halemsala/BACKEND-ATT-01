// VALIDADOR APENAS (zz-): prova bruta do RLS com papel crm_app (nao so filtro de
// servico), permissoes (sem DELETE), migracao requerida com base parcial e
// catalogo de politicas/indices das tabelas kz.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { Database } from '../src/database.js';
import { KzCaixa } from '../src/modules/kz-caixa/service.js';
import { KZ_DEMO_WS_A, KZ_DEMO_WS_B } from '../src/seed.js';

let db: any;

before(async () => {
  db = await Database.open();
});

after(async () => {
  await db.close();
});

test('RLS bruta: sem workspace definido, crm_app nao ve linha alguma das tabelas kz', async () => {
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await tx.query(
      "INSERT INTO crm.kz_settings (workspace_id, key, value, created_by) VALUES ($1, 'rls_teste', 'valor sintetico', 'kz-validador')",
      [KZ_DEMO_WS_A],
    );
  });
  const visivel = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_settings')).rows[0];
    return r.c;
  });
  assert.equal(visivel, 1);
  const semWorkspace = await db.rawTx(async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_settings')).rows[0];
    return r.c;
  });
  assert.equal(semWorkspace, 0, 'sem app.workspace_id o RLS devolve zero linhas');
  const outraLoja = await db.workspace(KZ_DEMO_WS_B, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_settings')).rows[0];
    return r.c;
  });
  assert.equal(outraLoja, 0, 'a loja B nao ve a linha da loja A');
});

test('permissoes: crm_app NAO tem DELETE nas tabelas kz (arquiva, nao apaga)', async () => {
  let negado = false;
  let codigo = '';
  try {
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      await tx.query('DELETE FROM crm.kz_settings');
    });
  } catch (e: any) {
    negado = /permission denied/i.test(String(e?.message ?? ''));
    codigo = String(e?.code ?? '');
  }
  assert.ok(negado, 'DELETE precisa ser negado ao papel da aplicacao');
  assert.equal(codigo, '42501');
});

test('catalogo: toda tabela kz tem policy workspace_scope, FORCE RLS e grant sem DELETE', async () => {
  const catalogo = await db.rawTx(async (tx: any) => {
    const politicas = (await tx.query(
      "SELECT tablename AS tabela FROM pg_policies WHERE schemaname = 'crm' AND starts_with(tablename, 'kz_')",
    )).rows;
    const forca = (await tx.query(
      `SELECT c.relname AS tabela FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = 'crm' AND starts_with(c.relname, 'kz_') AND c.relforcerowsecurity`,
    )).rows;
    const tabelas = (await tx.query(
      "SELECT c.relname AS tabela FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND starts_with(c.relname, 'kz_') AND c.relkind = 'r'",
    )).rows;
    return { politicas, forca, tabelas };
  });
  // fora do rawTx para consultar catalogo (superuser)
  const tabelas = catalogo.tabelas.map((t: any) => t.tabela).sort();
  const politicas = catalogo.politicas.map((t: any) => t.tabela).sort();
  const forca = catalogo.forca.map((t: any) => t.tabela).sort();
  assert.equal(tabelas.length, 24, '24 tabelas kz no Lote 1 (6 infra + 18 de dominio)');
  assert.deepEqual(politicas, tabelas, 'toda tabela kz tem a policy workspace_scope');
  assert.deepEqual(forca, tabelas, 'toda tabela kz usa FORCE ROW LEVEL SECURITY');
  // Revisao 2: recibos, outbox, auditoria e tentativas de PIN sao apendice-only
  // (grant sem UPDATE); as demais tabelas seguem mutaveis pelo servico.
  const apendiceOnly = new Set(['kz_command_receipts', 'kz_outbox_events', 'kz_audit_events', 'kz_stepup_attempts']);
  for (const tabela of tabelas) {
    const permissoes = await db.rawTx(async (tx: any) => {
      const linhas = (await tx.query(
        `SELECT has_table_privilege('crm_app', 'crm.${tabela}', 'DELETE') AS pode_apagar,
                has_table_privilege('crm_app', 'crm.${tabela}', 'SELECT') AS pode_ler,
                has_table_privilege('crm_app', 'crm.${tabela}', 'INSERT') AS pode_inserir,
                has_table_privilege('crm_app', 'crm.${tabela}', 'UPDATE') AS pode_atualizar`,
      )).rows[0];
      return linhas;
    });
    assert.equal(permissoes.pode_apagar, false, `${tabela}: sem DELETE`);
    assert.equal(permissoes.pode_ler, true, `${tabela}: com SELECT`);
    assert.equal(permissoes.pode_inserir, true, `${tabela}: com INSERT`);
    assert.equal(permissoes.pode_atualizar, !apendiceOnly.has(tabela), `${tabela}: UPDATE so nas tabelas mutaveis (Revisao 2)`);
  }
});

test('migracao ausente: base sem as kz responde KZ_MIGRATION_REQUIRED', async () => {
  const dbAntigo = await Database.open({ throughVersion: 0 });
  process.env.KAZZUS_KZ_CAIXA = 'YES';
  const caixa = new KzCaixa(dbAntigo);
  await assert.rejects(
    () => caixa.abrir({ workspaceId: KZ_DEMO_WS_A, actorId: 'kz-validador', providerAccountId: 'kz-validador', role: 'operator' }, { opening_cents: 1, idempotency_key: 'rls-mig-1' }),
    (e: any) => e?.code === 'KZ_MIGRATION_REQUIRED' && e?.status === 503,
  );
  delete process.env.KAZZUS_KZ_CAIXA;
  await dbAntigo.close();
});

test('migracao parcial: so a infra kz (094) responde KZ_CAIXA_MIGRATION_REQUIRED', async () => {
  const dbParcial = await Database.open({ throughVersion: 94 });
  process.env.KAZZUS_KZ_CAIXA = 'YES';
  await dbParcial.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await tx.query(
      "INSERT INTO crm.kz_feature_flags (workspace_id, module, enabled, created_by) VALUES ($1, 'caixa', true, 'kz-validador') ON CONFLICT (workspace_id, module) DO NOTHING",
      [KZ_DEMO_WS_A],
    );
  });
  const caixa = new KzCaixa(dbParcial);
  await assert.rejects(
    () => caixa.hoje({ workspaceId: KZ_DEMO_WS_A, actorId: 'kz-validador', providerAccountId: 'kz-validador', role: 'operator' }),
    (e: any) => e?.code === 'KZ_CAIXA_MIGRATION_REQUIRED' && e?.status === 503,
  );
  delete process.env.KAZZUS_KZ_CAIXA;
  await dbParcial.close();
});
