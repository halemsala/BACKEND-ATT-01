// VALIDADOR APENAS (zz-): prova dos gatilhos e CHECKs da Revisao 2 no nivel OWNER
// (superuser, sem SET ROLE): UPDATE/DELETE nas tabelas apendice-only derrubam
// mesmo para o dono do banco, e o catalogo confirma gatilhos e CHECKs novos.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { Database } from '../src/database.js';
import { KZ_DEMO_WS_A } from '../src/seed.js';

let db: any;

before(async () => {
  db = await Database.open();
});

after(async () => {
  await db.close();
});

function apendiceNegado(e: unknown): boolean {
  return /apendice-only/i.test(String((e as { message?: string })?.message ?? ''));
}

test('gatilhos de imutabilidade valem para o OWNER (superuser), tabela por tabela', async () => {
  const casos: Array<[string, string, unknown[]]> = [
    [
      'kz_command_receipts',
      "INSERT INTO crm.kz_command_receipts (workspace_id, action, idempotency_key, actor_id, request_hash, response) VALUES ($1, 'zz.guarda', 'zz-1', 'zz', $2, '{}')",
      [KZ_DEMO_WS_A, 'a'.repeat(64)],
    ],
    [
      'kz_outbox_events',
      "INSERT INTO crm.kz_outbox_events (workspace_id, type, aggregate_id, dedupe_key, actor_id, payload) VALUES ($1, 'kz.zz.guarda', 'agg', 'zz:1', 'zz', '{}')",
      [KZ_DEMO_WS_A],
    ],
    [
      'kz_audit_events',
      "INSERT INTO crm.kz_audit_events (workspace_id, seq, actor_id, action, payload, prev_hash, hash) VALUES ($1, 1, 'zz', 'zz.guarda', '{}', '', $2)",
      [KZ_DEMO_WS_A, '0'.repeat(64)],
    ],
    [
      'kz_stepup_attempts',
      "INSERT INTO crm.kz_stepup_attempts (workspace_id, actor_id, ok) VALUES ($1, 'zz', false)",
      [KZ_DEMO_WS_A],
    ],
  ];
  for (const [tabela, insere, params] of casos) {
    await assert.rejects(
      () =>
        db.adminTx(async (tx: any) => {
          await tx.query(insere, params);
          await tx.query(`UPDATE crm.${tabela} SET actor_id = actor_id`);
        }),
      apendiceNegado,
      `${tabela}: UPDATE precisa derrubar ate o owner`,
    );
    await assert.rejects(
      () =>
        db.adminTx(async (tx: any) => {
          await tx.query(insere, params);
          await tx.query(`DELETE FROM crm.${tabela}`);
        }),
      apendiceNegado,
      `${tabela}: DELETE precisa derrubar ate o owner`,
    );
  }
});

test('catalogo: gatilhos kz e CHECKs da Revisao 2 presentes em todas as tabelas esperadas', async () => {
  const catalogo = await db.adminTx(async (tx: any) => {
    const gatilhos = (
      await tx.query(
        "SELECT c.relname AS tabela FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND t.tgname LIKE 'kz\\_%' AND NOT t.tgisinternal",
      )
    ).rows;
    const checks = (
      await tx.query(
        "SELECT conname FROM pg_constraint con JOIN pg_class r ON r.oid = con.conrelid JOIN pg_namespace n ON n.oid = r.relnamespace WHERE n.nspname = 'crm' AND r.relname LIKE 'kz\\_%' AND con.contype = 'c'",
      )
    ).rows;
    return { gatilhos: gatilhos.map((x: any) => x.tabela).sort(), checks: checks.map((x: any) => x.conname).sort() };
  });
  // 10 tabelas com gatilho: imutabilidade (recibos, outbox, auditoria, tentativas),
  // guarda de sessao aberta (movimentos), guarda de OS ativa (checklist, pecas,
  // fotos), termo imutavel e soma dos splits (constraint trigger diferido).
  assert.deepEqual(catalogo.gatilhos, [
    'kz_audit_events',
    'kz_cash_movements',
    'kz_command_receipts',
    'kz_outbox_events',
    'kz_payment_splits',
    'kz_service_order_checklists',
    'kz_service_order_parts',
    'kz_service_order_photos',
    'kz_stepup_attempts',
    'kz_tradein_terms',
  ]);
  const esperados = [
    'kz_audit_events_hash_fmt',
    'kz_audit_events_prev_fmt',
    'kz_cash_status_coerente',
    'kz_cash_fechamento_coerente',
    'kz_os_entrega_coerente',
    'kz_os_check_concluido',
    'kz_os_foto_ref_fmt',
    'kz_usados_decisao_coerente',
    'kz_usados_aprovada_com_unidade',
    'kz_usados_checklist_lista',
    'kz_payment_equacao',
    'kz_payment_parcelas_metodo',
    'kz_credit_pago_coerente',
    'kz_credit_vinculo_coerente',
    'kz_credit_quitado_coerente',
    'kz_credit_cancelado_coerente',
    'kz_credit_parcela_paga_coerente',
    'kz_credit_parcela_quando_coerente',
    'kz_stepup_uso_coerente',
    'kz_stepup_prazo_coerente',
  ];
  for (const conname of esperados) {
    assert.ok(catalogo.checks.includes(conname), `CHECK ${conname} ausente no catalogo`);
  }
});
