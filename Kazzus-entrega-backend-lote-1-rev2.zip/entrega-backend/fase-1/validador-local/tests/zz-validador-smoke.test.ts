// VALIDADOR APENAS (zz-): fumaça HTTP com o app Nest ligado como o app.ts real faria
// depois do patch de ligacao. Prova rotas, filtro de erros, idempotencia via HTTP,
// papeis, agentes e isolamento entre lojas.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { Database } from '../src/database.js';
import { kzCriarApp } from '../src/app.js';

let db: any;
let app: any;
let base: string;

before(async () => {
  db = await Database.open();
  app = await kzCriarApp(db);
  await app.listen(0, '127.0.0.1');
  const endereco = app.getHttpServer().address();
  base = `http://127.0.0.1:${endereco.port}`;
});

after(async () => {
  await app.close();
  await db.close();
});

async function chamar(metodo: string, caminho: string, corpo?: unknown, cabecalhos: Record<string, string> = {}) {
  const resposta = await fetch(`${base}${caminho}`, {
    method: metodo,
    headers: { 'content-type': 'application/json', authorization: 'Bearer demo-a', ...cabecalhos },
    body: corpo === undefined ? undefined : JSON.stringify(corpo),
  });
  let json: any = null;
  try {
    json = await resposta.json();
  } catch {
    /* sem corpo */
  }
  return { status: resposta.status, json, headers: resposta.headers };
}

test('sem flag por loja responde MODULE_DISABLED', async () => {
  process.env.KAZZUS_KZ_CAIXA = 'YES'; // processo ligado, loja B nao tem linha
  const r = await chamar('GET', '/kz/caixa/hoje', undefined, { authorization: 'Bearer demo-b' });
  assert.equal(r.status, 404);
  assert.equal(r.json.code, 'MODULE_DISABLED');
});

test('plano de controle liga o modulo por loja e o ciclo do caixa funciona por HTTP', async () => {
  const ligar = await chamar('POST', '/kz/flags', { module: 'caixa', enabled: true, idempotency_key: 'smoke-flag-1' });
  assert.equal(ligar.status, 201);
  assert.equal(ligar.json.enabled, true);

  const abrir = await chamar('POST', '/kz/caixa/abrir', { opening_cents: 100000, idempotency_key: 'smoke-1' });
  assert.equal(abrir.status, 201);
  assert.equal(abrir.json.status, 'aberta');

  const repetido = await chamar('POST', '/kz/caixa/abrir', { opening_cents: 100000, idempotency_key: 'smoke-1' });
  assert.equal(repetido.json.id, abrir.json.id, 'idempotencia via HTTP devolve o mesmo recibo');

  const sangria = await chamar('POST', '/kz/caixa/sangria', {
    session_id: abrir.json.id,
    amount_cents: 20000,
    reason: 'fumaça sintetica',
    expected_version: 1,
    idempotency_key: 'smoke-2',
  });
  assert.equal(sangria.status, 201);

  const fechar = await chamar('POST', '/kz/caixa/fechar', {
    session_id: abrir.json.id,
    counted_cents: 130000,
    expected_version: 2,
    idempotency_key: 'smoke-3',
  });
  assert.equal(fechar.status, 201);
  assert.equal(Number(fechar.json.expected_cents), 80000);
  assert.equal(Number(fechar.json.difference_cents), 50000);

  const hoje = await chamar('GET', '/kz/caixa/hoje');
  assert.equal(hoje.status, 200);
  assert.equal(hoje.json.aberta, null);
  assert.equal(hoje.json.fechadas_hoje.length, 1);
  assert.equal(hoje.headers.get('cache-control'), 'private, no-store');
});

test('erros mapeados pelo filtro: 404, 403, 422 e agente bloqueado', async () => {
  const naoEncontrado = await chamar('GET', '/kz/caixa/00000000-0000-4000-8000-000000000009');
  assert.equal(naoEncontrado.status, 404);
  assert.equal(naoEncontrado.json.code, 'NOT_FOUND');

  const escritaVendedor = await chamar('POST', '/kz/caixa/abrir', { opening_cents: 1, idempotency_key: 'smoke-x1' }, { 'x-kazzus-role': 'sales' });
  assert.equal(escritaVendedor.status, 403);
  assert.equal(escritaVendedor.json.code, 'FORBIDDEN');

  const agente = await chamar('GET', '/kz/caixa/hoje', undefined, { 'x-kazzus-agent': 'kz-agente' });
  assert.equal(agente.status, 403);
  assert.equal(agente.json.code, 'FORBIDDEN');

  const invalido = await chamar('POST', '/kz/caixa/abrir', { opening_cents: -5, idempotency_key: 'smoke-x2' });
  assert.equal(invalido.status, 422);
  assert.equal(invalido.json.code, 'INVALID_INPUT');
  assert.ok(Array.isArray(invalido.json.issues));

  const semAuth = await fetch(`${base}/kz/caixa/hoje`);
  assert.equal(semAuth.status, 401);
});

test('isolamento entre lojas por HTTP', async () => {
  const hojeB = await chamar('GET', '/kz/caixa/hoje', undefined, { authorization: 'Bearer demo-b' });
  assert.equal(hojeB.status, 404);
  assert.equal(hojeB.json.code, 'MODULE_DISABLED', 'loja B segue desligada (flag e por loja)');
});
