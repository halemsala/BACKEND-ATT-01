// Validador local: Database com PGlite em memoria, migracoes, transacao com RLS
// (set_config de app.workspace_id + papel crm_app) e bootstrap de workspaces.
// Reproduz o padrao descrito no contrato (secoes 2.4, 2.7 e 2.9).
// Arquivo do VALIDADOR apenas: nao copiar para a arvore real.

import { readFileSync } from 'node:fs';
import { PGlite } from '@electric-sql/pglite';
import { databaseMigrations } from './database-migrations.js';
import { KZ_DEMO_NAME_A, KZ_DEMO_NAME_B, KZ_DEMO_WS_A, KZ_DEMO_WS_B } from './seed.js';

export interface KzQueryResult<T> {
  rows: T[];
}

export interface HarnessTx {
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<KzQueryResult<T>>;
}

export class Database {
  private constructor(private readonly pg: PGlite) {}

  static async open(opts: { throughVersion?: number } = {}): Promise<Database> {
    const pg = new PGlite();
    const db = new Database(pg);
    await db.aplicarMigracoes(opts.throughVersion);
    await db.bootstrapWorkspace(KZ_DEMO_WS_A, KZ_DEMO_NAME_A);
    await db.bootstrapWorkspace(KZ_DEMO_WS_B, KZ_DEMO_NAME_B);
    return db;
  }

  private async aplicarMigracoes(through?: number): Promise<void> {
    for (const m of databaseMigrations) {
      if (through !== undefined && m.version > through) continue;
      const sql = readFileSync(new URL(m.file, import.meta.url), 'utf8');
      await this.pg.exec(sql);
      await this.pg.query(
        'INSERT INTO crm.schema_migrations (version, file) VALUES ($1, $2) ON CONFLICT (version) DO NOTHING',
        [m.version, m.file],
      );
    }
  }

  async bootstrapWorkspace(workspaceId: string, name: string): Promise<void> {
    await this.pg.query('INSERT INTO crm.workspaces (id, name) VALUES ($1, $2) ON CONFLICT (id) DO NOTHING', [
      workspaceId,
      name,
    ]);
  }

  async workspace<T>(workspaceId: string, fn: (tx: HarnessTx) => Promise<T>): Promise<T> {
    await this.pg.exec('BEGIN');
    try {
      await this.pg.query("SELECT set_config('app.workspace_id', $1, true)", [workspaceId]);
      await this.pg.query("SELECT set_config('role', 'crm_app', true)");
      const out = await fn(this.tx());
      await this.pg.exec('COMMIT');
      return out;
    } catch (err) {
      try {
        await this.pg.exec('ROLLBACK');
      } catch {
        /* transacao ja abortada */
      }
      throw err;
    }
  }

  /** Transacao como crm_app SEM workspace definido: o RLS deve devolver zero linhas. */
  async rawTx<T>(fn: (tx: HarnessTx) => Promise<T>): Promise<T> {
    await this.pg.exec('BEGIN');
    try {
      await this.pg.query("SELECT set_config('role', 'crm_app', true)");
      const out = await fn(this.tx());
      await this.pg.exec('ROLLBACK');
      return out;
    } catch (err) {
      try {
        await this.pg.exec('ROLLBACK');
      } catch {
        /* transacao ja abortada */
      }
      throw err;
    }
  }

  /** Transacao como OWNER (sem SET ROLE), sempre com ROLLBACK no fim: usada pelos
   *  testes zz- para provar que os gatilhos da Revisao 2 valem para qualquer papel. */
  async adminTx<T>(fn: (tx: HarnessTx) => Promise<T>): Promise<T> {
    await this.pg.exec('BEGIN');
    try {
      const out = await fn(this.tx());
      await this.pg.exec('ROLLBACK');
      return out;
    } catch (err) {
      try {
        await this.pg.exec('ROLLBACK');
      } catch {
        /* transacao ja abortada */
      }
      throw err;
    }
  }

  private tx(): HarnessTx {
    return {
      query: async <T>(sql: string, params?: unknown[]) => {
        const r = await this.pg.query(sql, params ?? []);
        return { rows: r.rows as T[] };
      },
    };
  }

  async close(): Promise<void> {
    await this.pg.close();
  }
}
