// Validador local: contratos minimos iguais aos do Kazzus (src/contracts.ts real).
// Arquivo do VALIDADOR apenas: nao copiar para a arvore real.

export type PrincipalRole =
  | 'admin'
  | 'manager'
  | 'sales'
  | 'support'
  | 'viewer'
  | 'operator'
  | 'simulator-finance'
  | 'agent';

export interface Principal {
  workspaceId: string;
  actorId: string;
  providerAccountId: string;
  role?: PrincipalRole;
  agentId?: string;
}
