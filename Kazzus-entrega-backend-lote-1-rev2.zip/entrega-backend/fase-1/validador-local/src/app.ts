// Validador local: app NestJS com os controllers kz + middleware de demo + filtro
// ApiErrors no padrao do contrato (secao 2.5). Reproduz a ligacao que o patch
// aplica no app.ts real. Arquivo do VALIDADOR apenas: nao copiar para a arvore real.

import 'reflect-metadata';
import { Catch, type ArgumentsHost, type DynamicModule, Module, type ExceptionFilter, type INestApplication } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { randomUUID } from 'node:crypto';
import type { Database } from './database.js';
import { KZ_DEMO_WS_A, KZ_DEMO_WS_B } from './seed.js';
import { KzFlagsController, KZ_FLAGS_PROVIDER } from './modules/kz-flags.js';
import { KzCaixaController, KZ_CAIXA_PROVIDER } from './modules/kz-caixa/routes.js';
import { KzTaxasController, KZ_TAXAS_PROVIDER } from './modules/kz-taxas/routes.js';
import { KzOsController, KZ_OS_PROVIDER } from './modules/kz-os/routes.js';
import { KzUsadosController, KZ_USADOS_PROVIDER } from './modules/kz-usados/routes.js';
import { KzPagamentoMistoController, KZ_PAGAMENTO_MISTO_PROVIDER } from './modules/kz-pagamento-misto/routes.js';
import { KzCrediarioController, KZ_CREDIARIO_PROVIDER } from './modules/kz-crediario/routes.js';
import { KzSegurancaController, KZ_SEGURANCA_PROVIDER } from './modules/kz-seguranca/routes.js';

type KzResposta = { status(codigo: number): KzResposta; json(corpo: unknown): unknown };

/** Filtro no padrao do ApiErrors real: { "code": ... } com o status certo. */
@Catch()
export class ApiErrors implements ExceptionFilter {
  catch(excecao: unknown, host: ArgumentsHost): void {
    const resposta = host.switchToHttp().getResponse<KzResposta>();
    const erro = excecao as {
      name?: string;
      code?: string;
      status?: number;
      constraint?: string;
      issues?: Array<{ path?: Array<string | number>; message?: string }>;
      stack?: string;
    };
    if (erro && typeof erro === 'object' && erro.name === 'DomainError' && typeof erro.code === 'string' && typeof erro.status === 'number') {
      resposta.status(erro.status).json({ code: erro.code });
      return;
    }
    if (erro && typeof erro === 'object' && erro.name === 'ZodError') {
      resposta.status(422).json({
        code: 'INVALID_INPUT',
        issues: (erro.issues ?? []).map((i) => ({ path: (i.path ?? []).join('.'), message: i.message })),
      });
      return;
    }
    if (erro?.code === '23503' || erro?.code === '23505' || erro?.code === '23514') {
      const codigo = erro.code === '23505' && erro.constraint === 'record_archived' ? 'RECORD_ARCHIVED' : 'DATA_CONSTRAINT';
      resposta.status(409).json({ code: codigo });
      return;
    }
    if (erro?.code === '42501') {
      resposta.status(403).json({ code: 'FORBIDDEN' });
      return;
    }
    const request_id = randomUUID();
    console.error(JSON.stringify({ level: 'error', request_id, message: String(erro?.stack ?? excecao) }));
    resposta.status(500).json({ code: 'INTERNAL_ERROR', request_id });
  }
}

@Module({})
class KzValidadorRootModule {}

export function kzModuloDoValidador(db: Database): DynamicModule {
  return {
    module: KzValidadorRootModule,
    controllers: [
      KzFlagsController,
      KzCaixaController,
      KzTaxasController,
      KzOsController,
      KzUsadosController,
      KzPagamentoMistoController,
      KzCrediarioController,
      KzSegurancaController,
    ],
    providers: [
      { provide: 'MANAGEMENT', useValue: { db } },
      KZ_FLAGS_PROVIDER,
      KZ_CAIXA_PROVIDER,
      KZ_TAXAS_PROVIDER,
      KZ_OS_PROVIDER,
      KZ_USADOS_PROVIDER,
      KZ_PAGAMENTO_MISTO_PROVIDER,
      KZ_CREDIARIO_PROVIDER,
      KZ_SEGURANCA_PROVIDER,
    ],
  };
}

const KZ_PAPEIS_DEMO = new Set(['admin', 'manager', 'sales', 'support', 'viewer', 'operator']);

export async function kzCriarApp(db: Database): Promise<INestApplication> {
  const app = await NestFactory.create(kzModuloDoValidador(db), { logger: false });
  app.use((req: { url?: string; headers: Record<string, unknown>; principal?: unknown }, res: { status(c: number): { json(b: unknown): unknown } }, next: () => void) => {
    const caminho = String(req.url ?? '').split('?')[0];
    if (!caminho.startsWith('/kz/')) return next();
    if (req.headers['x-kazzus-agent'] !== undefined) {
      res.status(403).json({ code: 'FORBIDDEN' });
      return;
    }
    const autorizacao = String(req.headers['authorization'] ?? '').replace(/^Bearer\s+/i, '');
    if (autorizacao !== 'demo-a' && autorizacao !== 'demo-b') {
      res.status(401).json({ code: 'UNAUTHORIZED' });
      return;
    }
    const papelHeader = req.headers['x-kazzus-role'];
    const papel = typeof papelHeader === 'string' && KZ_PAPEIS_DEMO.has(papelHeader) ? papelHeader : 'operator';
    req.principal = {
      workspaceId: autorizacao === 'demo-a' ? KZ_DEMO_WS_A : KZ_DEMO_WS_B,
      actorId: `kz-${autorizacao}`,
      providerAccountId: `kz-${autorizacao}`,
      role: papel,
    };
    next();
  });
  app.useGlobalFilters(new ApiErrors());
  return app;
}
