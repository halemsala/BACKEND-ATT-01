// Validador local: identificadores sinteticos das duas lojas de teste (DEMO_A / DEMO_B).
// Arquivo do VALIDADOR apenas: nao copiar para a arvore real.

export const KZ_DEMO_WS_A = '11111111-1111-4111-8111-111111111111';
export const KZ_DEMO_WS_B = '22222222-2222-4222-8222-222222222222';
export const KZ_DEMO_NAME_A = 'Loja Sintetica A';
export const KZ_DEMO_NAME_B = 'Loja Sintetica B';
