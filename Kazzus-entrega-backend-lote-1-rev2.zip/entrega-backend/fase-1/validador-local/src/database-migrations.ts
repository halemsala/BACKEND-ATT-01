// Validador local: registro de migracoes (espelha src/database-migrations.ts real).
// A base 000 existe so aqui; na arvore real as 094..101 entram no fim do array oficial.
// Arquivo do VALIDADOR apenas: nao copiar para a arvore real.

export interface DatabaseMigration {
  version: number;
  file: string;
}

export const databaseMigrations: DatabaseMigration[] = [
  { version: 0, file: '../migrations/000_validador_base.sql' },
  { version: 94, file: '../migrations/094_kz_infra.sql' },
  { version: 95, file: '../migrations/095_kz_caixa.sql' },
  { version: 96, file: '../migrations/096_kz_taxas.sql' },
  { version: 97, file: '../migrations/097_kz_os.sql' },
  { version: 98, file: '../migrations/098_kz_usados.sql' },
  { version: 99, file: '../migrations/099_kz_pagamento_misto.sql' },
  { version: 100, file: '../migrations/100_kz_crediario.sql' },
  { version: 101, file: '../migrations/101_kz_seguranca.sql' },
];
