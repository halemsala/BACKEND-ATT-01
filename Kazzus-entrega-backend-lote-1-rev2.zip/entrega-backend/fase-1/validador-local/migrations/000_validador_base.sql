-- 000 base do validador local do Lote 1 kz: replica minima do ambiente do Kazzus
-- (papel crm_app, schema crm, workspaces e registro de migracoes).
-- ATENCAO: arquivo do VALIDADOR apenas. NAO FAZ PARTE DA ENTREGA e nao deve ser
-- copiado para a arvore real do projeto.

CREATE SCHEMA IF NOT EXISTS crm;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'crm_app') THEN
    CREATE ROLE crm_app NOLOGIN;
  END IF;
END $$;

GRANT USAGE ON SCHEMA crm TO crm_app;

CREATE TABLE IF NOT EXISTS crm.workspaces (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT workspaces_pk PRIMARY KEY (id)
);
GRANT SELECT ON crm.workspaces TO crm_app;

CREATE TABLE IF NOT EXISTS crm.schema_migrations (
  version integer NOT NULL,
  file text NOT NULL,
  applied_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT schema_migrations_pk PRIMARY KEY (version)
);
