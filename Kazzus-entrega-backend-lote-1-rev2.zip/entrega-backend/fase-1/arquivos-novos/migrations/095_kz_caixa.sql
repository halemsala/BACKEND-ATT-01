-- 095 kz-caixa: sessoes de caixa do dia (abertura, sangria, reforco, fechamento com conferencia cega).
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_cash_sessions (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  opening_cents bigint NOT NULL CHECK (opening_cents >= 0),
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta', 'fechada')),
  opened_by text NOT NULL,
  opened_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  closed_by text,
  counted_cents bigint CHECK (counted_cents IS NULL OR counted_cents >= 0),
  declared_sales_cash_cents bigint NOT NULL DEFAULT 0 CHECK (declared_sales_cash_cents >= 0),
  expected_cents bigint,
  difference_cents bigint,
  note text CHECK (note IS NULL OR length(note) BETWEEN 1 AND 500),
  close_note text CHECK (close_note IS NULL OR length(close_note) BETWEEN 1 AND 500),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_cash_sessions_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_cash_status_coerente CHECK ((status = 'aberta') = (closed_at IS NULL)),
  CONSTRAINT kz_cash_fechamento_coerente CHECK (
    status <> 'fechada'
    OR (closed_by IS NOT NULL AND counted_cents IS NOT NULL AND expected_cents IS NOT NULL
        AND difference_cents = counted_cents - expected_cents)
  )
);

-- Revisao 2: o unico ativo agora usa status (antes closed_at IS NULL), amarrado ao
-- CHECK de coerencia - status 'aberta' sem closed_at e a unica forma de ficar ativo.
CREATE UNIQUE INDEX IF NOT EXISTS kz_cash_sessions_um_aberto ON crm.kz_cash_sessions (workspace_id) WHERE status = 'aberta' AND archived_at IS NULL;
CREATE INDEX IF NOT EXISTS kz_cash_sessions_por_data ON crm.kz_cash_sessions (workspace_id, opened_at DESC);

ALTER TABLE crm.kz_cash_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_cash_sessions FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_cash_sessions' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_cash_sessions USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_cash_sessions TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_cash_movements (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL,
  type text NOT NULL CHECK (type IN ('sangria', 'reforco')),
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  reason text NOT NULL CHECK (length(reason) BETWEEN 1 AND 500),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_cash_movements_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_cash_movements_sessao_fk FOREIGN KEY (workspace_id, session_id) REFERENCES crm.kz_cash_sessions (workspace_id, id)
);

CREATE INDEX IF NOT EXISTS kz_cash_movements_por_sessao ON crm.kz_cash_movements (workspace_id, session_id, created_at);

ALTER TABLE crm.kz_cash_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_cash_movements FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_cash_movements' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_cash_movements USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_cash_movements TO crm_app;

-- Revisao 2: defesa em profundidade - o servico ja nega movimento em sessao fechada
-- (INVALID_STATE com FOR UPDATE), e o gatilho garante o mesmo no banco para
-- qualquer outro caminho de escrita.
DO $mig$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'crm' AND p.proname = 'kz_caixa_somente_aberta') THEN
    EXECUTE $fn$CREATE FUNCTION crm.kz_caixa_somente_aberta() RETURNS trigger AS $body$
    DECLARE st text;
    BEGIN
      SELECT status INTO st FROM crm.kz_cash_sessions
       WHERE workspace_id = NEW.workspace_id AND id = NEW.session_id;
      IF st IS DISTINCT FROM 'aberta' THEN
        RAISE EXCEPTION 'movimento de caixa so em sessao aberta (sessao % do workspace %)', NEW.session_id, NEW.workspace_id;
      END IF;
      RETURN NEW;
    END $body$ LANGUAGE plpgsql$fn$;
  END IF;
END $mig$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_cash_movements' AND t.tgname = 'kz_cash_movimento_aberto') THEN
    EXECUTE 'CREATE TRIGGER kz_cash_movimento_aberto BEFORE INSERT ON crm.kz_cash_movements FOR EACH ROW EXECUTE FUNCTION crm.kz_caixa_somente_aberta()';
  END IF;
END $$;
