-- 100 kz-crediario: carne, parcelas e limite de credito por cliente.
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_credit_limits (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  contact_id uuid NOT NULL,
  limit_cents bigint NOT NULL CHECK (limit_cents >= 0),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_credit_limits_pk PRIMARY KEY (workspace_id, contact_id)
);

ALTER TABLE crm.kz_credit_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_credit_limits FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_credit_limits' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_credit_limits USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_credit_limits TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_credit_plans (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  plan_number text NOT NULL CHECK (plan_number ~ '^CR-[0-9]{5,8}$'),
  contact_id uuid NOT NULL,
  order_kind text CHECK (order_kind IS NULL OR order_kind IN ('order', 'quote')),
  order_id uuid,
  total_cents bigint NOT NULL CHECK (total_cents > 0),
  installments_count integer NOT NULL CHECK (installments_count BETWEEN 1 AND 48),
  first_due date NOT NULL,
  notes text CHECK (notes IS NULL OR length(notes) BETWEEN 1 AND 500),
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'quitado', 'cancelado')),
  paid_cents bigint NOT NULL DEFAULT 0 CHECK (paid_cents >= 0),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_credit_plans_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_credit_plans_numero_unico UNIQUE (workspace_id, plan_number),
  -- Revisao 2: integridade do carne no banco (o servico ja garantia; agora nem
  -- SQL direto grava incoerencia). first_due no passado E ACEITO DE PROPOSITO:
  -- carne retroativo e comum e o fluxo de atraso (kz.parcela.atrasada) depende
  -- disso - ver teste kz-crediario 'plano com parcela atrasada'.
  CONSTRAINT kz_credit_pago_coerente CHECK (paid_cents <= total_cents),
  CONSTRAINT kz_credit_vinculo_coerente CHECK ((order_kind IS NULL) = (order_id IS NULL)),
  CONSTRAINT kz_credit_quitado_coerente CHECK (status <> 'quitado' OR paid_cents = total_cents),
  CONSTRAINT kz_credit_cancelado_coerente CHECK (status <> 'cancelado' OR paid_cents = 0)
);

CREATE INDEX IF NOT EXISTS kz_credit_plans_por_cliente ON crm.kz_credit_plans (workspace_id, contact_id, status);

ALTER TABLE crm.kz_credit_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_credit_plans FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_credit_plans' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_credit_plans USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_credit_plans TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_credit_installments (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL,
  number integer NOT NULL CHECK (number BETWEEN 1 AND 48),
  due_date date NOT NULL,
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  paid_cents bigint NOT NULL DEFAULT 0 CHECK (paid_cents >= 0),
  paid_at timestamptz,
  paid_by text,
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta', 'paga')),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_credit_installments_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_credit_installments_plano_fk FOREIGN KEY (workspace_id, plan_id) REFERENCES crm.kz_credit_plans (workspace_id, id),
  CONSTRAINT kz_credit_installments_numero UNIQUE (workspace_id, plan_id, number),
  -- Revisao 2: parcela paga grava o valor cheio junto com data e autor (a baixa e
  -- sempre da parcela inteira).
  CONSTRAINT kz_credit_parcela_paga_coerente CHECK ((status = 'paga') = (paid_cents = amount_cents)),
  CONSTRAINT kz_credit_parcela_quando_coerente CHECK ((status = 'paga') = (paid_at IS NOT NULL) AND (status = 'paga') = (paid_by IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS kz_credit_installments_por_vencimento ON crm.kz_credit_installments (workspace_id, status, due_date);

ALTER TABLE crm.kz_credit_installments ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_credit_installments FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_credit_installments' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_credit_installments USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_credit_installments TO crm_app;
