-- 096 kz-taxas: tabela de taxas de maquininha por bandeira e parcela (simulacao e lucro real).
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_card_fee_tables (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  brand text NOT NULL CHECK (brand ~ '^[a-z0-9 -]{2,30}$'),
  installments integer NOT NULL CHECK (installments BETWEEN 1 AND 24),
  percent numeric(5,2) NOT NULL CHECK (percent >= 0 AND percent <= 100),
  fixed_cents bigint NOT NULL DEFAULT 0 CHECK (fixed_cents >= 0),
  active boolean NOT NULL DEFAULT true,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_card_fee_tables_pk PRIMARY KEY (workspace_id, id)
);

CREATE UNIQUE INDEX IF NOT EXISTS kz_card_fee_tables_unicas ON crm.kz_card_fee_tables (workspace_id, brand, installments) WHERE archived_at IS NULL;
-- Revisao 2: o indice comum kz_card_fee_tables_por_bandeira foi removido: tinha as
-- mesmas colunas e o mesmo predicado do unico acima (100% redundante).

ALTER TABLE crm.kz_card_fee_tables ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_card_fee_tables FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_card_fee_tables' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_card_fee_tables USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_card_fee_tables TO crm_app;
