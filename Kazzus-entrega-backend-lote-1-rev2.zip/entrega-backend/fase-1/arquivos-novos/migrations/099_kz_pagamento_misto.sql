-- 099 kz-pagamento-misto: divisao do pagamento em varias formas com troco (registro em modo demo).
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_payment_sets (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  order_kind text NOT NULL CHECK (order_kind IN ('order', 'quote')),
  order_id uuid NOT NULL,
  order_total_cents bigint NOT NULL CHECK (order_total_cents > 0),
  payments_total_cents bigint NOT NULL CHECK (payments_total_cents > 0),
  change_cents bigint NOT NULL DEFAULT 0 CHECK (change_cents >= 0),
  note text CHECK (note IS NULL OR length(note) BETWEEN 1 AND 500),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_payment_sets_pk PRIMARY KEY (workspace_id, id),
  -- Revisao 2: a equacao do pagamento misto virou CHECK do banco (o servico ja
  -- validava com PAYMENT_SPLIT_MISMATCH; agora nem SQL direto grava inconsistencia).
  -- payments - change = total implica payments > change (total e sempre > 0).
  CONSTRAINT kz_payment_equacao CHECK (payments_total_cents - change_cents = order_total_cents)
);

CREATE UNIQUE INDEX IF NOT EXISTS kz_payment_sets_ativo_por_pedido ON crm.kz_payment_sets (workspace_id, order_kind, order_id) WHERE archived_at IS NULL;

ALTER TABLE crm.kz_payment_sets ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_payment_sets FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_payment_sets' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_payment_sets USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_payment_sets TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_payment_splits (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  set_id uuid NOT NULL,
  split_index integer NOT NULL CHECK (split_index BETWEEN 1 AND 50),
  method text NOT NULL CHECK (method IN ('dinheiro', 'pix', 'debito', 'credito', 'crediario', 'vale_troca', 'outro')),
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  installments integer CHECK (installments IS NULL OR installments BETWEEN 1 AND 24),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_payment_splits_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_payment_splits_conjunto_fk FOREIGN KEY (workspace_id, set_id) REFERENCES crm.kz_payment_sets (workspace_id, id),
  CONSTRAINT kz_payment_splits_posicao UNIQUE (workspace_id, set_id, split_index),
  -- Revisao 2: parcelas so em credito/crediario (o zod ja recusa com 422; CHECK e
  -- a segunda barreira).
  CONSTRAINT kz_payment_parcelas_metodo CHECK (method IN ('credito', 'crediario') OR installments IS NULL)
);

CREATE INDEX IF NOT EXISTS kz_payment_splits_por_conjunto ON crm.kz_payment_splits (workspace_id, set_id, split_index);

ALTER TABLE crm.kz_payment_splits ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_payment_splits FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_payment_splits' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_payment_splits USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_payment_splits TO crm_app;

-- Revisao 2: gatilho de restricao DIFERIDO - no COMMIT confere que a soma dos
-- splits do conjunto e igual ao payments_total_cents gravado no conjunto. Diferido
-- porque o servico insere os splits um a um dentro da transacao.
DO $mig$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'crm' AND p.proname = 'kz_payment_splits_confere') THEN
    EXECUTE $fn$CREATE FUNCTION crm.kz_payment_splits_confere() RETURNS trigger AS $body$
    DECLARE
      total bigint;
      esperado bigint;
    BEGIN
      SELECT COALESCE(sum(s.amount_cents), 0) INTO total
        FROM crm.kz_payment_splits s
       WHERE s.workspace_id = NEW.workspace_id AND s.set_id = NEW.set_id AND s.archived_at IS NULL;
      SELECT p.payments_total_cents INTO esperado
        FROM crm.kz_payment_sets p
       WHERE p.workspace_id = NEW.workspace_id AND p.id = NEW.set_id;
      IF total IS DISTINCT FROM esperado THEN
        RAISE EXCEPTION 'soma dos splits (%) difere do total do conjunto (%)', total, esperado;
      END IF;
      RETURN NULL;
    END $body$ LANGUAGE plpgsql$fn$;
  END IF;
END $mig$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_payment_splits' AND t.tgname = 'kz_payment_splits_soma') THEN
    EXECUTE 'CREATE CONSTRAINT TRIGGER kz_payment_splits_soma AFTER INSERT OR UPDATE ON crm.kz_payment_splits DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION crm.kz_payment_splits_confere()';
  END IF;
END $$;
