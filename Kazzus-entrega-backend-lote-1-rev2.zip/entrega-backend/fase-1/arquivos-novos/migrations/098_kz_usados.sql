-- 098 kz-usados: avaliacao de aparelho usado, tabela de referencia e termo de compra (rascunho).
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_tradein_reference (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  model_label text NOT NULL CHECK (length(model_label) BETWEEN 1 AND 120),
  storage_label text CHECK (storage_label IS NULL OR length(storage_label) BETWEEN 1 AND 40),
  grade text NOT NULL CHECK (grade IN ('A', 'B', 'C', 'D')),
  min_value_cents bigint NOT NULL CHECK (min_value_cents >= 0),
  max_value_cents bigint NOT NULL CHECK (max_value_cents >= 0),
  notes text CHECK (notes IS NULL OR length(notes) BETWEEN 1 AND 500),
  active boolean NOT NULL DEFAULT true,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_tradein_reference_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_tradein_reference_faixa CHECK (min_value_cents <= max_value_cents)
);

CREATE UNIQUE INDEX IF NOT EXISTS kz_tradein_reference_unica ON crm.kz_tradein_reference (workspace_id, lower(model_label), COALESCE(storage_label, ''), grade) WHERE archived_at IS NULL;

ALTER TABLE crm.kz_tradein_reference ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_tradein_reference FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_tradein_reference' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_tradein_reference USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_tradein_reference TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_tradein_evaluations (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  eval_number text NOT NULL CHECK (eval_number ~ '^AT-[0-9]{5,8}$'),
  contact_id uuid,
  device_brand text NOT NULL CHECK (length(device_brand) BETWEEN 1 AND 60),
  device_model text NOT NULL CHECK (length(device_model) BETWEEN 1 AND 120),
  storage_label text CHECK (storage_label IS NULL OR length(storage_label) BETWEEN 1 AND 40),
  imei varchar(15) CHECK (imei IS NULL OR imei ~ '^[0-9]{15}$'),
  grade text NOT NULL CHECK (grade IN ('A', 'B', 'C', 'D')),
  checklist jsonb NOT NULL DEFAULT '[]'::jsonb,
  reference_id uuid,
  suggested_min_cents bigint,
  suggested_max_cents bigint,
  suggested_value_cents bigint CHECK (suggested_value_cents IS NULL OR suggested_value_cents >= 0),
  out_of_range boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'avaliada' CHECK (status IN ('avaliada', 'aprovada', 'recusada', 'cancelada')),
  decision_note text CHECK (decision_note IS NULL OR length(decision_note) BETWEEN 1 AND 500),
  decided_at timestamptz,
  decided_by text,
  stocked_unit_ref text CHECK (stocked_unit_ref IS NULL OR length(stocked_unit_ref) BETWEEN 1 AND 120),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_tradein_evaluations_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_tradein_evaluations_numero_unico UNIQUE (workspace_id, eval_number),
  CONSTRAINT kz_tradein_evaluations_referencia_fk FOREIGN KEY (workspace_id, reference_id) REFERENCES crm.kz_tradein_reference (workspace_id, id),
  -- Revisao 2: decisao so existe quando o status saiu de 'avaliada'; aprovacao
  -- exige o vinculo com a unidade de estoque (unit_ref obrigatorio na API).
  -- Um cancelamento futuro devera registrar decided_at/decided_by do mesmo jeito.
  CONSTRAINT kz_usados_decisao_coerente CHECK ((status = 'avaliada') = (decided_at IS NULL) AND (status = 'avaliada') = (decided_by IS NULL)),
  CONSTRAINT kz_usados_aprovada_com_unidade CHECK (status <> 'aprovada' OR stocked_unit_ref IS NOT NULL),
  CONSTRAINT kz_usados_checklist_lista CHECK (jsonb_typeof(checklist) = 'array')
);

CREATE INDEX IF NOT EXISTS kz_tradein_evaluations_por_status ON crm.kz_tradein_evaluations (workspace_id, status, created_at DESC);

ALTER TABLE crm.kz_tradein_evaluations ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_tradein_evaluations FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_tradein_evaluations' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_tradein_evaluations USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_tradein_evaluations TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_tradein_terms (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  evaluation_id uuid NOT NULL,
  template_version integer NOT NULL DEFAULT 1,
  rendered_text text NOT NULL CHECK (length(rendered_text) BETWEEN 200 AND 8000),
  accepted_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_tradein_terms_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_tradein_terms_avaliacao_fk FOREIGN KEY (workspace_id, evaluation_id) REFERENCES crm.kz_tradein_evaluations (workspace_id, id),
  CONSTRAINT kz_tradein_terms_por_avaliacao UNIQUE (workspace_id, evaluation_id)
);

ALTER TABLE crm.kz_tradein_terms ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_tradein_terms FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_tradein_terms' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_tradein_terms USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_tradein_terms TO crm_app;

-- Revisao 2: o texto do termo aceito e prova de registro - o servico ja gera o
-- termo uma unica vez (INSERT ... ON CONFLICT DO NOTHING) e o aceite so grava
-- accepted_at; o gatilho garante que NENHUM caminho reescreva o texto depois.
DO $mig$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'crm' AND p.proname = 'kz_termo_texto_fixo') THEN
    EXECUTE $fn$CREATE FUNCTION crm.kz_termo_texto_fixo() RETURNS trigger AS $body$
    BEGIN
      IF NEW.rendered_text IS DISTINCT FROM OLD.rendered_text THEN
        RAISE EXCEPTION 'texto do termo de compra e imutavel (avaliacao % do workspace %)', NEW.evaluation_id, NEW.workspace_id;
      END IF;
      RETURN NEW;
    END $body$ LANGUAGE plpgsql$fn$;
  END IF;
END $mig$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_tradein_terms' AND t.tgname = 'kz_termo_texto_imutavel') THEN
    EXECUTE 'CREATE TRIGGER kz_termo_texto_imutavel BEFORE UPDATE ON crm.kz_tradein_terms FOR EACH ROW EXECUTE FUNCTION crm.kz_termo_texto_fixo()';
  END IF;
END $$;
