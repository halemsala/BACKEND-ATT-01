-- 097 kz-os: ordens de servico com checklist, pecas, fotos e senha do aparelho cifrada.
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_service_orders (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  os_number text NOT NULL CHECK (os_number ~ '^OS-[0-9]{5,8}$'),
  contact_id uuid,
  device_brand text NOT NULL CHECK (length(device_brand) BETWEEN 1 AND 60),
  device_model text NOT NULL CHECK (length(device_model) BETWEEN 1 AND 80),
  device_password_enc text,
  problem_reported text NOT NULL CHECK (length(problem_reported) BETWEEN 1 AND 2000),
  diagnosis text CHECK (diagnosis IS NULL OR length(diagnosis) BETWEEN 1 AND 2000),
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta', 'em_analise', 'aguardando_aprovacao', 'aguardando_peca', 'em_reparo', 'pronta', 'entregue', 'cancelada')),
  delivered_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_service_orders_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_service_orders_numero_unico UNIQUE (workspace_id, os_number),
  CONSTRAINT kz_os_entrega_coerente CHECK ((status = 'entregue') = (delivered_at IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS kz_service_orders_por_status ON crm.kz_service_orders (workspace_id, status, created_at DESC);

ALTER TABLE crm.kz_service_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_service_orders FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_service_orders' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_service_orders USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_service_orders TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_service_order_checklists (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL,
  label text NOT NULL CHECK (length(label) BETWEEN 1 AND 200),
  position integer NOT NULL CHECK (position BETWEEN 1 AND 500),
  done boolean NOT NULL DEFAULT false,
  done_at timestamptz,
  done_by text,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_service_order_checklists_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_service_order_checklists_os_fk FOREIGN KEY (workspace_id, order_id) REFERENCES crm.kz_service_orders (workspace_id, id),
  CONSTRAINT kz_service_order_checklists_posicao UNIQUE (workspace_id, order_id, position),
  CONSTRAINT kz_os_check_concluido CHECK ((done) = (done_at IS NOT NULL) AND (done) = (done_by IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS kz_service_order_checklists_por_os ON crm.kz_service_order_checklists (workspace_id, order_id, position);

ALTER TABLE crm.kz_service_order_checklists ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_service_order_checklists FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_service_order_checklists' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_service_order_checklists USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_service_order_checklists TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_service_order_parts (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL,
  description text NOT NULL CHECK (length(description) BETWEEN 1 AND 200),
  quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 1000),
  unit_cost_cents bigint NOT NULL CHECK (unit_cost_cents >= 0),
  cost_source text NOT NULL CHECK (cost_source IN ('loja', 'terceiro', 'cliente')),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_service_order_parts_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_service_order_parts_os_fk FOREIGN KEY (workspace_id, order_id) REFERENCES crm.kz_service_orders (workspace_id, id)
);

CREATE INDEX IF NOT EXISTS kz_service_order_parts_por_os ON crm.kz_service_order_parts (workspace_id, order_id);

ALTER TABLE crm.kz_service_order_parts ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_service_order_parts FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_service_order_parts' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_service_order_parts USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_service_order_parts TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_service_order_photos (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('entrada', 'durante', 'saida')),
  storage_ref text NOT NULL CHECK (length(storage_ref) BETWEEN 1 AND 500),
  -- Revisao 2: referencia de armazenamento com formato fechado (sem '..', sem
  -- caminho absoluto, sem barra invertida e sem espaco) para nao virar caminho
  -- de filesystem livre.
  CONSTRAINT kz_os_foto_ref_fmt CHECK (storage_ref ~ '^[A-Za-z0-9][A-Za-z0-9._/-]*$' AND storage_ref !~ '\.\.'),
  note text CHECK (note IS NULL OR length(note) BETWEEN 1 AND 500),
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_service_order_photos_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_service_order_photos_os_fk FOREIGN KEY (workspace_id, order_id) REFERENCES crm.kz_service_orders (workspace_id, id)
);

CREATE INDEX IF NOT EXISTS kz_service_order_photos_por_os ON crm.kz_service_order_photos (workspace_id, order_id);

ALTER TABLE crm.kz_service_order_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_service_order_photos FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_service_order_photos' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_service_order_photos USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_service_order_photos TO crm_app;

-- Revisao 2: defesa em profundidade - checklist, peca e foto so entram em OS ATIVA
-- (status nao entregue/cancelada). O servico ja bloqueia (INVALID_STATE); o gatilho
-- cobre qualquer outro caminho de escrita.
DO $mig$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'crm' AND p.proname = 'kz_os_filha_somente_ativa') THEN
    EXECUTE $fn$CREATE FUNCTION crm.kz_os_filha_somente_ativa() RETURNS trigger AS $body$
    DECLARE st text;
    BEGIN
      SELECT status INTO st FROM crm.kz_service_orders
       WHERE workspace_id = NEW.workspace_id AND id = NEW.order_id;
      IF st IN ('entregue', 'cancelada') THEN
        RAISE EXCEPTION 'item de OS so entra em ordem ativa (ordem % do workspace % esta %)', NEW.order_id, NEW.workspace_id, st;
      END IF;
      RETURN NEW;
    END $body$ LANGUAGE plpgsql$fn$;
  END IF;
END $mig$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_service_order_checklists' AND t.tgname = 'kz_os_check_ativa') THEN
    EXECUTE 'CREATE TRIGGER kz_os_check_ativa BEFORE INSERT ON crm.kz_service_order_checklists FOR EACH ROW EXECUTE FUNCTION crm.kz_os_filha_somente_ativa()';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_service_order_parts' AND t.tgname = 'kz_os_peca_ativa') THEN
    EXECUTE 'CREATE TRIGGER kz_os_peca_ativa BEFORE INSERT ON crm.kz_service_order_parts FOR EACH ROW EXECUTE FUNCTION crm.kz_os_filha_somente_ativa()';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_service_order_photos' AND t.tgname = 'kz_os_foto_ativa') THEN
    EXECUTE 'CREATE TRIGGER kz_os_foto_ativa BEFORE INSERT ON crm.kz_service_order_photos FOR EACH ROW EXECUTE FUNCTION crm.kz_os_filha_somente_ativa()';
  END IF;
END $$;
