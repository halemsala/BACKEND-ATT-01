-- 101 kz-seguranca: PIN de acao sensivel, concessoes de curta validade e trilha de tentativas.
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.

CREATE TABLE IF NOT EXISTS crm.kz_stepup_pins (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  actor_id text NOT NULL,
  pin_hash text NOT NULL,
  pin_salt text NOT NULL,
  pin_ver text NOT NULL DEFAULT 'scrypt-16384-8-1',
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_stepup_pins_pk PRIMARY KEY (workspace_id, actor_id)
);

ALTER TABLE crm.kz_stepup_pins ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_stepup_pins FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_stepup_pins' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_stepup_pins USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_stepup_pins TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_stepup_grants (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  actor_id text NOT NULL,
  purpose text NOT NULL CHECK (length(purpose) BETWEEN 1 AND 60),
  expires_at timestamptz NOT NULL,
  used boolean NOT NULL DEFAULT false,
  used_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_stepup_grants_pk PRIMARY KEY (workspace_id, id),
  -- Revisao 2: concessao us marca a hora junto; prazo sempre posterior a criacao
  -- (ttl minimo de 30s no zod; now() e estavel dentro da transacao).
  CONSTRAINT kz_stepup_uso_coerente CHECK ((used) = (used_at IS NOT NULL)),
  CONSTRAINT kz_stepup_prazo_coerente CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS kz_stepup_grants_por_ator ON crm.kz_stepup_grants (workspace_id, actor_id, expires_at);

ALTER TABLE crm.kz_stepup_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_stepup_grants FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_stepup_grants' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_stepup_grants USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_stepup_grants TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_stepup_attempts (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  actor_id text NOT NULL,
  ok boolean NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT kz_stepup_attempts_pk PRIMARY KEY (workspace_id, id)
);

CREATE INDEX IF NOT EXISTS kz_stepup_attempts_por_ator ON crm.kz_stepup_attempts (workspace_id, actor_id, created_at);

ALTER TABLE crm.kz_stepup_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_stepup_attempts FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_stepup_attempts' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_stepup_attempts USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT ON crm.kz_stepup_attempts TO crm_app;
-- Revisao 2: trilha de tentativas e apendice-only (INSERT + SELECT), como
-- recibos/outbox/auditoria da 094 - reusa a mesma funcao de imutabilidade.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_stepup_attempts' AND t.tgname = 'kz_tentativas_imutavel') THEN
    EXECUTE 'CREATE TRIGGER kz_tentativas_imutavel BEFORE UPDATE OR DELETE ON crm.kz_stepup_attempts FOR EACH ROW EXECUTE FUNCTION crm.kz_apendice_somente()';
  END IF;
END $$;
