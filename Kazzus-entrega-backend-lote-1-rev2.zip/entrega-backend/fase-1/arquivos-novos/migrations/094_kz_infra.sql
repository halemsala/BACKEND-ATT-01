-- 094 kz infraestrutura comum: flags por loja, ajustes da loja, contadores, recibos de
-- idempotencia, outbox kz e trilha de auditoria kz (hash encadeado).
-- So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco.
--
-- Revisao 2 (17/11/2026, revisao externa): recibos, outbox e auditoria sao
-- APENDICE-ONLY - o grant e SELECT, INSERT e triggers bloqueiam UPDATE/DELETE ate
-- para o owner. O outbox NAO tem coluna processed_at por design: o consumidor da
-- Fase 2 (kz-regras) guarda a propria posicao em kz_rule_cursors, permitindo
-- varios consumidores independentes (duvida D15 do mapa).

CREATE TABLE IF NOT EXISTS crm.kz_feature_flags (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  module text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_feature_flags_pk PRIMARY KEY (workspace_id, module),
  CONSTRAINT kz_feature_flags_mod_tam CHECK (length(module) BETWEEN 1 AND 60),
  CONSTRAINT kz_feature_flags_mod_fmt CHECK (module ~ '^[a-z0-9-]+$')
);
CREATE INDEX IF NOT EXISTS kz_feature_flags_por_loja ON crm.kz_feature_flags (workspace_id, enabled);

ALTER TABLE crm.kz_feature_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_feature_flags FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_feature_flags' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_feature_flags USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_feature_flags TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_settings (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  key text NOT NULL,
  value text NOT NULL,
  version integer NOT NULL DEFAULT 1,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz,
  CONSTRAINT kz_settings_pk PRIMARY KEY (workspace_id, key),
  CONSTRAINT kz_settings_chave_fmt CHECK (key ~ '^[a-z0-9_.-]{1,60}$'),
  CONSTRAINT kz_settings_valor_tam CHECK (length(value) BETWEEN 1 AND 500)
);

ALTER TABLE crm.kz_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_settings FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_settings' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_settings USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_settings TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_counters (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  name text NOT NULL,
  value bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT kz_counters_pk PRIMARY KEY (workspace_id, name),
  CONSTRAINT kz_counters_nome_fmt CHECK (name ~ '^[a-z0-9_-]{1,60}$')
);
-- Desvio intencional do molde (version/created_by/archived_at): contador interno
-- de numeração atomica (INSERT ... ON CONFLICT DO UPDATE), sem ator humano por
-- incremento e sem arquivamento. O prefixo maiusculo (OS-/CR-/AT-) e apenas
-- formatacao na exibicao; aqui o nome e sempre minusculo.

ALTER TABLE crm.kz_counters ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_counters FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_counters' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_counters USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT, UPDATE ON crm.kz_counters TO crm_app;

CREATE TABLE IF NOT EXISTS crm.kz_command_receipts (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  action text NOT NULL,
  idempotency_key text NOT NULL,
  actor_id text NOT NULL,
  request_hash text NOT NULL,
  response jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT kz_command_receipts_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_command_receipts_chave_tam CHECK (length(idempotency_key) BETWEEN 1 AND 120),
  CONSTRAINT kz_command_receipts_acao_tam CHECK (length(action) BETWEEN 1 AND 120)
);
CREATE UNIQUE INDEX IF NOT EXISTS kz_command_receipts_por_chave ON crm.kz_command_receipts (workspace_id, idempotency_key);

ALTER TABLE crm.kz_command_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_command_receipts FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_command_receipts' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_command_receipts USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT ON crm.kz_command_receipts TO crm_app;
-- recibo de idempotencia e imutavel: resposta gravada uma unica vez.

CREATE TABLE IF NOT EXISTS crm.kz_outbox_events (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  type text NOT NULL,
  aggregate_id text NOT NULL,
  dedupe_key text NOT NULL,
  actor_id text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT kz_outbox_events_pk PRIMARY KEY (workspace_id, id),
  CONSTRAINT kz_outbox_events_tipo_fmt CHECK (type ~ '^kz\.[a-z0-9_-]+(\.[a-z0-9_-]+)+$'),
  CONSTRAINT kz_outbox_events_agregado_tam CHECK (length(aggregate_id) BETWEEN 1 AND 200),
  CONSTRAINT kz_outbox_events_dedupe_tam CHECK (length(dedupe_key) BETWEEN 1 AND 200)
);
CREATE UNIQUE INDEX IF NOT EXISTS kz_outbox_events_por_dedupe ON crm.kz_outbox_events (workspace_id, dedupe_key);
CREATE INDEX IF NOT EXISTS kz_outbox_events_por_tipo ON crm.kz_outbox_events (workspace_id, type, created_at);

ALTER TABLE crm.kz_outbox_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_outbox_events FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_outbox_events' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_outbox_events USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT ON crm.kz_outbox_events TO crm_app;
-- evento de outbox e imutavel (dedupe por chave unica, sem reescrita).

CREATE TABLE IF NOT EXISTS crm.kz_audit_events (
  workspace_id uuid NOT NULL REFERENCES crm.workspaces(id),
  seq bigint NOT NULL,
  actor_id text NOT NULL,
  action text NOT NULL,
  entity_id text,
  category text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  prev_hash text NOT NULL,
  hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT kz_audit_events_pk PRIMARY KEY (workspace_id, seq),
  CONSTRAINT kz_audit_events_acao_tam CHECK (length(action) BETWEEN 1 AND 120),
  CONSTRAINT kz_audit_events_hash_fmt CHECK (hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT kz_audit_events_prev_fmt CHECK (prev_hash = '' OR prev_hash ~ '^[0-9a-f]{64}$')
);
-- Genesis da cadeia: seq 1 nasce com prev_hash vazio (kz-common, kzAudit).
CREATE INDEX IF NOT EXISTS kz_audit_events_por_data ON crm.kz_audit_events (workspace_id, created_at);

ALTER TABLE crm.kz_audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.kz_audit_events FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'crm' AND tablename = 'kz_audit_events' AND policyname = 'workspace_scope') THEN
    EXECUTE 'CREATE POLICY workspace_scope ON crm.kz_audit_events USING (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid) WITH CHECK (workspace_id = nullif(current_setting(''app.workspace_id'', true), '''')::uuid)';
  END IF;
END $$;
GRANT SELECT, INSERT ON crm.kz_audit_events TO crm_app;
-- trilha append-only: nem o owner reescreve historico (trigger abaixo).

-- Gatilho de imutabilidade das tabelas apendice-only (recibos, outbox e
-- auditoria): bloqueia UPDATE e DELETE para QUALQUER papel, inclusive owner.
-- Revisao 2: o grant sem UPDATE ja nega ao crm_app; o gatilho e a segunda
-- barreira contra erro operacional ou grant futuro descuidado.
DO $mig$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'crm' AND p.proname = 'kz_apendice_somente') THEN
    EXECUTE $fn$CREATE FUNCTION crm.kz_apendice_somente() RETURNS trigger AS $body$
    BEGIN
      RAISE EXCEPTION 'tabela apendice-only crm.%: UPDATE/DELETE negado pelo gatilho kz_apendice_somente', TG_TABLE_NAME;
    END $body$ LANGUAGE plpgsql$fn$;
  END IF;
END $mig$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_command_receipts' AND t.tgname = 'kz_recibos_imutavel') THEN
    EXECUTE 'CREATE TRIGGER kz_recibos_imutavel BEFORE UPDATE OR DELETE ON crm.kz_command_receipts FOR EACH ROW EXECUTE FUNCTION crm.kz_apendice_somente()';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_outbox_events' AND t.tgname = 'kz_outbox_imutavel') THEN
    EXECUTE 'CREATE TRIGGER kz_outbox_imutavel BEFORE UPDATE OR DELETE ON crm.kz_outbox_events FOR EACH ROW EXECUTE FUNCTION crm.kz_apendice_somente()';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'crm' AND c.relname = 'kz_audit_events' AND t.tgname = 'kz_auditoria_imutavel') THEN
    EXECUTE 'CREATE TRIGGER kz_auditoria_imutavel BEFORE UPDATE OR DELETE ON crm.kz_audit_events FOR EACH ROW EXECUTE FUNCTION crm.kz_apendice_somente()';
  END IF;
END $$;
