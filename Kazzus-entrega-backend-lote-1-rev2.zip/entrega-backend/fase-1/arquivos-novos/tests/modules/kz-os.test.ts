// Testes do kz-os: criacao com senha cifrada, transicoes de status, checklist,
// pecas, fotos, idempotencia, papeis, flag, RLS e nao-vazamento de segredo.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzOs } from '../../src/modules/kz-os/service.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzChaveDeDadosDeTeste,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let os: KzOs;

before(async () => {
  process.env.KAZZUS_KZ_DATA_KEY = kzChaveDeDadosDeTeste();
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'os', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'os', KZ_DEMO_WS_B);
  os = new KzOs(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
  delete process.env.KAZZUS_KZ_DATA_KEY;
});

test('cria OS com checklist e senha cifrada (sem vazamento)', async () => {
  const criada = (await os.criar(kzDemoA(), {
    device_brand: 'Marca Sintetica',
    device_model: 'Modelo X Sintetico',
    problem_reported: 'Nao liga sintetico',
    device_password: 'padrao123',
    checklist: [{ label: 'Tela sem trinca' }, { label: 'Bateria carrega' }],
    idempotency_key: 'os-1',
  })) as any;
  assert.equal(criada.os_number, 'OS-00001');
  assert.equal(criada.status, 'aberta');
  assert.equal(criada.has_password, true);
  assert.equal('device_password_enc' in criada, false, 'cifra da senha nao pode sair');
  assert.equal(criada.device_password_enc, undefined);

  const detalhe = (await os.detalhe(kzDemoA(), criada.id)) as any;
  assert.equal(detalhe.checklist.length, 2);
  assert.equal(detalhe.checklist[0].position, 1);
  assert.equal(detalhe.checklist[0].done, false);
  assert.equal(detalhe.has_password, true);
  assert.equal('device_password_enc' in detalhe, false);

  // no banco a senha existe cifrada; em evento e auditoria, nao
  const guarda = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const linha = (await tx.query('SELECT device_password_enc FROM crm.kz_service_orders WHERE workspace_id = $1 AND id = $2', [KZ_DEMO_WS_A, criada.id])).rows[0];
    const eventos = (await tx.query('SELECT payload FROM crm.kz_outbox_events WHERE workspace_id = $1 AND aggregate_id = $2', [KZ_DEMO_WS_A, criada.id])).rows;
    const auditoria = (await tx.query('SELECT payload FROM crm.kz_audit_events WHERE workspace_id = $1 AND entity_id = $2', [KZ_DEMO_WS_A, criada.id])).rows;
    return { linha: linha.device_password_enc, eventos, auditoria };
  });
  assert.match(guarda.linha, /^kz1\./);
  for (const e of guarda.eventos) assert.ok(!JSON.stringify(e.payload).includes('padrao123'), 'evento nao pode ter a senha');
  for (const a of guarda.auditoria) assert.ok(!JSON.stringify(a.payload).includes('padrao123'), 'auditoria nao pode ter a senha');
});

test('senha sem chave configurada responde DATA_KEY_REQUIRED', async () => {
  const chave = process.env.KAZZUS_KZ_DATA_KEY;
  delete process.env.KAZZUS_KZ_DATA_KEY;
  await kzErro(
    () =>
      os.criar(kzDemoA(), {
        device_brand: 'Marca Sintetica',
        device_model: 'Modelo Y',
        problem_reported: 'Problema sintetico',
        device_password: 'segredo',
        idempotency_key: 'os-sem-chave',
      }),
    'DATA_KEY_REQUIRED',
    503,
  );
  process.env.KAZZUS_KZ_DATA_KEY = chave;
});

test('fluxo de status com transicoes validas e invalidas', async () => {
  const p = kzDemoA();
  const os1 = (await os.criar(p, { device_brand: 'B', device_model: 'M', problem_reported: 'x sintetico', idempotency_key: 'os-2' })) as any;
  await kzErro(() => os.status(p, os1.id, { status: 'pronta', expected_version: 1, idempotency_key: 'st-x1' }), 'INVALID_STATE', 409);
  const analise = (await os.status(p, os1.id, { status: 'em_analise', expected_version: 1, idempotency_key: 'st-1' })) as any;
  assert.equal(analise.status, 'em_analise');
  const reparo = (await os.status(p, os1.id, { status: 'em_reparo', expected_version: 2, idempotency_key: 'st-2' })) as any;
  assert.equal(reparo.status, 'em_reparo');
  const pronta = (await os.status(p, os1.id, { status: 'pronta', expected_version: 3, idempotency_key: 'st-3' })) as any;
  assert.equal(pronta.status, 'pronta');
  await kzErro(() => os.status(p, os1.id, { status: 'em_analise', expected_version: 4, idempotency_key: 'st-x2' }), 'INVALID_STATE', 409);
  const entregue = (await os.status(p, os1.id, { status: 'entregue', expected_version: 4, idempotency_key: 'st-4' })) as any;
  assert.equal(entregue.status, 'entregue');
  assert.ok(entregue.delivered_at, 'entrega registra data');
  await kzErro(() => os.status(p, os1.id, { status: 'aberta', expected_version: 5, idempotency_key: 'st-x3' }), 'INVALID_STATE', 409);
  // versao errada
  await kzErro(() => os.status(p, os1.id, { status: 'cancelada', expected_version: 99, idempotency_key: 'st-x4' }), 'VERSION_CONFLICT', 409);
});

test('checklist: adicionar, marcar e concorrencia otimista', async () => {
  const p = kzDemoA();
  const os2 = (await os.criar(p, { device_brand: 'B', device_model: 'M', problem_reported: 'y sintetico', idempotency_key: 'os-3' })) as any;
  const add = (await os.checklistAdd(p, os2.id, { items: [{ label: 'Teste de chamada' }, { label: 'Teste de wifi' }], idempotency_key: 'ck-1' })) as any;
  assert.equal(add.adicionados, 2);
  assert.equal(add.posicao_final, 2);
  const detalhe = (await os.detalhe(p, os2.id)) as any;
  const item = detalhe.checklist[0];
  await kzErro(() => os.checklistMarcar(p, os2.id, item.id, { done: true, expected_version: 99, idempotency_key: 'ck-x' }), 'VERSION_CONFLICT', 409);
  const marcado = (await os.checklistMarcar(p, os2.id, item.id, { done: true, expected_version: detalhe.version, idempotency_key: 'ck-2' })) as any;
  assert.equal(marcado.done, true);
  assert.ok(marcado.done_at);
  const desmarcado = (await os.checklistMarcar(p, os2.id, item.id, { done: false, expected_version: detalhe.version + 1, idempotency_key: 'ck-3' })) as any;
  assert.equal(desmarcado.done, false);
  assert.equal(desmarcado.done_at, null);
});

test('diagnostico, pecas e fotos', async () => {
  const p = kzDemoA();
  const os3 = (await os.criar(p, { device_brand: 'B', device_model: 'M', problem_reported: 'z sintetico', idempotency_key: 'os-4' })) as any;
  const diag = (await os.diagnostico(p, os3.id, { diagnosis: 'Defeito na placa sintetico', expected_version: 1, idempotency_key: 'dg-1' })) as any;
  assert.equal(diag.diagnosis, 'Defeito na placa sintetico');
  const peca = (await os.pecas(p, os3.id, { description: 'Conector de carga sintetico', quantity: 1, unit_cost_cents: 1500, cost_source: 'loja', idempotency_key: 'pc-1' })) as any;
  assert.equal(Number(peca.unit_cost_cents), 1500);
  const foto = (await os.fotos(p, os3.id, { kind: 'entrada', storage_ref: 'sintetico/os-foto-1.jpg', idempotency_key: 'ft-1' })) as any;
  assert.equal(foto.kind, 'entrada');
  const detalhe = (await os.detalhe(p, os3.id)) as any;
  assert.equal(detalhe.pecas.length, 1);
  assert.equal(detalhe.fotos.length, 1);
});

test('idempotencia na criacao e senha posterior', async () => {
  const p = kzDemoA();
  const repetida = (await os.criar(p, { device_brand: 'B', device_model: 'M', problem_reported: 'x sintetico', idempotency_key: 'os-2' })) as any;
  assert.equal(repetida.os_number, 'OS-00002');
  await kzErro(
    () => os.criar(p, { device_brand: 'B', device_model: 'M', problem_reported: 'outro sintetico', idempotency_key: 'os-2' }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
  const total = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_service_orders WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  assert.equal(total, 4, 'os-2 nao pode ter criado OS nova');
});

test('papeis e agente; flag desligada; RLS entre lojas', async () => {
  await kzErro(() => os.criar(kzDemoA('sales'), { device_brand: 'B', device_model: 'M', problem_reported: 'vendedor sintetico', idempotency_key: 'os-v' }), 'FORBIDDEN', 403);
  const lista = (await os.listar(kzDemoA('viewer'), {})) as any[];
  assert.ok(Array.isArray(lista));
  await kzErro(() => os.listar(kzAgenteA(), {}), 'FORBIDDEN', 403);

  delete process.env.KAZZUS_KZ_OS;
  await kzErro(() => os.listar(kzDemoA(), {}), 'MODULE_DISABLED', 404);
  await kzErro(() => os.criar(kzDemoA(), { device_brand: 'B', device_model: 'M', problem_reported: 'flag off', idempotency_key: 'os-off' }), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_OS = 'YES';

  const listaB = (await os.listar(kzDemoB(), {})) as any[];
  assert.equal(listaB.length, 0, 'loja B nao ve OS da loja A');
  const primeira = (await os.listar(kzDemoA(), { limit: '1' })) as any[];
  await kzErro(() => os.detalhe(kzDemoB(), primeira[0].id), 'NOT_FOUND', 404);
  await kzErro(
    () => os.status(kzDemoB(), primeira[0].id, { status: 'cancelada', expected_version: Number(primeira[0].version), idempotency_key: 'st-rls' }),
    'NOT_FOUND',
    404,
  );
});

test('numeros sequenciais por loja (contadores independentes)', async () => {
  const osB = (await os.criar(kzDemoB(), { device_brand: 'B2', device_model: 'M2', problem_reported: 'loja B sintetico', idempotency_key: 'os-b1' })) as any;
  assert.equal(osB.os_number, 'OS-00001', 'loja B comeca do 1');
  const osA = (await os.criar(kzDemoA(), { device_brand: 'B', device_model: 'M', problem_reported: 'loja A sintetico', idempotency_key: 'os-a5' })) as any;
  assert.equal(osA.os_number, 'OS-00005');
});
