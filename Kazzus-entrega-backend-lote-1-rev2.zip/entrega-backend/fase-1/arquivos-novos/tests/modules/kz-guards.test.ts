// Testes das guardas de BANCO da Revisao 2 (rodada de revisao externa): grants
// apendice-only, CHECKs de coerencia e gatilhos de defesa em profundidade.
// Tudo com dados sinteticos (R9); roda no validador e na arvore real.

import { randomUUID } from 'node:crypto';
import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KZ_DEMO_WS_A, kzAbrirDb, kzChaveDeDadosDeTeste, kzFecharDb, kzLimparEnv } from './helpers/kz-env.js';

let db: any;

before(async () => {
  process.env.KAZZUS_KZ_DATA_KEY = kzChaveDeDadosDeTeste();
  db = await kzAbrirDb();
  kzLimparEnv();
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
  delete process.env.KAZZUS_KZ_DATA_KEY;
});

function e23514(e: unknown): boolean {
  return (e as { code?: string })?.code === '23514';
}

test('apendice-only: crm_app nao tem UPDATE nem DELETE nas 4 tabelas (42501)', async () => {
  // uma linha em cada tabela para o teste nao depender de catalogo
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await tx.query(
      "INSERT INTO crm.kz_command_receipts (workspace_id, action, idempotency_key, actor_id, request_hash, response) VALUES ($1, 'kz.guards', 'guards-r-1', 'kz-guards', $2, '{}')",
      [KZ_DEMO_WS_A, 'a'.repeat(64)],
    );
    await tx.query(
      "INSERT INTO crm.kz_outbox_events (workspace_id, type, aggregate_id, dedupe_key, actor_id, payload) VALUES ($1, 'kz.guards.evento', 'agg-1', 'kz.guards:1', 'kz-guards', '{}')",
      [KZ_DEMO_WS_A],
    );
    await tx.query(
      "INSERT INTO crm.kz_audit_events (workspace_id, seq, actor_id, action, payload, prev_hash, hash) VALUES ($1, 1, 'kz-guards', 'kz.guards.auditoria', '{}', '', $2)",
      [KZ_DEMO_WS_A, '0'.repeat(64)],
    );
    await tx.query("INSERT INTO crm.kz_stepup_attempts (workspace_id, actor_id, ok) VALUES ($1, 'kz-guards', false)", [KZ_DEMO_WS_A]);
  });
  const casos: Array<[string, string]> = [
    ['kz_command_receipts', 'UPDATE crm.kz_command_receipts SET actor_id = actor_id'],
    ['kz_command_receipts', 'DELETE FROM crm.kz_command_receipts'],
    ['kz_outbox_events', 'UPDATE crm.kz_outbox_events SET actor_id = actor_id'],
    ['kz_outbox_events', 'DELETE FROM crm.kz_outbox_events'],
    ['kz_audit_events', 'UPDATE crm.kz_audit_events SET actor_id = actor_id'],
    ['kz_audit_events', 'DELETE FROM crm.kz_audit_events'],
    ['kz_stepup_attempts', 'UPDATE crm.kz_stepup_attempts SET ok = ok'],
    ['kz_stepup_attempts', 'DELETE FROM crm.kz_stepup_attempts'],
  ];
  for (const [tabela, sql] of casos) {
    await assert.rejects(
      () => db.workspace(KZ_DEMO_WS_A, async (tx: any) => void (await tx.query(sql))),
      (e: unknown) => (e as { code?: string })?.code === '42501',
      `${tabela}: ${sql.split(' ')[0]} precisa ser negado ao crm_app`,
    );
  }
});

test('pagamento misto: CHECK da equacao nega conjunto incoerente (23514)', async () => {
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_payment_sets (workspace_id, order_kind, order_id, order_total_cents, payments_total_cents, change_cents, created_by) VALUES ($1, 'order', $2, 10000, 9000, 0, 'kz-guards')",
          [KZ_DEMO_WS_A, randomUUID()],
        );
      }),
    e23514,
  );
});

test('pagamento misto: parcelas so em credito/crediario no banco (23514)', async () => {
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        const set = (
          await tx.query(
            "INSERT INTO crm.kz_payment_sets (workspace_id, order_kind, order_id, order_total_cents, payments_total_cents, change_cents, created_by) VALUES ($1, 'order', $2, 10000, 10000, 0, 'kz-guards') RETURNING id",
            [KZ_DEMO_WS_A, randomUUID()],
          )
        ).rows[0];
        await tx.query(
          "INSERT INTO crm.kz_payment_splits (workspace_id, set_id, split_index, method, amount_cents, installments, created_by) VALUES ($1, $2, 1, 'dinheiro', 10000, 3, 'kz-guards')",
          [KZ_DEMO_WS_A, set.id],
        );
      }),
    e23514,
  );
});

test('pagamento misto: soma dos splits difere do total derruba o COMMIT (gatilho diferido)', async () => {
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        const set = (
          await tx.query(
            "INSERT INTO crm.kz_payment_sets (workspace_id, order_kind, order_id, order_total_cents, payments_total_cents, change_cents, created_by) VALUES ($1, 'order', $2, 10000, 10000, 0, 'kz-guards') RETURNING id",
            [KZ_DEMO_WS_A, randomUUID()],
          )
        ).rows[0];
        await tx.query(
          "INSERT INTO crm.kz_payment_splits (workspace_id, set_id, split_index, method, amount_cents, created_by) VALUES ($1, $2, 1, 'dinheiro', 6000, 'kz-guards')",
          [KZ_DEMO_WS_A, set.id],
        );
        await tx.query(
          "INSERT INTO crm.kz_payment_splits (workspace_id, set_id, split_index, method, amount_cents, created_by) VALUES ($1, $2, 2, 'pix', 3000, 'kz-guards')",
          [KZ_DEMO_WS_A, set.id],
        );
      }),
    (e: unknown) => /soma dos splits/i.test(String((e as { message?: string })?.message ?? '')),
  );
});

test('caixa: status e fechamento coerentes; movimento so em sessao aberta', async () => {
  // fechada sem closed_at
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_cash_sessions (workspace_id, opening_cents, status, opened_by, created_by) VALUES ($1, 1000, 'fechada', 'kz-guards', 'kz-guards')",
          [KZ_DEMO_WS_A],
        );
      }),
    e23514,
  );
  // sessao aberta persistida para os proximos passos
  const sessao = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          "INSERT INTO crm.kz_cash_sessions (workspace_id, opening_cents, status, opened_by, created_by) VALUES ($1, 1000, 'aberta', 'kz-guards', 'kz-guards') RETURNING id",
          [KZ_DEMO_WS_A],
        )
      ).rows[0];
    })
  ).id;
  // diferenca que nao bate com contado - esperado
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          `UPDATE crm.kz_cash_sessions SET status = 'fechada', closed_at = now(), closed_by = 'kz-guards',
             counted_cents = 500, expected_cents = 700, difference_cents = 999
           WHERE workspace_id = $1 AND id = $2`,
          [KZ_DEMO_WS_A, sessao],
        );
      }),
    e23514,
  );
  // fechamento coerente passa, e movimento na sessao fechada derruba no gatilho
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await tx.query(
      `UPDATE crm.kz_cash_sessions SET status = 'fechada', closed_at = now(), closed_by = 'kz-guards',
         counted_cents = 1000, expected_cents = 1000, difference_cents = 0, version = 2
       WHERE workspace_id = $1 AND id = $2`,
      [KZ_DEMO_WS_A, sessao],
    );
  });
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_cash_movements (workspace_id, session_id, type, amount_cents, reason, created_by) VALUES ($1, $2, 'sangria', 100, 'forca o gatilho', 'kz-guards')",
          [KZ_DEMO_WS_A, sessao],
        );
      }),
    (e: unknown) => /sessao aberta/i.test(String((e as { message?: string })?.message ?? '')),
  );
});

test('os: entrega coerente, foto com ref fechada e filha so em ordem ativa', async () => {
  // entregue sem delivered_at
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_service_orders (workspace_id, os_number, device_brand, device_model, problem_reported, status, created_by) VALUES ($1, 'OS-90001', 'B', 'M', 'sintetico', 'entregue', 'kz-guards')",
          [KZ_DEMO_WS_A],
        );
      }),
    e23514,
  );
  // storage_ref com ..
  const ativa = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          "INSERT INTO crm.kz_service_orders (workspace_id, os_number, device_brand, device_model, problem_reported, created_by) VALUES ($1, 'OS-90002', 'B', 'M', 'sintetico', 'kz-guards') RETURNING id",
          [KZ_DEMO_WS_A],
        )
      ).rows[0];
    })
  ).id;
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_service_order_photos (workspace_id, order_id, kind, storage_ref, created_by) VALUES ($1, $2, 'entrada', '../../etc/senha', 'kz-guards')",
          [KZ_DEMO_WS_A, ativa],
        );
      }),
    e23514,
  );
  // checklist marcado sem done_at
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_service_order_checklists (workspace_id, order_id, label, position, done, created_by) VALUES ($1, $2, 'item', 1, true, 'kz-guards')",
          [KZ_DEMO_WS_A, ativa],
        );
      }),
    e23514,
  );
  // peca/foto em OS entregue derruba no gatilho
  const entregue = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          "INSERT INTO crm.kz_service_orders (workspace_id, os_number, device_brand, device_model, problem_reported, status, delivered_at, created_by) VALUES ($1, 'OS-90003', 'B', 'M', 'sintetico', 'entregue', now(), 'kz-guards') RETURNING id",
          [KZ_DEMO_WS_A],
        )
      ).rows[0];
    })
  ).id;
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_service_order_photos (workspace_id, order_id, kind, storage_ref, created_by) VALUES ($1, $2, 'entrada', 'sintetico/foto.jpg', 'kz-guards')",
          [KZ_DEMO_WS_A, entregue],
        );
      }),
    (e: unknown) => /ordem ativa/i.test(String((e as { message?: string })?.message ?? '')),
  );
});

test('usados: decisao, unidade na aprovacao, checklist lista e termo imutavel', async () => {
  const base = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          `INSERT INTO crm.kz_tradein_evaluations (workspace_id, eval_number, device_brand, device_model, grade, checklist, created_by)
           VALUES ($1, 'AT-90001', 'B', 'M', 'A', '[{"label":"Liga","ok":true}]', 'kz-guards') RETURNING id`,
          [KZ_DEMO_WS_A],
        )
      ).rows[0];
    })
  ).id;
  // aprovada sem stocked_unit_ref
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "UPDATE crm.kz_tradein_evaluations SET status = 'aprovada', decided_at = now(), decided_by = 'kz-guards' WHERE workspace_id = $1 AND id = $2",
          [KZ_DEMO_WS_A, base],
        );
      }),
    e23514,
  );
  // decisao sem sair de 'avaliada'
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query("UPDATE crm.kz_tradein_evaluations SET decided_at = now() WHERE workspace_id = $1 AND id = $2", [KZ_DEMO_WS_A, base]);
      }),
    e23514,
  );
  // checklist que nao e lista
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          `INSERT INTO crm.kz_tradein_evaluations (workspace_id, eval_number, device_brand, device_model, grade, checklist, created_by)
           VALUES ($1, 'AT-90002', 'B', 'M', 'A', '{"label":"Liga"}', 'kz-guards')`,
          [KZ_DEMO_WS_A],
        );
      }),
    e23514,
  );
  // termo: texto gerado uma vez e imutavel (gatilho), aceite continua permitido
  const termo = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          `INSERT INTO crm.kz_tradein_terms (workspace_id, evaluation_id, rendered_text, created_by)
           VALUES ($1, $2, $3, 'kz-guards') RETURNING id`,
          [KZ_DEMO_WS_A, base, 'T'.repeat(300)],
        )
      ).rows[0];
    })
  ).id;
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query("UPDATE crm.kz_tradein_terms SET rendered_text = $1 WHERE workspace_id = $2 AND id = $3", [
          'X'.repeat(300),
          KZ_DEMO_WS_A,
          termo,
        ]);
      }),
    (e: unknown) => /imutavel/i.test(String((e as { message?: string })?.message ?? '')),
  );
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await tx.query("UPDATE crm.kz_tradein_terms SET accepted_at = now(), version = 2 WHERE workspace_id = $1 AND id = $2", [
      KZ_DEMO_WS_A,
      termo,
    ]);
  });
});

test('crediario: pago, vinculo, quitado e cancelado coerentes no banco', async () => {
  const plano = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          `INSERT INTO crm.kz_credit_plans (workspace_id, plan_number, contact_id, total_cents, installments_count, first_due, created_by)
           VALUES ($1, 'CR-90001', $2, 10000, 2, CURRENT_DATE, 'kz-guards') RETURNING id`,
          [KZ_DEMO_WS_A, randomUUID()],
        )
      ).rows[0];
    })
  ).id;
  // pago > total
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query("UPDATE crm.kz_credit_plans SET paid_cents = 20000 WHERE workspace_id = $1 AND id = $2", [KZ_DEMO_WS_A, plano]);
      }),
    e23514,
  );
  // quitado sem pagar tudo
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query("UPDATE crm.kz_credit_plans SET status = 'quitado' WHERE workspace_id = $1 AND id = $2", [KZ_DEMO_WS_A, plano]);
      }),
    e23514,
  );
  // vinculo incoerente (order_kind sem order_id)
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          `INSERT INTO crm.kz_credit_plans (workspace_id, plan_number, contact_id, total_cents, installments_count, first_due, order_kind, created_by)
           VALUES ($1, 'CR-90002', $2, 10000, 2, CURRENT_DATE, 'order', 'kz-guards')`,
          [KZ_DEMO_WS_A, randomUUID()],
        );
      }),
    e23514,
  );
  // parcela paga sem data/autor
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_credit_installments (workspace_id, plan_id, number, due_date, amount_cents, status, paid_cents, created_by) VALUES ($1, $2, 1, CURRENT_DATE, 5000, 'paga', 5000, 'kz-guards')",
          [KZ_DEMO_WS_A, plano],
        );
      }),
    e23514,
  );
});

test('seguranca: concessao com prazo e uso coerentes', async () => {
  // expires_at antes de created_at
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_stepup_grants (workspace_id, actor_id, purpose, expires_at, created_at, created_by) VALUES ($1, 'kz-guards', 'estorno', now() - interval '1 minute', now(), 'kz-guards')",
          [KZ_DEMO_WS_A],
        );
      }),
    e23514,
  );
  // us sem used_at
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
        await tx.query(
          "INSERT INTO crm.kz_stepup_grants (workspace_id, actor_id, purpose, expires_at, used, created_by) VALUES ($1, 'kz-guards', 'estorno', now() + interval '5 minutes', true, 'kz-guards')",
          [KZ_DEMO_WS_A],
        );
      }),
    e23514,
  );
});
