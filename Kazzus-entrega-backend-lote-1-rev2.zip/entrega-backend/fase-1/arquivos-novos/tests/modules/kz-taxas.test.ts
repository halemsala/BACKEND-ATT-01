// Testes do kz-taxas: cadastro, concorrencia otimista, idempotencia, simulacao com
// matematica inteira, papeis, flag e isolamento RLS.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzTaxas } from '../../src/modules/kz-taxas/service.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let taxas: KzTaxas;

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'taxas', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'taxas', KZ_DEMO_WS_B);
  taxas = new KzTaxas(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('cadastro e edicao com concorrencia otimista', async () => {
  const p = kzDemoA();
  const criada = (await taxas.set(p, { brand: 'visa', installments: 1, percent: 3.99, idempotency_key: 'taxa-1' })) as any;
  assert.equal(Number(criada.version), 1);
  await kzErro(
    () => taxas.set(p, { brand: 'visa', installments: 1, percent: 4.5, idempotency_key: 'taxa-2' }),
    'VERSION_CONFLICT',
    409,
  );
  const editada = (await taxas.set(p, { brand: 'visa', installments: 1, percent: 4.11, expected_version: 1, idempotency_key: 'taxa-3' })) as any;
  assert.equal(Number(editada.version), 2);
  assert.equal(Number(editada.percent), 4.11);
});

test('idempotencia na taxa', async () => {
  const repetida = (await taxas.set(kzDemoA(), { brand: 'visa', installments: 1, percent: 4.11, expected_version: 1, idempotency_key: 'taxa-3' })) as any;
  assert.equal(Number(repetida.version), 2);
  await kzErro(
    () => taxas.set(kzDemoA(), { brand: 'visa', installments: 1, percent: 9.99, expected_version: 1, idempotency_key: 'taxa-3' }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
});

test('simulacao com matematica inteira exata', async () => {
  await taxas.set(kzDemoA(), { brand: 'visa', installments: 3, percent: 3.99, fixed_cents: 20, idempotency_key: 'taxa-4' });
  const sim = (await taxas.simular(kzDemoA(), { price_cents: 99900, brand: 'visa', installments: 3, cost_cents: 70000 })) as any;
  // taxa = floor(99900 * 399 / 10000) + 20 = 3986 + 20
  assert.equal(sim.fee_cents, 4006);
  assert.equal(sim.liquid_cents, 95894);
  assert.deepEqual(sim.installments_cents, [33300, 33300, 33300]);
  assert.equal(sim.lucro_real_cents, 25894);
  const sim1x = (await taxas.simular(kzDemoA(), { price_cents: 99900, brand: 'visa', installments: 1 })) as any;
  // visa 1x foi editada para 4.11% no primeiro teste: floor(99900 * 411 / 10000) = 4105
  assert.equal(sim1x.fee_cents, 4105);
  assert.equal(sim1x.liquid_cents, 95795);
  assert.equal(sim1x.lucro_real_cents, null, 'sem custo informado nao ha lucro');
  // divisao com resto
  const simResto = (await taxas.simular(kzDemoA(), { price_cents: 10000, brand: 'visa', installments: 3 })) as any;
  assert.deepEqual(simResto.installments_cents, [3334, 3333, 3333]);
});

test('simulacao nao grava nada (guarda de preco R1)', async () => {
  const antes = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_card_fee_tables WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  for (let i = 0; i < 3; i++) {
    await taxas.simular(kzDemoA(), { price_cents: 50000, brand: 'visa', installments: 1 });
  }
  const depois = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_card_fee_tables WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  assert.equal(antes, depois, 'simulacao nao pode gravar linhas');
});

test('taxa inexistente ou inativa na simulacao', async () => {
  await kzErro(() => taxas.simular(kzDemoA(), { price_cents: 1000, brand: 'naoexiste', installments: 1 }), 'FEE_NOT_FOUND', 404);
  const inativa = (await taxas.set(kzDemoA(), { brand: 'elo', installments: 1, percent: 2, active: false, idempotency_key: 'taxa-5' })) as any;
  assert.equal(inativa.active, false);
  await kzErro(() => taxas.simular(kzDemoA(), { price_cents: 1000, brand: 'elo', installments: 1 }), 'FEE_NOT_FOUND', 404);
});

test('arquivar libera o cadastro de nova taxa ativa', async () => {
  const p = kzDemoA();
  const lista = (await taxas.listar(p, { brand: 'visa' })) as any[];
  const ativa = lista.find((t: any) => t.installments === 1 && t.active) as any;
  await kzErro(
    () => taxas.arquivar(p, ativa.id, { expected_version: 99, idempotency_key: 'arq-x' }),
    'VERSION_CONFLICT',
    409,
  );
  const arquivada = (await taxas.arquivar(p, ativa.id, { expected_version: Number(ativa.version), idempotency_key: 'arq-1' })) as any;
  assert.equal(arquivada.active, false);
  const nova = (await taxas.set(p, { brand: 'visa', installments: 1, percent: 3.5, idempotency_key: 'taxa-6' })) as any;
  assert.equal(Number(nova.version), 1, 'nova linha ativa apos arquivar a antiga');
  await kzErro(() => taxas.arquivar(p, ativa.id, { expected_version: 1, idempotency_key: 'arq-2' }), 'NOT_FOUND', 404);
});

test('papeis: vendedor consulta e simula, mas nao edita; agente bloqueado', async () => {
  const lista = (await taxas.listar(kzDemoA('sales'), {})) as any[];
  assert.ok(Array.isArray(lista));
  await taxas.simular(kzDemoA('sales'), { price_cents: 1000, brand: 'visa', installments: 1 });
  await kzErro(() => taxas.set(kzDemoA('sales'), { brand: 'amex', installments: 1, percent: 5, idempotency_key: 'taxa-s' }), 'FORBIDDEN', 403);
  await kzErro(() => taxas.listar(kzAgenteA(), {}), 'FORBIDDEN', 403);
});

test('flag desligada responde MODULE_DISABLED', async () => {
  delete process.env.KAZZUS_KZ_TAXAS;
  await kzErro(() => taxas.listar(kzDemoA(), {}), 'MODULE_DISABLED', 404);
  await kzErro(() => taxas.simular(kzDemoA(), { price_cents: 1000, brand: 'visa', installments: 1 }), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_TAXAS = 'YES';
});

test('isolamento entre lojas (RLS): taxas da loja A nao aparecem na loja B', async () => {
  const listaB = (await taxas.listar(kzDemoB(), {})) as any[];
  assert.equal(listaB.length, 0);
  await kzErro(() => taxas.simular(kzDemoB(), { price_cents: 1000, brand: 'visa', installments: 1 }), 'FEE_NOT_FOUND', 404);
});
