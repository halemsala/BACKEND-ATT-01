// Testes do kz-common: idempotencia, dedupe de eventos, trilha de auditoria
// encadeada, redacao de segredos, criptografia, dinheiro e papeis.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import {
  DomainError,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzDecryptSecret,
  kzEncryptSecret,
  kzEvent,
  kzFormatBRL,
  kzRedact,
  kzReady,
  kzSameVersion,
  kzSha256,
  kzSplitCents,
  kzStableStringify,
  kzTodayISO,
  kzValidImei,
  kzVerifyAuditChain,
} from '../../src/modules/kz-common.js';
import { kzNextCounter } from '../../src/modules/kz-flags.js';
import { KZ_DEMO_WS_A, KZ_DEMO_WS_B, kzAbrirDb, kzChaveDeDadosDeTeste, kzDemoA, kzDemoB, kzErro, kzFecharDb, kzLimparEnv } from './helpers/kz-env.js';

let db: any;

before(async () => {
  process.env.KAZZUS_KZ_DATA_KEY = kzChaveDeDadosDeTeste();
  db = await kzAbrirDb();
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
  delete process.env.KAZZUS_KZ_DATA_KEY;
});

test('idempotencia: mesma chave devolve o mesmo resultado sem reexecutar', async () => {
  const p = kzDemoA();
  const primeira = await db.workspace(KZ_DEMO_WS_A, (tx: any) =>
    kzCommand(tx, p, 'kz.teste.comando', 'chave-comum-1', { a: 1 }, async () => kzNextCounter(tx, KZ_DEMO_WS_A, 'comum-teste')),
  );
  assert.equal(primeira, 1);
  const repetida = await db.workspace(KZ_DEMO_WS_A, (tx: any) =>
    kzCommand(tx, p, 'kz.teste.comando', 'chave-comum-1', { a: 1 }, async () => kzNextCounter(tx, KZ_DEMO_WS_A, 'comum-teste')),
  );
  assert.equal(repetida, 1);
  const valor = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const row = (await tx.query('SELECT value FROM crm.kz_counters WHERE workspace_id = $1 AND name = $2', [KZ_DEMO_WS_A, 'comum-teste'])).rows[0];
    return Number(row.value);
  });
  assert.equal(valor, 1, 'o contador so pode ter avancado uma vez');
});

test('idempotencia: mesma chave com outro input gera IDEMPOTENCY_CONFLICT', async () => {
  const p = kzDemoA();
  await kzErro(
    () =>
      db.workspace(KZ_DEMO_WS_A, (tx: any) =>
        kzCommand(tx, p, 'kz.teste.comando', 'chave-comum-1', { a: 2 }, async () => 99),
      ),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
});

test('evento: dedupe por (workspace, dedupe_key) grava uma unica vez', async () => {
  const p = kzDemoA();
  const grava = () =>
    db.workspace(KZ_DEMO_WS_A, (tx: any) =>
      kzEvent(tx, p, 'kz.teste.evento', 'agregado-1', 'kz.teste.evento:1', { a: 1 }),
    );
  await grava();
  await grava();
  const total = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const row = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_outbox_events WHERE workspace_id = $1 AND dedupe_key = $2', [KZ_DEMO_WS_A, 'kz.teste.evento:1'])).rows[0];
    return row.c;
  });
  assert.equal(total, 1);
});

test('auditoria: trilha encadeada fecha e deteccao de adulteracao', async () => {
  const p = kzDemoB();
  for (const acao of ['kz.teste.a', 'kz.teste.b', 'kz.teste.c']) {
    await db.workspace(KZ_DEMO_WS_B, (tx: any) =>
      kzAudit(tx, { workspaceId: KZ_DEMO_WS_B, actorId: p.actorId, action: acao, entityId: 'ent-1', payload: { modulo: acao, habilitado: true } }),
    );
  }
  const ok = await db.workspace(KZ_DEMO_WS_B, (tx: any) => kzVerifyAuditChain(tx, KZ_DEMO_WS_B));
  assert.equal(ok.ok, true);
  assert.equal(ok.checked, 3);
  // Revisao 2: a trilha e apendice-only - UPDATE como crm_app e negado (42501),
  // entao a adulteracao por reescrita nem comeca.
  await assert.rejects(
    () =>
      db.workspace(KZ_DEMO_WS_B, async (tx: any) => {
        await tx.query('UPDATE crm.kz_audit_events SET payload = $1::jsonb WHERE workspace_id = $2 AND seq = 2', [
          '{"fraude":true}',
          KZ_DEMO_WS_B,
        ]);
      }),
    (e: any) => e?.code === '42501',
  );
  // A deteccao de quebra continua provada: INSERT e permitido (apendice), e um
  // elo incluido com prev_hash errado derruba a verificacao no ponto exato.
  await db.workspace(KZ_DEMO_WS_B, async (tx: any) => {
    await tx.query(
      'INSERT INTO crm.kz_audit_events (workspace_id, seq, actor_id, action, payload, prev_hash, hash) VALUES ($1, 4, $2, $3, $4::jsonb, $5, $6)',
      [KZ_DEMO_WS_B, p.actorId, 'kz.teste.fraude', '{}', '0'.repeat(64), '1'.repeat(64)],
    );
  });
  const quebrada = await db.workspace(KZ_DEMO_WS_B, (tx: any) => kzVerifyAuditChain(tx, KZ_DEMO_WS_B));
  assert.equal(quebrada.ok, false);
  assert.equal(quebrada.broken_seq, 4);
});

test('redacao: segredos nunca chegam a evento ou auditoria', async () => {
  const objeto = { senha: '4321', aninhado: { device_password: 'padrao123', valor: 10 }, pin: '99', nome: 'sintetico' };
  const limpo = kzRedact(objeto) as any;
  assert.equal(limpo.senha, '[redatado]');
  assert.equal(limpo.aninhado.device_password, '[redatado]');
  assert.equal(limpo.aninhado.valor, 10);
  assert.equal(limpo.pin, '[redatado]');
  assert.equal(limpo.nome, 'sintetico');
});

test('splitCents divide centavos sem erro de ponto flutuante', () => {
  assert.deepEqual(kzSplitCents(10000, 3), [3334, 3333, 3333]);
  assert.deepEqual(kzSplitCents(100, 3), [34, 33, 33]);
  assert.deepEqual(kzSplitCents(0, 5), [0, 0, 0, 0, 0]);
  assert.deepEqual(kzSplitCents(999, 2), [500, 499]);
  assert.equal(kzSplitCents(10000, 3).reduce((a, b) => a + b, 0), 10000);
});

test('Luhn valida IMEI de 15 digitos', () => {
  assert.equal(kzValidImei('123456789012347'), true);
  assert.equal(kzValidImei('123456789012348'), false);
  assert.equal(kzValidImei('12345678901234'), false);
  assert.equal(kzValidImei('1234567890123a7'), false);
});

test('formato de moeda e data local', () => {
  assert.equal(kzFormatBRL(1234567), '12.345,67');
  assert.equal(kzFormatBRL(5), '0,05');
  assert.equal(kzFormatBRL(-150), '-1,50');
  assert.match(kzTodayISO(), /^\d{4}-\d{2}-\d{2}$/);
});

test('criptografia AES-256-GCM: ida e volta com a chave de teste', () => {
  const cifrado = kzEncryptSecret('senhaDoAparelho#123');
  assert.match(cifrado, /^kz1\./);
  assert.notEqual(cifrado, 'senhaDoAparelho#123');
  assert.equal(kzDecryptSecret(cifrado), 'senhaDoAparelho#123');
  const cifrado2 = kzEncryptSecret('senhaDoAparelho#123');
  assert.notEqual(cifrado, cifrado2, 'iv aleatorio produz cifras distintas');
});

test('criptografia: adulteracao e chave ausente falham', async () => {
  const cifrado = kzEncryptSecret('segredo');
  const adulterado = cifrado.slice(0, -4) + (cifrado.endsWith('AAA=') ? 'BBB=' : 'AAA=');
  await assert.rejects(() => Promise.resolve().then(() => kzDecryptSecret(adulterado)));
  delete process.env.KAZZUS_KZ_DATA_KEY;
  await kzErro(() => Promise.resolve().then(() => kzEncryptSecret('x')), 'DATA_KEY_REQUIRED', 503);
  process.env.KAZZUS_KZ_DATA_KEY = 'curta';
  await kzErro(() => Promise.resolve().then(() => kzEncryptSecret('x')), 'DATA_KEY_INVALID', 503);
  process.env.KAZZUS_KZ_DATA_KEY = kzChaveDeDadosDeTeste();
});

test('papeis: escrita kz so para operator/admin; agentes nunca', async () => {
  const casos: Array<[string | undefined, string | undefined, boolean]> = [
    ['operator', undefined, true],
    ['admin', undefined, true],
    ['sales', undefined, false],
    ['manager', undefined, false],
    ['support', undefined, false],
    ['viewer', undefined, false],
    ['agent', 'kz-agente-1', false],
    ['simulator-finance', undefined, false],
  ];
  for (const [role, agentId, devePassar] of casos) {
    const p = { workspaceId: KZ_DEMO_WS_A, actorId: 'kz-papel', role, agentId };
    if (devePassar) {
      kzAssertWrite(p, 'POST', '/kz/teste');
    } else {
      await kzErro(async () => kzAssertWrite(p, 'POST', '/kz/teste'), 'FORBIDDEN', 403);
    }
  }
  await kzErro(async () => kzAssertRead({ workspaceId: KZ_DEMO_WS_A, actorId: 'a', role: 'agent', agentId: 'x' }), 'FORBIDDEN', 403);
  kzAssertRead(kzDemoA('viewer'));
});

test('concorrencia otimista: kzSameVersion', async () => {
  kzSameVersion({ version: 3 }, 3);
  await kzErro(async () => kzSameVersion({ version: 3 }, 2), 'VERSION_CONFLICT', 409);
  await kzErro(async () => kzSameVersion({ version: 3 }, undefined), 'VERSION_CONFLICT', 409);
});

test('migracao ausente: kzReady responde <MODULO>_MIGRATION_REQUIRED', async () => {
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await kzErro(() => kzReady(tx, 'kz_tabela_que_nao_existe', 'KZ_TESTE'), 'KZ_TESTE_MIGRATION_REQUIRED', 503);
  });
});

test('serializacao estavel e hash', () => {
  assert.equal(kzStableStringify({ b: 1, a: { d: 2, c: 3 } }), '{"a":{"c":3,"d":2},"b":1}');
  assert.equal(kzSha256('kazzus').length, 64);
  assert.ok(new DomainError('TESTE') instanceof DomainError);
  assert.equal(new DomainError('TESTE').status, 409);
});
