// Testes do kz-flags: plano de controle (flags por processo e por loja), ajustes,
// contadores, papeis, idempotencia, concorrencia otimista e isolamento RLS.

import { after, before, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzFlags, kzModuleEnabled, kzNextCounter, kzRequireModule } from '../../src/modules/kz-flags.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';

let db: any;
let flags: KzFlags;

before(async () => {
  db = await (await import('./helpers/kz-env.js')).kzAbrirDb();
  flags = new KzFlags(db);
});

beforeEach(() => {
  kzLimparEnv();
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('lista inicial: tudo desligado por padrao', async () => {
  const saida = (await flags.list(kzDemoA())) as any;
  assert.equal(saida.automations_enabled, false);
  for (const m of saida.modules) {
    assert.equal(m.enabled, false, `modulo ${m.module} deve comecar desligado`);
    assert.equal(m.store_enabled, false);
  }
});

test('habilitar exige processo E loja (sem ellipsis AND)', async () => {
  process.env.KAZZUS_KZ_CAIXA = 'YES';
  let habilitado = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzModuleEnabled(tx, KZ_DEMO_WS_A, 'caixa'));
  assert.equal(habilitado, false, 'sem linha na loja continua desligado');
  await flags.set(kzDemoA(), { module: 'caixa', enabled: true, idempotency_key: 'flags-1' });
  habilitado = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzModuleEnabled(tx, KZ_DEMO_WS_A, 'caixa'));
  assert.equal(habilitado, true);
  delete process.env.KAZZUS_KZ_CAIXA;
  habilitado = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzModuleEnabled(tx, KZ_DEMO_WS_A, 'caixa'));
  assert.equal(habilitado, false, 'sem flag de processo continua desligado');
});

test('kzRequireModule lanca MODULE_DISABLED com o modulo desligado', async () => {
  await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    await kzErro(() => kzRequireModule(tx, KZ_DEMO_WS_A, 'caixa'), 'MODULE_DISABLED', 404);
  });
});

test('escrita so para operator/admin; agentes bloqueados ate na leitura', async () => {
  await kzErro(() => flags.set(kzDemoA('viewer'), { module: 'taxas', enabled: true, idempotency_key: 'flags-v' }), 'FORBIDDEN', 403);
  await kzErro(() => flags.set(kzDemoA('sales'), { module: 'taxas', enabled: true, idempotency_key: 'flags-s' }), 'FORBIDDEN', 403);
  await kzErro(() => flags.list(kzAgenteA()), 'FORBIDDEN', 403);
  await flags.set(kzDemoA('admin'), { module: 'taxas', enabled: true, idempotency_key: 'flags-a' });
});

test('concorrencia otimista na linha de flag e idempotencia', async () => {
  const linha = (await flags.set(kzDemoA(), { module: 'os', enabled: true, idempotency_key: 'flags-os-1' })) as any;
  assert.equal(linha.version, 1);
  await kzErro(
    () => flags.set(kzDemoA(), { module: 'os', enabled: false, expected_version: 99, idempotency_key: 'flags-os-2' }),
    'VERSION_CONFLICT',
    409,
  );
  const atualizada = (await flags.set(kzDemoA(), { module: 'os', enabled: false, expected_version: 1, idempotency_key: 'flags-os-3' })) as any;
  assert.equal(atualizada.version, 2);
  // mesma chave e mesmo input: devolve o mesmo recibo sem bumpar de novo
  const repetida = (await flags.set(kzDemoA(), { module: 'os', enabled: false, expected_version: 1, idempotency_key: 'flags-os-3' })) as any;
  assert.equal(repetida.version, 2);
  await kzErro(
    () => flags.set(kzDemoA(), { module: 'os', enabled: true, expected_version: 1, idempotency_key: 'flags-os-3' }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
});

test('validacao: modulo desconhecido e campos extras rejeitados', async () => {
  await kzErro(() => flags.set(kzDemoA(), { module: 'nao-existe', enabled: true, idempotency_key: 'flags-x' }), 'ZodError');
  await kzErro(() => flags.set(kzDemoA(), { module: 'caixa', enabled: true, idempotency_key: 'flags-y', extra: 1 }), 'ZodError');
});

test('ajustes da loja: definir, listar, ler e atualizar', async () => {
  await flags.setSetting(kzDemoA(), { key: 'store_name', value: 'Loja Sintetica A', idempotency_key: 'set-1' });
  const lista = (await flags.listSettings(kzDemoA())) as any[];
  assert.equal(lista.length, 1);
  assert.equal(lista[0].key, 'store_name');
  const uma = (await flags.getSetting(kzDemoA(), 'store_name')) as any;
  assert.equal(uma.value, 'Loja Sintetica A');
  await kzErro(() => flags.getSetting(kzDemoA(), 'nao_existe'), 'SETTING_NOT_FOUND', 404);
  await kzErro(
    () => flags.setSetting(kzDemoA(), { key: 'store_name', value: 'Outro Nome', idempotency_key: 'set-2' }),
    'VERSION_CONFLICT',
    409,
  );
  const atualizada = (await flags.setSetting(kzDemoA(), { key: 'store_name', value: 'Nome Novo Sintetico', expected_version: 1, idempotency_key: 'set-3' })) as any;
  assert.equal(atualizada.version, 2);
  await kzErro(() => flags.setSetting(kzDemoA('viewer'), { key: 'x', value: 'y', idempotency_key: 'set-4' }), 'FORBIDDEN', 403);
});

test('contadores por loja avancam de um em um', async () => {
  const v1 = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzNextCounter(tx, KZ_DEMO_WS_A, 'teste-contador'));
  const v2 = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzNextCounter(tx, KZ_DEMO_WS_A, 'teste-contador'));
  const vB = await db.workspace(KZ_DEMO_WS_B, (tx: any) => kzNextCounter(tx, KZ_DEMO_WS_B, 'teste-contador'));
  assert.equal(v1, 1);
  assert.equal(v2, 2);
  assert.equal(vB, 1, 'contador da loja B e independente (RLS/escopo)');
});

test('eventos de flags e ajustes gravados no outbox kz', async () => {
  await flags.set(kzDemoA(), { module: 'crediario', enabled: true, idempotency_key: 'flags-ev-1' });
  await flags.setSetting(kzDemoA(), { key: 'store_city', value: 'Cidade Sintetica', idempotency_key: 'set-ev-1' });
  const tipos = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const rows = (await tx.query('SELECT type FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type IN ($2, $3)', [KZ_DEMO_WS_A, 'kz.flags.alteradas', 'kz.settings.alteradas'])).rows;
    return new Set(rows.map((r: any) => r.type));
  });
  assert.ok(tipos.has('kz.flags.alteradas'));
  assert.ok(tipos.has('kz.settings.alteradas'));
});

test('isolamento entre lojas: flag da loja A nao vaza para a loja B', async () => {
  await kzHabilitar(db, 'seguranca', KZ_DEMO_WS_A);
  const listaB = (await flags.list(kzDemoB())) as any;
  const segurancaB = listaB.modules.find((m: any) => m.module === 'seguranca');
  assert.equal(segurancaB.enabled, false);
  assert.equal(segurancaB.store_enabled, false, 'a loja B nao pode ver a flag da loja A');
  const habilitadaB = await db.workspace(KZ_DEMO_WS_B, (tx: any) => kzModuleEnabled(tx, KZ_DEMO_WS_B, 'seguranca'));
  assert.equal(habilitadaB, false);
});
