// Testes do kz-usados: referencia, avaliacao com IMEI (Luhn), fora da faixa,
// aprovacao/recusa, termo em rascunho com aceite, papeis, flag e RLS.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzUsados } from '../../src/modules/kz-usados/service.js';
import { KzFlags } from '../../src/modules/kz-flags.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let usados: KzUsados;

const IMEI_VALIDO = '123456789012347';

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'usados', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'usados', KZ_DEMO_WS_B);
  usados = new KzUsados(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('referencia: criar, atualizar com versao e arquivar', async () => {
  const p = kzDemoA();
  const ref = (await usados.refSet(p, {
    model_label: 'Modelo Sintetico 10',
    storage_label: '128GB',
    grade: 'A',
    min_value_cents: 150000,
    max_value_cents: 190000,
    idempotency_key: 'ref-1',
  })) as any;
  assert.equal(Number(ref.version), 1);
  await kzErro(
    () =>
      usados.refSet(p, {
        model_label: 'Modelo Sintetico 10',
        storage_label: '128GB',
        grade: 'A',
        min_value_cents: 160000,
        max_value_cents: 200000,
        idempotency_key: 'ref-2',
      }),
    'VERSION_CONFLICT',
    409,
  );
  const atualizada = (await usados.refSet(p, {
    model_label: 'modelo sintetico 10',
    storage_label: '128GB',
    grade: 'A',
    min_value_cents: 160000,
    max_value_cents: 200000,
    expected_version: 1,
    idempotency_key: 'ref-3',
  })) as any;
  assert.equal(Number(atualizada.version), 2, 'busca por modelo e case-insensitive');
  const lista = (await usados.refListar(p, { model: 'MODELO SINTETICO 10' })) as any[];
  assert.equal(lista.length, 1);
  const arquivada = (await usados.refArquivar(p, atualizada.id, { expected_version: 2, idempotency_key: 'ref-4' })) as any;
  assert.equal(arquivada.active, false);
  // apos arquivar, pode cadastrar de novo a mesma combinacao
  const nova = (await usados.refSet(p, {
    model_label: 'Modelo Sintetico 10',
    storage_label: '128GB',
    grade: 'A',
    min_value_cents: 155000,
    max_value_cents: 195000,
    idempotency_key: 'ref-5',
  })) as any;
  assert.equal(Number(nova.version), 1);
});

test('avaliacao: IMEI invalido rejeitado, faixa gravada e fora da faixa marcada', async () => {
  const p = kzDemoA();
  await kzErro(
    () =>
      usados.avaliar(p, {
        device_brand: 'Marca Sintetica',
        device_model: 'Modelo Sintetico 10',
        storage_label: '128GB',
        imei: '123456789012348',
        grade: 'A',
        checklist: [{ label: 'Liga', ok: true }],
        idempotency_key: 'av-inv',
      }),
    'IMEI_INVALID',
    422,
  );
  const dentro = (await usados.avaliar(p, {
    device_brand: 'Marca Sintetica',
    device_model: 'Modelo Sintetico 10',
    storage_label: '128GB',
    imei: IMEI_VALIDO,
    grade: 'A',
    checklist: [
      { label: 'Liga', ok: true },
      { label: 'Tela sem trinca', ok: true },
    ],
    suggested_value_cents: 175000,
    idempotency_key: 'av-1',
  })) as any;
  assert.equal(dentro.eval_number, 'AT-00001');
  assert.equal(dentro.out_of_range, false);
  assert.equal(Number(dentro.suggested_min_cents), 155000);
  assert.equal(Number(dentro.suggested_max_cents), 195000);

  const fora = (await usados.avaliar(p, {
    device_brand: 'Marca Sintetica',
    device_model: 'Modelo Sintetico 10',
    storage_label: '128GB',
    grade: 'A',
    checklist: [{ label: 'Liga', ok: false }],
    suggested_value_cents: 300000,
    idempotency_key: 'av-2',
  })) as any;
  assert.equal(fora.out_of_range, true, 'fora da faixa e marcado, nunca bloqueado');

  // modelo sem referencia: faixa nula e sem fora-da-faixa
  const semRef = (await usados.avaliar(p, {
    device_brand: 'Marca Sintetica',
    device_model: 'Modelo Sem Referencia',
    grade: 'B',
    checklist: [{ label: 'Liga', ok: true }],
    idempotency_key: 'av-3',
  })) as any;
  assert.equal(semRef.suggested_min_cents, null);
  assert.equal(semRef.out_of_range, false);
});

test('idempotencia na avaliacao', async () => {
  const repetida = (await usados.avaliar(kzDemoA(), {
    device_brand: 'Marca Sintetica',
    device_model: 'Modelo Sintetico 10',
    storage_label: '128GB',
    imei: IMEI_VALIDO,
    grade: 'A',
    checklist: [
      { label: 'Liga', ok: true },
      { label: 'Tela sem trinca', ok: true },
    ],
    suggested_value_cents: 175000,
    idempotency_key: 'av-1',
  })) as any;
  assert.equal(repetida.eval_number, 'AT-00001');
  await kzErro(
    () =>
      usados.avaliar(kzDemoA(), {
        device_brand: 'Marca Sintetica',
        device_model: 'Modelo Sintetico 10',
        storage_label: '128GB',
        grade: 'A',
        checklist: [{ label: 'Liga', ok: false }],
        idempotency_key: 'av-1',
      }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
});

test('aprovacao com unit_ref e recusa com estados invalidos', async () => {
  const p = kzDemoA();
  const lista = (await usados.listar(p, {})) as any[];
  const alvo = lista.find((a: any) => a.eval_number === 'AT-00001') as any;
  await kzErro(() => usados.recusar(p, alvo.id, { expected_version: 99, idempotency_key: 'rc-x' }), 'VERSION_CONFLICT', 409);
  const aprovada = (await usados.aprovar(p, alvo.id, {
    expected_version: Number(alvo.version),
    unit_ref: 'IMEI-123456789012347',
    decision_note: 'Aprovado sintetico',
    idempotency_key: 'ap-1',
  })) as any;
  assert.equal(aprovada.status, 'aprovada');
  assert.equal(aprovada.stocked_unit_ref, 'IMEI-123456789012347');
  await kzErro(() => usados.recusar(p, alvo.id, { expected_version: Number(alvo.version) + 1, idempotency_key: 'rc-1' }), 'INVALID_STATE', 409);
  const recusavel = lista.find((a: any) => a.eval_number === 'AT-00003') as any;
  const recusada = (await usados.recusar(p, recusavel.id, { expected_version: Number(recusavel.version), idempotency_key: 'rc-2' })) as any;
  assert.equal(recusada.status, 'recusada');
});

test('termo: gerado em rascunho na primeira leitura, aceite unico', async () => {
  const p = kzDemoA();
  await new KzFlags(db).setSetting(p, { key: 'store_name', value: 'Loja Sintetica A', idempotency_key: 'set-usados-1' });
  const lista = (await usados.listar(p, {})) as any[];
  const aprovada = lista.find((a: any) => a.status === 'aprovada') as any;
  const termo = (await usados.termo(p, aprovada.id)) as any;
  assert.ok(termo.rendered_text.includes('Loja Sintetica A'));
  assert.ok(termo.rendered_text.includes(IMEI_VALIDO));
  assert.ok(termo.rendered_text.includes('1.750,00'), 'valor ofertado formatado (175000 centavos = R$ 1.750,00)');
  assert.ok(termo.rendered_text.includes('RASCUNHO'));
  assert.equal(termo.accepted_at, null);
  // segunda leitura nao duplica
  const termos = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_tradein_terms WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  await usados.termo(p, aprovada.id);
  const termos2 = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_tradein_terms WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  assert.equal(termos, termos2);
  const aceito = (await usados.aceitarTermo(p, aprovada.id, { expected_version: Number(termo.version), idempotency_key: 'tm-1' })) as any;
  assert.ok(aceito.accepted_at);
  await kzErro(() => usados.aceitarTermo(p, aprovada.id, { expected_version: Number(aceito.version), idempotency_key: 'tm-2' }), 'INVALID_STATE', 409);
});

test('papeis, flag e RLS', async () => {
  await kzErro(
    () =>
      usados.avaliar(kzDemoA('sales'), {
        device_brand: 'X',
        device_model: 'Y',
        grade: 'C',
        checklist: [{ label: 'Liga', ok: true }],
        idempotency_key: 'av-v',
      }),
    'FORBIDDEN',
    403,
  );
  const lista = (await usados.listar(kzDemoA('viewer'), {})) as any[];
  assert.ok(Array.isArray(lista));
  await kzErro(() => usados.listar(kzAgenteA(), {}), 'FORBIDDEN', 403);

  delete process.env.KAZZUS_KZ_USADOS;
  await kzErro(() => usados.listar(kzDemoA(), {}), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_USADOS = 'YES';

  const listaB = (await usados.listar(kzDemoB(), {})) as any[];
  assert.equal(listaB.length, 0, 'loja B nao ve avaliacoes da loja A');
  const refsB = (await usados.refListar(kzDemoB(), {})) as any[];
  assert.equal(refsB.length, 0, 'loja B nao ve referencias da loja A');
  const listaA = (await usados.listar(kzDemoA(), {})) as any[];
  await kzErro(() => usados.detalhe(kzDemoB(), listaA[0].id), 'NOT_FOUND', 404);
  await kzErro(
    () => usados.aprovar(kzDemoB(), listaA[0].id, { unit_ref: 'zz-rls', expected_version: 1, idempotency_key: 'ap-rls' }),
    'NOT_FOUND',
    404,
  );
});

test('numeros de avaliacao independentes por loja', async () => {
  const b = (await usados.avaliar(kzDemoB(), {
    device_brand: 'Marca B',
    device_model: 'Modelo B',
    grade: 'D',
    checklist: [{ label: 'Liga', ok: true }],
    idempotency_key: 'av-b1',
  })) as any;
  assert.equal(b.eval_number, 'AT-00001', 'loja B comeca do 1');
});
