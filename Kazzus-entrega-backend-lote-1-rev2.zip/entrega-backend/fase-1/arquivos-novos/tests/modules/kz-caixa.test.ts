// Testes do kz-caixa: ciclo do dia, conferencia cega, idempotencia, concorrencia
// otimista, papeis, flag desligada e isolamento entre lojas (RLS).

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzCaixa } from '../../src/modules/kz-caixa/service.js';
import { kzVerifyAuditChain } from '../../src/modules/kz-common.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let caixa: KzCaixa;

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'caixa', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'caixa', KZ_DEMO_WS_B);
  caixa = new KzCaixa(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('ciclo feliz: abrir, sangria, reforco, fechar com diferenca (conferencia cega)', async () => {
  const p = kzDemoA();
  const sessao = (await caixa.abrir(p, { opening_cents: 100000, idempotency_key: 'abrir-1' })) as any;
  assert.equal(sessao.status, 'aberta');
  assert.equal(Number(sessao.opening_cents), 100000);

  const sangria = (await caixa.sangria(p, {
    session_id: sessao.id,
    amount_cents: 20000,
    reason: 'compra de suprimentos sintetica',
    expected_version: 1,
    idempotency_key: 'sang-1',
  })) as any;
  assert.equal(sangria.type, 'sangria');

  const reforco = (await caixa.reforco(p, {
    session_id: sessao.id,
    amount_cents: 50000,
    reason: 'troco extra sintetico',
    expected_version: 2,
    idempotency_key: 'ref-1',
  })) as any;
  assert.equal(reforco.type, 'reforco');

  const fechada = (await caixa.fechar(p, {
    session_id: sessao.id,
    counted_cents: 478500,
    declared_sales_cash_cents: 350000,
    expected_version: 3,
    idempotency_key: 'fec-1',
  })) as any;
  // esperado = 100000 + 50000 - 20000 + 350000 = 480000; contado 478500
  assert.equal(fechada.status, 'fechada');
  assert.equal(Number(fechada.expected_cents), 480000);
  assert.equal(Number(fechada.difference_cents), -1500);
});

test('eventos do ciclo gravados no outbox kz', async () => {
  const tipos = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const rows = (await tx.query('SELECT type FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type LIKE $2', [KZ_DEMO_WS_A, 'kz.caixa.%'])).rows;
    return rows.map((r: any) => r.type).sort();
  });
  assert.deepEqual(tipos, ['kz.caixa.aberto', 'kz.caixa.diferenca', 'kz.caixa.fechado', 'kz.caixa.movimento', 'kz.caixa.movimento']);
});

test('hoje mostra o fechamento e permite reabrir no mesmo dia', async () => {
  const hoje = (await caixa.hoje(kzDemoA())) as any;
  assert.equal(hoje.aberta, null);
  assert.equal(hoje.fechadas_hoje.length, 1);
  assert.equal(Number(hoje.fechadas_hoje[0].difference_cents), -1500);

  const nova = (await caixa.abrir(kzDemoA(), { opening_cents: 90000, idempotency_key: 'abrir-2' })) as any;
  assert.equal(nova.status, 'aberta');
  const depois = (await caixa.hoje(kzDemoA())) as any;
  assert.equal(depois.aberta.id, nova.id);
});

test('idempotencia: mesma chave devolve o mesmo recibo; outro input conflita', async () => {
  const repetido = (await caixa.abrir(kzDemoA(), { opening_cents: 100000, idempotency_key: 'abrir-1' })) as any;
  assert.equal(repetido.status, 'aberta', 'recibo devolve o resultado original');
  const original = JSON.parse(JSON.stringify(repetido));
  assert.equal(original.opening_cents, 100000);

  await kzErro(
    () => caixa.abrir(kzDemoA(), { opening_cents: 777, idempotency_key: 'abrir-1' }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
  const sessoes = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_cash_sessions WHERE workspace_id = $1', [KZ_DEMO_WS_A])).rows[0];
    return r.c;
  });
  assert.equal(sessoes, 2, 'abrir-1 nao pode ter criado sessao nova');
});

test('uma sessao aberta por vez', async () => {
  await kzErro(() => caixa.abrir(kzDemoA(), { opening_cents: 5000, idempotency_key: 'abrir-3' }), 'CAIXA_ALREADY_OPEN', 409);
});

test('estados e versoes invalidos rejeitados', async () => {
  const p = kzDemoA();
  const hoje = (await caixa.hoje(p)) as any;
  const aberta = hoje.aberta as any;
  await kzErro(
    () =>
      caixa.sangria(p, {
        session_id: aberta.id,
        amount_cents: 100,
        reason: 'versao errada sintetica',
        expected_version: 99,
        idempotency_key: 'sang-x1',
      }),
    'VERSION_CONFLICT',
    409,
  );
  await kzErro(
    () =>
      caixa.sangria(p, {
        session_id: '00000000-0000-4000-8000-000000000009',
        amount_cents: 100,
        reason: 'sessao inexistente sintetica',
        expected_version: 1,
        idempotency_key: 'sang-x2',
      }),
    'NOT_FOUND',
    404,
  );
  // fecha e tenta movimentar em sessao fechada
  const fechada = (await caixa.fechar(p, {
    session_id: aberta.id,
    counted_cents: 90000,
    expected_version: 1,
    idempotency_key: 'fec-2',
  })) as any;
  assert.equal(Number(fechada.expected_cents), 90000);
  assert.equal(Number(fechada.difference_cents), 0, 'sem diferenca nao emite kz.caixa.diferenca');
  await kzErro(
    () =>
      caixa.reforco(p, {
        session_id: aberta.id,
        amount_cents: 100,
        reason: 'sessao ja fechada sintetica',
        expected_version: 2,
        idempotency_key: 'ref-x1',
      }),
    'INVALID_STATE',
    409,
  );
});

test('papeis: escrita so operator/admin; leitura humana; agente bloqueado', async () => {
  await kzErro(() => caixa.abrir(kzDemoA('viewer'), { opening_cents: 100, idempotency_key: 'abrir-v' }), 'FORBIDDEN', 403);
  await kzErro(() => caixa.sangria(kzDemoA('sales'), {
    session_id: '00000000-0000-4000-8000-000000000001',
    amount_cents: 1,
    reason: 'vendedor tentando sintetico',
    expected_version: 1,
    idempotency_key: 'sang-v',
  }), 'FORBIDDEN', 403);
  const hoje = (await caixa.hoje(kzDemoA('viewer'))) as any;
  assert.ok(Array.isArray(hoje.fechadas_hoje));
  await kzErro(() => caixa.hoje(kzAgenteA()), 'FORBIDDEN', 403);
});

test('flag desligada responde MODULE_DISABLED em leitura e escrita', async () => {
  delete process.env.KAZZUS_KZ_CAIXA;
  await kzErro(() => caixa.hoje(kzDemoA()), 'MODULE_DISABLED', 404);
  await kzErro(() => caixa.abrir(kzDemoA(), { opening_cents: 100, idempotency_key: 'abrir-off' }), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_CAIXA = 'YES';
});

test('isolamento entre lojas (RLS): loja B nao ve nem mexe no caixa da loja A', async () => {
  const hojeB = (await caixa.hoje(kzDemoB())) as any;
  assert.equal(hojeB.aberta, null);
  assert.equal(hojeB.fechadas_hoje.length, 0);
  const hojeA = (await caixa.hoje(kzDemoA())) as any;
  const idA = (hojeA.fechadas_hoje[0] as any).id;
  await kzErro(() => caixa.detalhe(kzDemoB(), idA), 'NOT_FOUND', 404);
  await kzErro(
    () =>
      caixa.sangria(kzDemoB(), {
        session_id: idA,
        amount_cents: 10,
        reason: 'loja B tentando na loja A sintetico',
        expected_version: 1,
        idempotency_key: 'sang-rls',
      }),
    'NOT_FOUND',
    404,
  );
});

test('historico e detalhe devolvem as sessoes corretas', async () => {
  const hist = (await caixa.historico(kzDemoA(), { dias: '7' })) as any[];
  assert.equal(hist.length, 2);
  const detalhe = (await caixa.detalhe(kzDemoA(), hist[0].id)) as any;
  assert.ok(Array.isArray(detalhe.movimentos));
});

test('trilha de auditoria kz continua integra apos o modulo', async () => {
  const resultado = await db.workspace(KZ_DEMO_WS_A, (tx: any) => kzVerifyAuditChain(tx, KZ_DEMO_WS_A));
  assert.equal(resultado.ok, true);
});
