// Testes do kz-crediario: criacao com divisao inteira, vencimentos mensais, limite,
// baixa/quitacao, cancelamento, posicao do cliente, job de varredura, papeis, flag e RLS.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzCrediario, kzAddMonthsISO } from '../../src/modules/kz-crediario/service.js';
import { scanCrediarioInstallments } from '../../src/modules/kz-crediario/jobs.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let crediario: KzCrediario;

const CLIENTE = '44444444-4444-4444-8444-444444444444';
const CLIENTE2 = '55555555-5555-4555-8555-555555555555';

function dataISO(dias: number): string {
  // Dia de calendario em America/Fortaleza (mesma referencia do servico, que usa
  // (now() AT TIME ZONE 'America/Fortaleza')::date). Calculo em UTC quebraria na
  // janela 00:00-03:00 UTC, quando o dia UTC ja virou mas o local nao.
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Fortaleza',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const hojeLocal = fmt.format(new Date());
  const d = new Date(`${hojeLocal}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}

function soData(valor: unknown): string {
  return new Date(valor as string).toISOString().slice(0, 10);
}

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'crediario', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'crediario', KZ_DEMO_WS_B);
  crediario = new KzCrediario(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('cria carne com divisao inteira e vencimentos mensais (fim de mes)', async () => {
  const plano = (await crediario.criar(kzDemoA(), {
    contact_id: CLIENTE,
    total_cents: 100000,
    installments_count: 3,
    first_due: '2026-01-31',
    idempotency_key: 'cr-1',
  })) as any;
  assert.equal(plano.plan_number, 'CR-00001');
  assert.equal(plano.status, 'ativo');
  assert.deepEqual(
    plano.parcelas.map((i: any) => Number(i.amount_cents)),
    [33334, 33333, 33333],
  );
  assert.deepEqual(
    plano.parcelas.map((i: any) => soData(i.due_date)),
    ['2026-01-31', '2026-02-28', '2026-03-31'],
  );
  assert.equal(kzAddMonthsISO('2026-01-31', 1), '2026-02-28');
  assert.equal(kzAddMonthsISO('2024-01-31', 1), '2024-02-29', 'ano bissexto');
});

test('idempotencia na criacao do carne', async () => {
  const repetido = (await crediario.criar(kzDemoA(), {
    contact_id: CLIENTE,
    total_cents: 100000,
    installments_count: 3,
    first_due: '2026-01-31',
    idempotency_key: 'cr-1',
  })) as any;
  assert.equal(repetido.plan_number, 'CR-00001');
  await kzErro(
    () =>
      crediario.criar(kzDemoA(), {
        contact_id: CLIENTE,
        total_cents: 99999,
        installments_count: 3,
        first_due: '2026-01-31',
        idempotency_key: 'cr-1',
      }),
    'IDEMPOTENCY_CONFLICT',
    409,
  );
});

test('limite de credito e respeitado na criacao', async () => {
  const p = kzDemoA();
  await crediario.limite(p, { contact_id: CLIENTE, limit_cents: 200000, idempotency_key: 'lm-1' });
  await kzErro(
    () =>
      crediario.criar(p, {
        contact_id: CLIENTE,
        total_cents: 150000,
        installments_count: 2,
        first_due: dataISO(10),
        idempotency_key: 'cr-x1',
      }),
    'CREDIT_LIMIT_EXCEEDED',
    409,
  );
  await kzErro(
    () => crediario.limite(p, { contact_id: CLIENTE, limit_cents: 300000, idempotency_key: 'lm-2' }),
    'VERSION_CONFLICT',
    409,
  );
  await crediario.limite(p, { contact_id: CLIENTE, limit_cents: 300000, expected_version: 1, idempotency_key: 'lm-3' });
  const plano2 = (await crediario.criar(p, {
    contact_id: CLIENTE,
    total_cents: 150000,
    installments_count: 2,
    first_due: dataISO(10),
    idempotency_key: 'cr-2',
  })) as any;
  assert.equal(plano2.plan_number, 'CR-00002');
});

test('baixa parcela, idempotencia e quitacao do plano', async () => {
  const p = kzDemoA();
  const plano1 = (await crediario.listar(p, { status: 'ativo' })) as any[];
  const cr1 = plano1.find((x: any) => x.plan_number === 'CR-00001') as any;
  const detalhe = (await crediario.detalhe(p, cr1.id)) as any;
  const parcela1 = detalhe.parcelas[0];
  const baixa = (await crediario.baixar(p, parcela1.id, { idempotency_key: 'bx-1' })) as any;
  assert.equal(baixa.parcela.status, 'paga');
  assert.ok(baixa.parcela.paid_at);
  assert.equal(Number(baixa.plano.paid_cents), 33334);
  // idempotencia: mesma chave devolve o mesmo resultado sem cobrar de novo
  const baixaRepetida = (await crediario.baixar(p, parcela1.id, { idempotency_key: 'bx-1' })) as any;
  assert.equal(baixaRepetida.parcela.id, parcela1.id);
  await kzErro(() => crediario.baixar(p, parcela1.id, { idempotency_key: 'bx-2' }), 'INVALID_STATE', 409);
  // paga as restantes e o plano fecha
  const depois = (await crediario.detalhe(p, cr1.id)) as any;
  for (const parcela of depois.parcelas.filter((i: any) => i.status === 'aberta')) {
    await crediario.baixar(p, parcela.id, { idempotency_key: `bx-${parcela.number}` });
  }
  const fechado = (await crediario.detalhe(p, cr1.id)) as any;
  assert.equal(fechado.status, 'quitado');
  const eventoQuitado = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type = $2', [KZ_DEMO_WS_A, 'kz.crediario.quitado'])).rows[0];
    return r.c;
  });
  assert.equal(eventoQuitado, 1);
});

test('cancelamento so sem pagamento; posicao do cliente; atrasadas', async () => {
  const p = kzDemoA();
  const planoComPagamento = (await crediario.criar(p, {
    contact_id: CLIENTE2,
    total_cents: 50000,
    installments_count: 2,
    first_due: dataISO(40),
    idempotency_key: 'cr-3',
  })) as any;
  const detalhe = (await crediario.detalhe(p, planoComPagamento.id)) as any;
  await crediario.baixar(p, detalhe.parcelas[0].id, { idempotency_key: 'bx-c1' });
  const aposBaixa = (await crediario.detalhe(p, planoComPagamento.id)) as any;
  await kzErro(() => crediario.cancelar(p, planoComPagamento.id, { expected_version: Number(aposBaixa.version), idempotency_key: 'cx-1' }), 'INVALID_STATE', 409);
  const planoLimpo = (await crediario.criar(p, {
    contact_id: CLIENTE2,
    total_cents: 20000,
    installments_count: 1,
    first_due: dataISO(50),
    idempotency_key: 'cr-4',
  })) as any;
  const cancelado = (await crediario.cancelar(p, planoLimpo.id, { expected_version: Number(planoLimpo.version), idempotency_key: 'cx-2' })) as any;
  assert.equal(cancelado.status, 'cancelado');

  // plano com parcela atrasada (vencimento ontem)
  await crediario.criar(p, {
    contact_id: CLIENTE2,
    total_cents: 30000,
    installments_count: 1,
    first_due: dataISO(-1),
    idempotency_key: 'cr-5',
  });
  const atrasados = (await crediario.listar(p, { atrasadas: 'true' })) as any[];
  assert.equal(atrasados.length, 1);
  const posicao = (await crediario.posicaoCliente(p, CLIENTE2)) as any;
  assert.equal(posicao.parcelas_atrasadas.length, 1);
  assert.equal(posicao.limite_cents, null, 'sem limite definido para o cliente 2');
});

test('job de varredura emite eventos com dedupe e respeita o kill switch', async () => {
  process.env.KAZZUS_KZ_AUTOMATIONS = 'YES';
  const primeira = await scanCrediarioInstallments(db, KZ_DEMO_WS_A);
  assert.equal(primeira.desligado, false);
  assert.equal(primeira.atrasadas, 1);
  const eventos = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT type, count(*)::int AS c FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type IN ($2, $3) GROUP BY type', [KZ_DEMO_WS_A, 'kz.parcela.atrasada', 'kz.parcela.vence_amanha'])).rows;
    return r;
  });
  const atrasadas = eventos.find((e: any) => e.type === 'kz.parcela.atrasada');
  assert.equal(Number(atrasadas.c), 1);
  await scanCrediarioInstallments(db, KZ_DEMO_WS_A);
  const depois = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type = $2', [KZ_DEMO_WS_A, 'kz.parcela.atrasada'])).rows[0];
    return r.c;
  });
  assert.equal(depois, 1, 'dedupe: segunda varredura nao duplica evento');
  delete process.env.KAZZUS_KZ_AUTOMATIONS;
  const desligado = await scanCrediarioInstallments(db, KZ_DEMO_WS_A);
  assert.equal(desligado.desligado, true);
});

test('papeis, agente, flag e RLS', async () => {
  await kzErro(
    () =>
      crediario.criar(kzDemoA('sales'), {
        contact_id: CLIENTE,
        total_cents: 1000,
        installments_count: 1,
        first_due: dataISO(10),
        idempotency_key: 'cr-s',
      }),
    'FORBIDDEN',
    403,
  );
  const lista = (await crediario.listar(kzDemoA('viewer'), {})) as any[];
  assert.ok(Array.isArray(lista));
  await kzErro(() => crediario.listar(kzAgenteA(), {}), 'FORBIDDEN', 403);

  delete process.env.KAZZUS_KZ_CREDIARIO;
  await kzErro(() => crediario.listar(kzDemoA(), {}), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_CREDIARIO = 'YES';

  const listaB = (await crediario.listar(kzDemoB(), {})) as any[];
  assert.equal(listaB.length, 0, 'loja B nao ve carnes da loja A');
  const posicaoB = (await crediario.posicaoCliente(kzDemoB(), CLIENTE)) as any;
  assert.equal(posicaoB.planos.length, 0);
  const listaA = (await crediario.listar(kzDemoA(), {})) as any[];
  await kzErro(() => crediario.detalhe(kzDemoB(), listaA[0].id), 'NOT_FOUND', 404);
  await kzErro(() => crediario.cancelar(kzDemoB(), listaA[0].id, { expected_version: 1, idempotency_key: 'cx-rls' }), 'NOT_FOUND', 404);
});
