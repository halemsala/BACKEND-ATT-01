// Helpers dos testes kz: lojas sinteticas (DEMO_A / DEMO_B), habilitacao de flags,
// limpeza de variaveis de ambiente e assercao de erros de dominio.
// Somente dados sinteticos: nenhum dado real de cliente (regra R9).

import type { Principal } from '../../../src/contracts.js';
import { KzFlags } from '../../../src/modules/kz-flags.js';
import { Database } from './kz-database.js';

export const KZ_DEMO_WS_A = '11111111-1111-4111-8111-111111111111';
export const KZ_DEMO_WS_B = '22222222-2222-4222-8222-222222222222';

export type KzPapelTeste = 'admin' | 'manager' | 'sales' | 'support' | 'viewer' | 'operator';

export function kzDemoA(role: KzPapelTeste = 'operator'): Principal {
  return { workspaceId: KZ_DEMO_WS_A, actorId: 'kz-demo-a', providerAccountId: 'kz-demo-a', role };
}

export function kzDemoB(role: KzPapelTeste = 'operator'): Principal {
  return { workspaceId: KZ_DEMO_WS_B, actorId: 'kz-demo-b', providerAccountId: 'kz-demo-b', role };
}

export function kzAgenteA(): Principal {
  return { workspaceId: KZ_DEMO_WS_A, actorId: 'kz-agente-1', providerAccountId: 'kz-agente-1', role: 'agent', agentId: 'kz-agente-1' };
}

export async function kzAbrirDb(): Promise<any> {
  const db = await Database.open();
  if (typeof db?.bootstrapWorkspace !== 'function') {
    throw new Error(
      'O Database nao expoe bootstrapWorkspace(id, nome). Ajuste tests/modules/helpers/kz-env.ts (duvida D1 do RELATORIO.md).',
    );
  }
  await db.bootstrapWorkspace(KZ_DEMO_WS_A, 'Loja Sintetica A');
  await db.bootstrapWorkspace(KZ_DEMO_WS_B, 'Loja Sintetica B');
  return db;
}

export async function kzFecharDb(db: any): Promise<void> {
  await db?.close?.();
}

export function kzEnvFlag(modulo: string): string {
  return `KAZZUS_KZ_${modulo.toUpperCase().replace(/-/g, '_')}`;
}

/** Limpa as flags de processo dos testes (nao toca na chave de dados). */
export function kzLimparEnv(): void {
  for (const nome of Object.keys(process.env)) {
    if (nome.startsWith('KAZZUS_KZ_') && nome !== 'KAZZUS_KZ_DATA_KEY') delete process.env[nome];
  }
}

/** Liga a flag de processo E a flag da loja, usando o proprio servico kz-flags. */
export async function kzHabilitar(
  db: any,
  modulo: string,
  workspaceId: string = KZ_DEMO_WS_A,
  papel: KzPapelTeste = 'operator',
): Promise<void> {
  process.env[kzEnvFlag(modulo)] = 'YES';
  const flags = new KzFlags(db);
  await flags.set(
    { workspaceId, actorId: 'kz-testes', providerAccountId: 'kz-testes', role: papel } as Principal,
    { module: modulo, enabled: true, idempotency_key: `kz-teste-flag-${modulo}-${workspaceId}` },
  );
}

/** Desliga so a flag de processo (a linha da loja continua; modulo volta a DISABLED). */
export function kzDesligarProcesso(modulo: string): void {
  delete process.env[kzEnvFlag(modulo)];
}

/** Chave de dados efemera apenas para os testes (32 bytes em base64). */
export function kzChaveDeDadosDeTeste(): string {
  // deterministica e sintetica: nunca uma chave real
  const bytes = new Uint8Array(32);
  for (let i = 0; i < 32; i++) bytes[i] = (i * 7 + 11) % 256;
  return Buffer.from(bytes).toString('base64');
}

/** Espera um DomainError (ou ZodError) com o codigo informado. */
export async function kzErro(fn: () => Promise<unknown>, codigo: string, status?: number): Promise<void> {
  try {
    await fn();
  } catch (e) {
    const err = e as { code?: string; status?: number; name?: string; message?: string };
    const acertou = err?.code === codigo || err?.name === codigo;
    if (!acertou) {
      throw new Error(`Esperava erro ${codigo}, veio: ${err?.name ?? ''}:${err?.code ?? err?.message ?? String(e)}`);
    }
    if (status !== undefined && err.status !== undefined && err.status !== status) {
      throw new Error(`Status errado para ${codigo}: esperado ${status}, veio ${err.status}`);
    }
    return;
  }
  throw new Error(`Esperava erro ${codigo}, mas a chamada concluiu sem erro`);
}
