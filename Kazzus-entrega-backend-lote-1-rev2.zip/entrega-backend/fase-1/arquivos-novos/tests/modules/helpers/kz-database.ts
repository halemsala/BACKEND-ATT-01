// Resolver do Database para os testes kz. O caminho real varia conforme a arvore do
// projeto; tentamos os candidatos mais provaveis e o override KZ_DATABASE_MODULE.
// Se nada resolver, ajuste uma linha aqui (duvida D1 do RELATORIO).

const CANDIDATOS = [
  '../../../src/database.js',
  '../../../src/db.js',
  '../../../src/database/index.js',
  '../../../src/infra/database.js',
  '../../../src/pglite.js',
];

let Database: any;
const lista = process.env.KZ_DATABASE_MODULE
  ? [process.env.KZ_DATABASE_MODULE, ...CANDIDATOS]
  : CANDIDATOS;
for (const caminho of lista) {
  try {
    const modulo = await import(caminho);
    Database = modulo.Database ?? modulo.default?.Database;
    if (Database) break;
  } catch {
    /* tenta o proximo candidato */
  }
}
if (!Database) {
  throw new Error(
    'Nao encontrei a classe Database. Ajuste a variavel KZ_DATABASE_MODULE ou a lista CANDIDATOS em tests/modules/helpers/kz-database.ts com o caminho real do modulo que exporta Database (duvida D1 do RELATORIO.md).',
  );
}

export { Database };
