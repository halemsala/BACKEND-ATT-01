// Testes de CONTRATO (estaticos): transformam as regras invariaveis R1, R2, R7 e o
// padrao de migracoes em verificacoes automaticas. Rode junto com os demais testes
// no repositorio real para continuar guardando as regras depois da aplicacao.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { test } from 'node:test';
import assert from 'node:assert/strict';

const raizModulos = fileURLToPath(new URL('../../src/modules/', import.meta.url));
const raizMigracoes = fileURLToPath(new URL('../../migrations/', import.meta.url));

function listarArquivos(diretorio: string, sufixo: string): string[] {
  const saida: string[] = [];
  const caminhar = (pasta: string) => {
    for (const nome of readdirSync(pasta)) {
      const caminho = join(pasta, nome);
      if (statSync(caminho).isDirectory()) caminhar(caminho);
      else if (nome.endsWith(sufixo)) saida.push(caminho);
    }
  };
  caminhar(diretorio);
  return saida;
}

const arquivosTs = listarArquivos(raizModulos, '.ts');
const arquivosSql = listarArquivos(raizMigracoes, '.sql').filter((caminho) => /\d{3}_kz_.+\.sql$/.test(caminho));

test('R1/R7 - nenhum modulo escreve em tabela que nao seja kz_*', () => {
  assert.ok(arquivosTs.length >= 10, 'modulos kz presentes');
  const escreveFora = /\b(?:INSERT\s+INTO|UPDATE)\s+crm\.(?!kz_)/i;
  const remove = /\b(?:DELETE\s+FROM|TRUNCATE)\b/i;
  for (const caminho of arquivosTs) {
    const conteudo = readFileSync(caminho, 'utf8');
    assert.ok(!escreveFora.test(conteudo), `${caminho} nao pode escrever fora das tabelas kz_*`);
    assert.ok(!remove.test(conteudo), `${caminho} nao pode apagar dados (R7: arquivar, nao apagar)`);
  }
});

test('R2/R5 - nenhuma chamada de rede nem envio externo nos modulos', () => {
  const rede = /\bfetch\s*\(|node-fetch|\baxios\b|net\.connect|tls\.connect|https?\.request\(|\bhttps?:\/\/(?!127\.0\.0\.1)/;
  const proibidos = /guardOutbound|waha|whatsapp|sendEmail|sendSms|googleapis|mercadolivre|shopee/i;
  for (const caminho of arquivosTs) {
    const conteudo = readFileSync(caminho, 'utf8');
    assert.ok(!rede.test(conteudo), `${caminho} nao pode chamar rede externa`);
    assert.ok(!proibidos.test(conteudo), `${caminho} nao pode referenciar envio externo`);
  }
});

test('R9 - nenhum acesso a variavel de ambiente fora do namespace KAZZUS_KZ_*', () => {
  const envFora = /process\.env\.\w+/;
  for (const caminho of arquivosTs) {
    const conteudo = readFileSync(caminho, 'utf8');
    assert.ok(!envFora.test(conteudo), `${caminho} so pode ler flags KAZZUS_KZ_* (acesso por colchetes)`);
  }
});

test('migracoes kz: numeracao 094..101 sem buracos', () => {
  const numeros = arquivosSql.map((caminho) => Number(caminho.match(/\/(\d{3})_kz_/)?.[1])).sort((a, b) => a - b);
  assert.deepEqual(numeros, [94, 95, 96, 97, 98, 99, 100, 101], 'conferir se outra sessao criou a 094 (duvida D6)');
});
test('migracoes kz: somente DDL aditivo, sem DROP/RENAME/TRUNCATE/DELETE/ALTER COLUMN', () => {
  const proibidos = /\bDROP\b|\bRENAME\b|\bTRUNCATE\b|\bDELETE\s+FROM\b|ALTER\s+COLUMN|SET\s+NOT\s+NULL|ALTER\s+COLUMN\s+TYPE/i;
  for (const caminho of arquivosSql) {
    const conteudo = readFileSync(caminho, 'utf8');
    assert.ok(!proibidos.test(conteudo), `${caminho} contem DDL nao aditivo`);
  }
});

test('migracoes kz: bloco RLS completo (ENABLE, FORCE, policy workspace_scope, grant sem DELETE)', () => {
  // Revisao 2: recibos, outbox, auditoria e tentativas de PIN sao apendice-only -
  // o grant delas e SELECT, INSERT (sem UPDATE).
  const apendiceOnly = new Set(['kz_command_receipts', 'kz_outbox_events', 'kz_audit_events', 'kz_stepup_attempts']);
  for (const caminho of arquivosSql) {
    const conteudo = readFileSync(caminho, 'utf8');
    const criadas = (conteudo.match(/CREATE TABLE IF NOT EXISTS/g) ?? []).length;
    const enable = (conteudo.match(/ENABLE ROW LEVEL SECURITY/g) ?? []).length;
    const force = (conteudo.match(/FORCE ROW LEVEL SECURITY/g) ?? []).length;
    const policy = (conteudo.match(/CREATE POLICY workspace_scope/g) ?? []).length;
    const grant = (conteudo.match(/GRANT SELECT, INSERT(?:, UPDATE)? ON/g) ?? []).length;
    assert.equal(enable, criadas, `${caminho}: ENABLE para toda tabela`);
    assert.equal(force, criadas, `${caminho}: FORCE para toda tabela`);
    assert.equal(policy, criadas, `${caminho}: policy workspace_scope para toda tabela`);
    assert.equal(grant, criadas, `${caminho}: grant SELECT, INSERT[, UPDATE] para toda tabela`);
    for (const linha of conteudo.split('\n')) {
      const texto = linha.trim();
      if (/^GRANT/i.test(texto)) {
        assert.ok(!/\bDELETE\b/.test(texto), `${caminho}: grant nao pode dar DELETE (arquiva, nao apaga)`);
        const alvo = texto.match(/ON\s+crm\.([a-z_]+)/i)?.[1] ?? '';
        if (apendiceOnly.has(alvo)) {
          assert.ok(!/\bUPDATE\b/.test(texto), `${caminho}: ${alvo} e apendice-only, grant sem UPDATE (Revisao 2)`);
        }
      }
    }
  }
});

test('migracoes kz: cabecalho em portugues sem acento com a frase de seguranca', () => {
  const comAcento = /[áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇ]/;
  for (const caminho of arquivosSql) {
    const cabecalho = readFileSync(caminho, 'utf8').split('\n').slice(0, 3).join('\n');
    assert.ok(!comAcento.test(cabecalho), `${caminho}: cabecalho sem acento`);
    assert.ok(/So acrescimo; nada aqui envia mensagem, cobra, emite nota ou muda preco/.test(cabecalho), `${caminho}: frase de seguranca obrigatoria`);
  }
});

test('rotas kz: todo endpoint usa o prefixo kz/', () => {
  const rotas = [...listarArquivos(raizModulos, 'routes.ts'), join(raizModulos, 'kz-flags.ts')];
  assert.ok(rotas.length >= 8, 'controllers kz presentes');
  for (const caminho of rotas) {
    const conteudo = readFileSync(caminho, 'utf8');
    const declaradas = [...conteudo.matchAll(/@(Get|Post)\('([^']+)'\)/g)].map((m) => m[2]);
    assert.ok(declaradas.length > 0, `${caminho} deve declarar rotas`);
    for (const rota of declaradas) {
      assert.ok(rota.startsWith('kz/'), `${caminho}: rota ${rota} deve comecar com kz/`);
    }
  }
});

test('eventos kz: todo evento emitido usa o prefixo kz.', () => {
  for (const caminho of arquivosTs) {
    const conteudo = readFileSync(caminho, 'utf8');
    for (const tipo of [...conteudo.matchAll(/kzEvent\(\s*tx,\s*p,\s*'([^']+)'/g)].map((m) => m[1])) {
      assert.ok(tipo.startsWith('kz.'), `${caminho}: evento ${tipo} deve usar o prefixo kz.`);
    }
  }
});

test('validacao zod: schemas de entrada usam .strict()', () => {
  const schemas = listarArquivos(raizModulos, 'schema.ts');
  assert.ok(schemas.length >= 7, 'schemas kz presentes');
  for (const caminho of schemas) {
    const conteudo = readFileSync(caminho, 'utf8');
    assert.ok(conteudo.includes('.strict()'), `${caminho}: entradas devem ser .strict()`);
  }
});

test('dependencias: nenhum import fora do permitido (nest, zod, node:*, kz)', () => {
  const permitidas = /^(@nestjs\/common|zod|node:[a-z:]+|\.\.?\/(kz-)?[a-z-]+\.js)$/;
  for (const caminho of arquivosTs) {
    const conteudo = readFileSync(caminho, 'utf8');
    for (const modulo of [...conteudo.matchAll(/from '([^']+)';/g)].map((m) => m[1])) {
      assert.ok(permitidas.test(modulo), `${caminho}: dependencia nao permitida "${modulo}" (R8: sem dependencias novas)`);
    }
  }
});
