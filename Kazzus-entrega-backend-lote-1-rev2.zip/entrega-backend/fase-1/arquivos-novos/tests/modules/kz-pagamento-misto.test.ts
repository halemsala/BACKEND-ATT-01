// Testes do kz-pagamento-misto: divisao com troco, consistencia, redivisao,
// adaptador de total, papeis, flag e RLS.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzPagamentoMisto } from '../../src/modules/kz-pagamento-misto/service.js';
import {
  KZ_DEMO_WS_A,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let pagamentos: KzPagamentoMisto;

const PEDIDO = '33333333-3333-4333-8333-333333333333';

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'pagamento-misto');
  await (await import('./helpers/kz-env.js')).kzHabilitar(db, 'pagamento-misto', '22222222-2222-4222-8222-222222222222');
  pagamentos = new KzPagamentoMisto(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('divide em varias formas com troco e consulta de volta', async () => {
  const resultado = (await pagamentos.dividir(kzDemoA(), PEDIDO, {
    order_kind: 'order',
    order_total_cents: 250000,
    change_cents: 5000,
    payments: [
      { method: 'dinheiro', amount_cents: 100000 },
      { method: 'pix', amount_cents: 100000 },
      { method: 'credito', amount_cents: 55000, installments: 3 },
    ],
    idempotency_key: 'pg-1',
  })) as any;
  assert.equal(Number(resultado.order_total_cents), 250000);
  assert.equal(Number(resultado.payments_total_cents), 255000);
  assert.equal(Number(resultado.change_cents), 5000);
  assert.equal(resultado.splits.length, 3);

  const consulta = (await pagamentos.consultar(kzDemoA(), PEDIDO, {})) as any;
  assert.equal(consulta.splits.length, 3);
  assert.equal(consulta.splits[2].method, 'credito');
  assert.equal(Number(consulta.splits[2].installments), 3);
});

test('soma que nao fecha e rejeitada (PAYMENT_SPLIT_MISMATCH)', async () => {
  await kzErro(
    () =>
      pagamentos.dividir(kzDemoA(), '33333333-3333-4333-8333-333333333334', {
        order_kind: 'order',
        order_total_cents: 250000,
        payments: [
          { method: 'pix', amount_cents: 100000 },
          { method: 'dinheiro', amount_cents: 100000 },
        ],
        idempotency_key: 'pg-x1',
      }),
    'PAYMENT_SPLIT_MISMATCH',
    422,
  );
});

test('parcelas fora de credito/crediario sao rejeitadas na validacao', async () => {
  await kzErro(
    () =>
      pagamentos.dividir(kzDemoA(), '33333333-3333-4333-8333-333333333335', {
        order_kind: 'order',
        order_total_cents: 1000,
        payments: [{ method: 'pix', amount_cents: 1000, installments: 2 }],
        idempotency_key: 'pg-x2',
      }),
    'ZodError',
  );
});

test('idempotencia e redivisao arquiva o conjunto anterior', async () => {
  const repetido = (await pagamentos.dividir(kzDemoA(), PEDIDO, {
    order_kind: 'order',
    order_total_cents: 250000,
    change_cents: 5000,
    payments: [
      { method: 'dinheiro', amount_cents: 100000 },
      { method: 'pix', amount_cents: 100000 },
      { method: 'credito', amount_cents: 55000, installments: 3 },
    ],
    idempotency_key: 'pg-1',
  })) as any;
  assert.equal(repetido.splits.length, 3, 'recibo devolve o mesmo resultado');

  const nova = (await pagamentos.dividir(kzDemoA(), PEDIDO, {
    order_kind: 'order',
    order_total_cents: 250000,
    payments: [{ method: 'pix', amount_cents: 250000 }],
    idempotency_key: 'pg-2',
  })) as any;
  assert.equal(Number(nova.change_cents), 0);
  const consulta = (await pagamentos.consultar(kzDemoA(), PEDIDO, {})) as any;
  assert.equal(consulta.id, nova.id, 'consulta devolve so o conjunto ativo');
  assert.equal(consulta.splits.length, 1);
  const ativos = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const r = (await tx.query('SELECT count(*)::int AS c FROM crm.kz_payment_sets WHERE workspace_id = $1 AND order_id = $2 AND archived_at IS NULL', [KZ_DEMO_WS_A, PEDIDO])).rows[0];
    return r.c;
  });
  assert.equal(ativos, 1, 'so um conjunto ativo por pedido');
});

test('adaptador de total real confere o valor declarado', async () => {
  const comAdaptador = new KzPagamentoMisto(db, async (_tx, _ws, _kind, _id) => 300000);
  await kzErro(
    () =>
      comAdaptador.dividir(kzDemoA(), '33333333-3333-4333-8333-333333333336', {
        order_kind: 'order',
        order_total_cents: 250000,
        payments: [{ method: 'pix', amount_cents: 250000 }],
        idempotency_key: 'pg-x3',
      }),
    'ORDER_TOTAL_MISMATCH',
    422,
  );
  const ok = (await comAdaptador.dividir(kzDemoA(), '33333333-3333-4333-8333-333333333337', {
    order_kind: 'order',
    order_total_cents: 300000,
    payments: [{ method: 'pix', amount_cents: 300000 }],
    idempotency_key: 'pg-3',
  })) as any;
  assert.equal(Number(ok.order_total_cents), 300000);
});

test('papeis, agente, flag e RLS', async () => {
  await kzErro(
    () =>
      pagamentos.dividir(kzDemoA('sales'), '33333333-3333-4333-8333-333333333338', {
        order_kind: 'order',
        order_total_cents: 100,
        payments: [{ method: 'pix', amount_cents: 100 }],
        idempotency_key: 'pg-s',
      }),
    'FORBIDDEN',
    403,
  );
  const consulta = (await pagamentos.consultar(kzDemoA('viewer'), PEDIDO, {})) as any;
  assert.ok(consulta.id);
  await kzErro(() => pagamentos.consultar(kzAgenteA(), PEDIDO, {}), 'FORBIDDEN', 403);

  delete process.env.KAZZUS_KZ_PAGAMENTO_MISTO;
  await kzErro(() => pagamentos.consultar(kzDemoA(), PEDIDO, {}), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_PAGAMENTO_MISTO = 'YES';

  await kzErro(() => pagamentos.consultar(kzDemoB(), PEDIDO, {}), 'PAYMENT_SET_NOT_FOUND', 404);
  // a loja B grava o proprio conjunto para o mesmo id de pedido (espaco isolado por RLS)
  const conjuntoB = (await pagamentos.dividir(kzDemoB(), PEDIDO, {
    order_kind: 'order',
    order_total_cents: 250000,
    payments: [{ method: 'dinheiro', amount_cents: 250000 }],
    idempotency_key: 'pg-b1',
  })) as any;
  assert.ok(conjuntoB.id, 'loja B grava no proprio espaco');
  const consultaB = (await pagamentos.consultar(kzDemoB(), PEDIDO, {})) as any;
  assert.equal(consultaB.id, conjuntoB.id);
  const consultaA = (await pagamentos.consultar(kzDemoA(), PEDIDO, {})) as any;
  assert.notEqual(consultaA.id, conjuntoB.id, 'loja A continua vendo o dela');
});
