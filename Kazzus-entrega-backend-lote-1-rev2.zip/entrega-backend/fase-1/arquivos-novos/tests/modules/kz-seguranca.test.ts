// Testes do kz-seguranca: PIN scrypt, rotacao, concessoes de 5 minutos, consumo
// unico, trava por tentativas, sem PIN em evento/auditoria, papeis, flag e RLS.

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { KzSeguranca } from '../../src/modules/kz-seguranca/service.js';
import {
  KZ_DEMO_WS_A,
  KZ_DEMO_WS_B,
  kzAgenteA,
  kzDemoA,
  kzDemoB,
  kzErro,
  kzFecharDb,
  kzHabilitar,
  kzLimparEnv,
} from './helpers/kz-env.js';
import { kzAbrirDb } from './helpers/kz-env.js';

let db: any;
let seguranca: KzSeguranca;

before(async () => {
  db = await kzAbrirDb();
  kzLimparEnv();
  await kzHabilitar(db, 'seguranca', KZ_DEMO_WS_A);
  await kzHabilitar(db, 'seguranca', KZ_DEMO_WS_B);
  seguranca = new KzSeguranca(db);
});

after(async () => {
  await kzFecharDb(db);
  kzLimparEnv();
});

test('define PIN, rotaciona com o atual e rejeita o errado', async () => {
  const p = kzDemoA();
  const primeira = (await seguranca.definirPin(p, { pin: '4321', idempotency_key: 'pin-1' })) as any;
  assert.equal(primeira.ok, true);
  assert.equal(primeira.rotacionado, false);
  await kzErro(() => seguranca.definirPin(p, { pin: '9999', current_pin: '0000', idempotency_key: 'pin-2' }), 'INVALID_PIN', 403);
  const rotacionado = (await seguranca.definirPin(p, { pin: '5678', current_pin: '4321', idempotency_key: 'pin-3' })) as any;
  assert.equal(rotacionado.rotacionado, true);
  assert.equal(Number(rotacionado.version), 2);
  await kzErro(() => seguranca.definirPin(p, { pin: '1111', idempotency_key: 'pin-4' }), 'INVALID_PIN', 403, );
});

test('confirma PIN e devolve concessao de 5 minutos (sem PIN em lugar nenhum)', async () => {
  const p = kzDemoA();
  await kzErro(() => seguranca.confirmar(p, { pin: '0000', purpose: 'estorno', idempotency_key: 'cf-x1' }), 'INVALID_PIN', 403);
  const grant = (await seguranca.confirmar(p, { pin: '5678', purpose: 'estorno', idempotency_key: 'cf-1' })) as any;
  assert.ok(grant.grant_id);
  const expira = new Date(grant.expires_at).getTime();
  const agora = Date.now();
  assert.ok(expira > agora && expira <= agora + 300_000, 'concessao vale ate 5 minutos');

  const ativos = (await seguranca.grantsAtivos(p)) as any[];
  assert.equal(ativos.length, 1);
  assert.equal(ativos[0].purpose, 'estorno');

  // eventos e auditoria sem o PIN
  const guarda = await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
    const eventos = (await tx.query('SELECT payload FROM crm.kz_outbox_events WHERE workspace_id = $1 AND type LIKE $2', [KZ_DEMO_WS_A, 'kz.seguranca.%'])).rows;
    const auditoria = (await tx.query('SELECT payload FROM crm.kz_audit_events WHERE workspace_id = $1 AND action LIKE $2', [KZ_DEMO_WS_A, 'kz.seguranca.%'])).rows;
    return { eventos, auditoria };
  });
  for (const e of [...guarda.eventos, ...guarda.auditoria]) {
    assert.ok(!JSON.stringify(e.payload).includes('5678'), 'evento/auditoria nao pode ter o PIN');
    assert.ok(!JSON.stringify(e.payload).includes('4321'), 'evento/auditoria nao pode ter PIN antigo');
  }
});

test('historico proprio mostra as confirmacoes', async () => {
  const historico = (await seguranca.historico(kzDemoA(), {})) as any[];
  assert.ok(historico.length >= 1);
  assert.ok(historico[0].payload.purpose);
});

test('consumo unico da concessao; proposito e prazo conferidos', async () => {
  const p = kzDemoA();
  const grant = (await seguranca.confirmar(p, { pin: '5678', purpose: 'cancelamento', idempotency_key: 'cf-2' })) as any;
  await kzErro(() => seguranca.consumir(p, grant.grant_id, { purpose: 'estorno', idempotency_key: 'us-x1' }), 'STEPUP_INVALID', 403);
  const consumido = (await seguranca.consumir(p, grant.grant_id, { purpose: 'cancelamento', idempotency_key: 'us-1' })) as any;
  assert.equal(consumido.used, true);
  await kzErro(() => seguranca.consumir(p, grant.grant_id, { purpose: 'cancelamento', idempotency_key: 'us-2' }), 'STEPUP_INVALID', 403);
  const ativos = (await seguranca.grantsAtivos(p)) as any[];
  assert.equal(ativos.filter((g: any) => g.id === grant.grant_id).length, 0);

  // concessao expirada: inserida direto com criacao ha 10 min e prazo ha 5 min
  // (o CHECK kz_stepup_prazo_coerente da Revisao 2 proibe expires_at antes de
  // created_at, entao a simulacao realista e nascer ja vencida, nao empurrar para tras)
  const expirada = (
    await db.workspace(KZ_DEMO_WS_A, async (tx: any) => {
      return (
        await tx.query(
          `INSERT INTO crm.kz_stepup_grants (workspace_id, actor_id, purpose, expires_at, created_at, created_by)
           VALUES ($1, 'kz-demo-a', 'estorno', now() - interval '5 minutes', now() - interval '10 minutes', 'kz-seguranca-teste')
           RETURNING id`,
          [KZ_DEMO_WS_A],
        )
      ).rows[0];
    })
  ).id;
  await kzErro(() => seguranca.consumir(p, expirada, { purpose: 'estorno', idempotency_key: 'us-3' }), 'STEPUP_INVALID', 403);
});

test('idempotencia na confirmacao', async () => {
  const p = kzDemoA();
  const grant = (await seguranca.confirmar(p, { pin: '5678', purpose: 'estorno', idempotency_key: 'cf-1' })) as any;
  const repetido = (await seguranca.confirmar(p, { pin: '5678', purpose: 'estorno', idempotency_key: 'cf-1' })) as any;
  assert.equal(repetido.grant_id, grant.grant_id, 'mesma chave devolve a mesma concessao');
});

test('PIN inexistente e formatos invalidos', async () => {
  const semPin = { ...kzDemoA(), actorId: 'kz-ator-sem-pin' };
  await kzErro(() => seguranca.confirmar(semPin, { pin: '1234', purpose: 'estorno', idempotency_key: 'cf-np' }), 'PIN_NOT_SET', 404);
  await kzErro(() => seguranca.definirPin(kzDemoA(), { pin: '12', idempotency_key: 'pin-x' }), 'ZodError');
  await kzErro(() => seguranca.definirPin(kzDemoA(), { pin: '12a4', idempotency_key: 'pin-x2' }), 'ZodError');
});

test('trava apos 5 tentativas erradas em 15 minutos', async () => {
  const p = { ...kzDemoA(), actorId: 'kz-ator-trava' };
  await seguranca.definirPin(p, { pin: '2468', idempotency_key: 'pin-t1' });
  for (let i = 0; i < 5; i++) {
    await kzErro(() => seguranca.confirmar(p, { pin: '0000', purpose: 'estorno', idempotency_key: `cf-t${i}` }), 'INVALID_PIN', 403);
  }
  await kzErro(() => seguranca.confirmar(p, { pin: '2468', purpose: 'estorno', idempotency_key: 'cf-tok' }), 'PIN_LOCKED', 403);
});

test('papeis, agente, flag e RLS', async () => {
  await kzErro(() => seguranca.definirPin(kzDemoA('viewer'), { pin: '1234', idempotency_key: 'pin-v' }), 'FORBIDDEN', 403);
  await kzErro(() => seguranca.confirmar(kzDemoA('sales'), { pin: '1234', purpose: 'x', idempotency_key: 'cf-s' }), 'FORBIDDEN', 403);
  await kzErro(() => seguranca.grantsAtivos(kzAgenteA()), 'FORBIDDEN', 403);

  delete process.env.KAZZUS_KZ_SEGURANCA;
  await kzErro(() => seguranca.grantsAtivos(kzDemoA()), 'MODULE_DISABLED', 404);
  await kzErro(() => seguranca.definirPin(kzDemoA(), { pin: '1234', idempotency_key: 'pin-off' }), 'MODULE_DISABLED', 404);
  process.env.KAZZUS_KZ_SEGURANCA = 'YES';

  // PIN e por loja+ator: loja B comeca sem PIN proprio
  await kzErro(() => seguranca.confirmar(kzDemoB(), { pin: '5678', purpose: 'estorno', idempotency_key: 'cf-b1' }), 'PIN_NOT_SET', 404);
  await seguranca.definirPin(kzDemoB(), { pin: '1357', idempotency_key: 'pin-b1' });
  const grantsB = (await seguranca.grantsAtivos(kzDemoB())) as any[];
  assert.equal(grantsB.length, 0, 'loja B nao ve concessoes da loja A');
});
