# kz-usados

Avaliacao de aparelho usado (trade-in): tabela de referencia por modelo/grau,
checklist de avaliacao, termo de compra em RASCUNHO e aprovacao com vinculo a
unidade de estoque. Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Tabela de referencia editada pelo Anderson: faixa (minimo/maximo em centavos) por
  modelo + armazenamento + grau (A/B/C/D). O valor e FAIXA DE REFERENCIA: so sugere.
- Avaliacao com checklist (1 a 50 itens), IMEI opcional com validacao Luhn,
  numero legivel (`AT-00001`) e snapshot da faixa de referencia no momento.
- Se o valor sugerido sair da faixa, a avaliacao e gravada com `out_of_range=true`
  (nunca bloqueia: quem decide e o Anderson).
- Aprovacao/recusa com nota; a aprovacao pode registrar `unit_ref` (vinculo com a
  unidade serial "used" registrada pelo fluxo de estoque existente) e emite
  `kz.usado.aprovado`.
- Termo de compra gerado como RASCUNHO na primeira leitura de
  `GET kz/usados/:id/termo` (deterministico: uma linha por avaliacao) e aceite
  registrado com data. O nome da loja vem do ajuste `store_name` (`POST kz/settings`).

## O que NAO faz (de proposito)

- Nao grava preco de venda, desconto ou cupom (R1): o valor ofertado e sugestao de
  custo de compra.
- Nao envia o termo ao cliente nem ao mercado (R2): o texto fica no sistema.
- Nao insere a unidade no estoque por conta propria: usa o fluxo existente e
  registra o vinculo (duvida D5).

## Tabelas (migracao 098)

- `crm.kz_tradein_reference`, `crm.kz_tradein_evaluations`, `crm.kz_tradein_terms`.

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| GET | `kz/usados/referencia?model=&storage=&ativos=` | lista faixas |
| POST | `kz/usados/referencia` | `{model_label, storage_label?, grade, min_value_cents, max_value_cents, notes?, active?, expected_version?, idempotency_key}` |
| POST | `kz/usados/referencia/:id/arquivar` | `{expected_version, idempotency_key}` |
| POST | `kz/usados/avaliacao` | `{device_brand, device_model, storage_label?, imei?, grade, checklist: [{label, ok, note?}], suggested_value_cents?, contact_id?, idempotency_key}` |
| GET | `kz/usados?status=&dias=` | lista avaliacoes |
| GET | `kz/usados/:id` | detalhe + termo |
| POST | `kz/usados/:id/aprovar` | `{expected_version, decision_note?, unit_ref?, idempotency_key}` |
| POST | `kz/usados/:id/recusar` | `{expected_version, decision_note?, idempotency_key}` |
| GET | `kz/usados/:id/termo` | termo em rascunho (gera se ainda nao existir) |
| POST | `kz/usados/:id/termo/aceitar` | `{expected_version, idempotency_key}` |

Erros: `IMEI_INVALID` 422, `INVALID_STATE` 409, `VERSION_CONFLICT` 409, `NOT_FOUND`
404, `TERM_NOT_FOUND` 404, `MODULE_DISABLED` 404, `FORBIDDEN` 403,
`KZ_USADOS_MIGRATION_REQUIRED` 503.

## Eventos

`kz.usado.avaliado`, `kz.usado.aprovado`, `kz.usado.recusado`,
`kz.usado.referencia_alterada`, `kz.usado.termo_gerado`, `kz.usado.termo_aceito`.

## Flags

- Processo: `KAZZUS_KZ_USADOS=YES`; Loja: linha `usados` em `crm.kz_feature_flags`.

## Exige autorizacao do Anderson

- Manter a tabela de referencia atualizada (faixas por modelo/grau).
- Definir retencao do termo (contem IMEI e dados do cliente) para LGPD (duvida D10).
- Confirmar como a unidade "used" entra no estoque para preencher `unit_ref`.
