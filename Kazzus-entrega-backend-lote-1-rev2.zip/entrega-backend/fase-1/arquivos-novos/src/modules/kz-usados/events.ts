// Eventos do kz-usados.

export const KZ_USADOS_EVENTS = [
  'kz.usado.avaliado',
  'kz.usado.aprovado',
  'kz.usado.recusado',
  'kz.usado.referencia_alterada',
  'kz.usado.termo_gerado',
  'kz.usado.termo_aceito',
] as const;

export interface KzUsadoAvaliadoPayload {
  eval_number: string;
  device_model: string;
  grade: string;
  suggested_min_cents: number | null;
  suggested_max_cents: number | null;
  suggested_value_cents: number | null;
  out_of_range: boolean;
}

export interface KzUsadoAprovadoPayload {
  eval_number: string;
  unit_ref: string | null;
}
