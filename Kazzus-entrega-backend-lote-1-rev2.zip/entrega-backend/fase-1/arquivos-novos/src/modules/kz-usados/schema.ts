// Schemas zod do kz-usados.

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzText, kzVersion } from '../kz-common.js';

export const KZ_USADOS_GRADES = ['A', 'B', 'C', 'D'] as const;
export const kzUsadosGrade = z.enum(KZ_USADOS_GRADES);

export const kzUsadosRefSetSchema = z
  .object({
    model_label: kzText(1, 120),
    storage_label: kzText(1, 40).optional(),
    grade: kzUsadosGrade,
    min_value_cents: kzCents(0),
    max_value_cents: kzCents(0),
    notes: kzText(1, 500).optional(),
    active: z.boolean().optional(),
    expected_version: kzVersion.optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict()
  .refine((v) => v.min_value_cents <= v.max_value_cents, 'valor minimo maior que o maximo');

export const kzUsadosRefArquivarSchema = z
  .object({ expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzUsadosAvaliacaoSchema = z
  .object({
    contact_id: z.uuid().optional(),
    device_brand: kzText(1, 60),
    device_model: kzText(1, 120),
    storage_label: kzText(1, 40).optional(),
    imei: z.string().regex(/^[0-9]{15}$/, 'IMEI com 15 digitos').optional(),
    grade: kzUsadosGrade,
    checklist: z
      .array(z.object({ label: kzText(1, 200), ok: z.boolean(), note: kzText(1, 200).optional() }).strict())
      .min(1)
      .max(50),
    suggested_value_cents: kzCents(0).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzUsadosAprovarSchema = z
  .object({
    decision_note: kzText(1, 500).optional(),
    // Revisao 2: obrigatorio - a aprovacao "entra como unidade serial used" (item 5
    // do contrato); o vinculo com o estoque e registrado no momento da aprovacao.
    unit_ref: kzText(1, 120),
    expected_version: kzVersion,
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzUsadosRecusarSchema = z
  .object({ decision_note: kzText(1, 500).optional(), expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzUsadosTermoAceitarSchema = z
  .object({ expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzUsadosListQuery = z
  .object({
    status: z.enum(['avaliada', 'aprovada', 'recusada', 'cancelada']).optional(),
    dias: z.coerce.number().int().min(1).max(365).default(30),
  })
  .strict();

export const kzUsadosRefListQuery = z
  .object({
    model: kzText(1, 120).optional(),
    storage: kzText(1, 40).optional(),
    ativos: z.enum(['true', 'false']).optional(),
  })
  .strict();
