// Rotas do kz-usados. Ordem importa: rotas literais antes de :id.

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzUsados } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzUsadosController {
  constructor(@Inject('KZ:USADOS') private readonly usados: KzUsados) {}

  @Get('kz/usados/referencia')
  listarReferencias(@Req() r: Request, @Query() q: unknown) {
    return this.usados.refListar(r.principal, q);
  }

  @Post('kz/usados/referencia')
  definirReferencia(@Req() r: Request, @Body() b: unknown) {
    return this.usados.refSet(r.principal, b);
  }

  @Post('kz/usados/referencia/:id/arquivar')
  arquivarReferencia(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.usados.refArquivar(r.principal, id, b);
  }

  @Post('kz/usados/avaliacao')
  avaliar(@Req() r: Request, @Body() b: unknown) {
    return this.usados.avaliar(r.principal, b);
  }

  @Get('kz/usados')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  listar(@Req() r: Request, @Query() q: unknown) {
    return this.usados.listar(r.principal, q);
  }

  @Get('kz/usados/:id')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  detalhe(@Req() r: Request, @Param('id') id: string) {
    return this.usados.detalhe(r.principal, id);
  }

  @Post('kz/usados/:id/aprovar')
  aprovar(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.usados.aprovar(r.principal, id, b);
  }

  @Post('kz/usados/:id/recusar')
  recusar(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.usados.recusar(r.principal, id, b);
  }

  @Get('kz/usados/:id/termo')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  termo(@Req() r: Request, @Param('id') id: string) {
    return this.usados.termo(r.principal, id);
  }

  @Post('kz/usados/:id/termo/aceitar')
  aceitarTermo(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.usados.aceitarTermo(r.principal, id, b);
  }
}

export const KZ_USADOS_PROVIDER: Provider = {
  provide: 'KZ:USADOS',
  useFactory: (management: { db: KzDb }) => new KzUsados(management.db),
  inject: ['MANAGEMENT'],
};
