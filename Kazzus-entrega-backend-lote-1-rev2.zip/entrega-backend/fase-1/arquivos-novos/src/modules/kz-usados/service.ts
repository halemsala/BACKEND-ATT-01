// kz-usados: avaliacao de aparelho usado (trade-in) com tabela de referencia por
// modelo/grau, termo de compra em RASCUNHO e aprovacao que registra o vinculo com a
// unidade de estoque. O valor ofertado e sempre uma SUGESTAO interna (custo de
// compra): nenhum preco de venda e gravado aqui (R1) e nada e enviado ao cliente (R2).
// A entrada como unidade serial "used" no estoque usa o fluxo existente; este modulo
// registra o vinculo via `unit_ref` e emite `kz.usado.aprovado` (duvida D5).

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzFormatBRL,
  kzReady,
  kzSameVersion,
  kzStableStringify,
  kzTodayISO,
  kzValidImei,
  kzUuid,
  type KzRow,
} from '../kz-common.js';
import { kzGetSetting, kzNextCounter, kzRequireModule } from '../kz-flags.js';
import {
  kzUsadosAprovarSchema,
  kzUsadosAvaliacaoSchema,
  kzUsadosRecusarSchema,
  kzUsadosRefArquivarSchema,
  kzUsadosRefListQuery,
  kzUsadosRefSetSchema,
  kzUsadosTermoAceitarSchema,
  kzUsadosListQuery,
} from './schema.js';

const KZ_USADOS_TZ = 'America/Fortaleza';

const KZ_USADOS_TERMO_MODELO = `TERMO DE COMPRA DE APARELHO USADO (RASCUNHO INTERNO)

Loja: {{loja}}
Data: {{data}}
Avaliacao: {{numero}}

O(a) vendedor(a) declara ser o(a) legitimo(a) proprietario(a) do aparelho descrito
abaixo, que o mesmo se encontra livre de pendencias, restricoes financeiras e nao se
originou de furto ou roubo, responsabilizando-se civil e penalmente pela veracidade
das informacoes prestadas.

Aparelho: {{marca}} {{modelo}}{{armazenamento}}
IMEI: {{imei}}
Grau de conservacao: {{grau}}
Valor ofertado: R$ {{valor}} (sugestao interna, sujeita a confirmacao da loja)

Checklist de avaliacao:
{{checklist}}

Este documento e um rascunho gerado pelo modulo kz-usados do Kazzus CRM. Nenhum envio,
cobranca ou emissao e realizado por este modulo.`;

interface KzAvaliacaoRow {
  id: string;
  eval_number: string;
  status: string;
  version: number;
  device_brand: string;
  device_model: string;
  storage_label: string | null;
  imei: string | null;
  grade: string;
  suggested_min_cents: string | number | null;
  suggested_max_cents: string | number | null;
  suggested_value_cents: string | number | null;
  out_of_range: boolean;
  checklist: unknown;
  [key: string]: unknown;
}

export class KzUsados {
  constructor(private readonly db: KzDb) {}

  // ------------------------------ referencia ------------------------------

  async refSet(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/usados/referencia');
    const input = kzUsadosRefSetSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.usado.referencia_set', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'usados');
        await kzReady(tx, 'kz_tradein_reference', 'KZ_USADOS');
        const existente = (
          await tx.query(
            `SELECT id, version FROM crm.kz_tradein_reference
             WHERE workspace_id = $1 AND lower(model_label) = lower($2) AND COALESCE(storage_label, '') = COALESCE($3, '') AND grade = $4 AND archived_at IS NULL
             FOR UPDATE`,
            [p.workspaceId, input.model_label, input.storage_label ?? null, input.grade],
          )
        ).rows[0];
        let row: Record<string, unknown>;
        if (existente) {
          kzSameVersion(existente as { version: number }, input.expected_version);
          row = (
            await tx.query<KzRow>(
              `UPDATE crm.kz_tradein_reference
               SET min_value_cents = $3, max_value_cents = $4, notes = $5, active = $6, version = version + 1, updated_at = now()
               WHERE workspace_id = $1 AND id = $2 RETURNING *`,
              [p.workspaceId, existente.id, input.min_value_cents, input.max_value_cents, input.notes ?? null, input.active ?? true],
            )
          ).rows[0];
        } else {
          row = (
            await tx.query<KzRow>(
              `INSERT INTO crm.kz_tradein_reference (workspace_id, model_label, storage_label, grade, min_value_cents, max_value_cents, notes, active, created_by)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
              [p.workspaceId, input.model_label, input.storage_label ?? null, input.grade, input.min_value_cents, input.max_value_cents, input.notes ?? null, input.active ?? true, p.actorId],
            )
          ).rows[0];
        }
        await kzEvent(tx, p, 'kz.usado.referencia_alterada', row.id as string, `kz.usado.referencia:${row.id}:${row.version}`, {
          model_label: input.model_label,
          grade: input.grade,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.usado.referencia_alterada',
          entityId: row.id as string,
          payload: { model_label: input.model_label, grade: input.grade },
        });
        return row;
      }),
    );
  }

  async refArquivar(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/usados/referencia/:id/arquivar');
    const refId = kzUuid.parse(id);
    const input = kzUsadosRefArquivarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.usado.referencia_arquivar', input.idempotency_key, { ...input, id: refId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'usados');
        await kzReady(tx, 'kz_tradein_reference', 'KZ_USADOS');
        const existente = (
          await tx.query<{ id: string; version: number }>('SELECT id, version FROM crm.kz_tradein_reference WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL FOR UPDATE', [p.workspaceId, refId])
        ).rows[0];
        if (!existente) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(existente, input.expected_version);
        const row = (
          await tx.query<KzRow>(
            'UPDATE crm.kz_tradein_reference SET active = false, archived_at = now(), version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2 RETURNING *',
            [p.workspaceId, refId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.usado.referencia_alterada', refId, `kz.usado.referencia:${refId}:${row.version}`, { arquivada: true });
        await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.usado.referencia_arquivada', entityId: refId, payload: {} });
        return row;
      }),
    );
  }

  async refListar(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzUsadosRefListQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'usados');
      await kzReady(tx, 'kz_tradein_reference', 'KZ_USADOS');
      const filtros: string[] = ['workspace_id = $1', 'archived_at IS NULL'];
      const params: unknown[] = [p.workspaceId];
      if (query.model) {
        params.push(query.model);
        filtros.push(`lower(model_label) = lower($${params.length})`);
      }
      if (query.storage) {
        params.push(query.storage);
        filtros.push(`COALESCE(storage_label, '') = $${params.length}`);
      }
      if (query.ativos === 'true') filtros.push('active = true');
      return (
        await tx.query<KzRow>(`SELECT * FROM crm.kz_tradein_reference WHERE ${filtros.join(' AND ')} ORDER BY model_label, grade`, params)
      ).rows;
    });
  }

  // ------------------------------ avaliacao ------------------------------

  async avaliar(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/usados/avaliacao');
    const input = kzUsadosAvaliacaoSchema.parse(raw);
    if (input.imei !== undefined && !kzValidImei(input.imei)) throw new DomainError('IMEI_INVALID', 422);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.usado.avaliar', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'usados');
        await kzReady(tx, 'kz_tradein_evaluations', 'KZ_USADOS');
        const numero = `AT-${String(await kzNextCounter(tx, p.workspaceId, 'kz_tradein')).padStart(5, '0')}`;
        const referencia = (
          await tx.query(
            `SELECT id, min_value_cents, max_value_cents FROM crm.kz_tradein_reference
             WHERE workspace_id = $1 AND lower(model_label) = lower($2) AND COALESCE(storage_label, '') = COALESCE($3, '') AND grade = $4 AND active AND archived_at IS NULL`,
            [p.workspaceId, input.device_model, input.storage_label ?? null, input.grade],
          )
        ).rows[0];
        const minimo = referencia ? Number(referencia.min_value_cents) : null;
        const maximo = referencia ? Number(referencia.max_value_cents) : null;
        const foraDaFaixa =
          input.suggested_value_cents !== undefined && referencia !== undefined &&
          (input.suggested_value_cents < Number(referencia.min_value_cents) || input.suggested_value_cents > Number(referencia.max_value_cents));
        const row = (
          await tx.query<KzRow>(
            `INSERT INTO crm.kz_tradein_evaluations
             (workspace_id, eval_number, contact_id, device_brand, device_model, storage_label, imei, grade, checklist, reference_id, suggested_min_cents, suggested_max_cents, suggested_value_cents, out_of_range, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10, $11, $12, $13, $14, $15) RETURNING *`,
            [
              p.workspaceId,
              numero,
              input.contact_id ?? null,
              input.device_brand,
              input.device_model,
              input.storage_label ?? null,
              input.imei ?? null,
              input.grade,
              kzStableStringify(input.checklist),
              referencia?.id ?? null,
              minimo,
              maximo,
              input.suggested_value_cents ?? null,
              foraDaFaixa,
              p.actorId,
            ],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.usado.avaliado', row.id, `kz.usado.avaliado:${row.id}`, {
          eval_number: numero,
          device_model: input.device_model,
          grade: input.grade,
          suggested_min_cents: minimo,
          suggested_max_cents: maximo,
          suggested_value_cents: input.suggested_value_cents ?? null,
          out_of_range: foraDaFaixa,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.usado.avaliado',
          entityId: row.id,
          payload: { eval_number: numero, out_of_range: foraDaFaixa },
        });
        return row;
      }),
    );
  }

  async aprovar(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    return this.decidir(p, id, raw, 'aprovada');
  }

  async recusar(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    return this.decidir(p, id, raw, 'recusada');
  }

  private async decidir(p: KzPrincipal, id: string, raw: unknown, destino: 'aprovada' | 'recusada'): Promise<unknown> {
    kzAssertWrite(p, 'POST', `/kz/usados/:id/${destino === 'aprovada' ? 'aprovar' : 'recusar'}`);
    const avalId = kzUuid.parse(id);
    const input = destino === 'aprovada' ? kzUsadosAprovarSchema.parse(raw) : kzUsadosRecusarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, `kz.usado.${destino === 'aprovada' ? 'aprovar' : 'recusar'}`, input.idempotency_key, { ...input, id: avalId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'usados');
        await kzReady(tx, 'kz_tradein_evaluations', 'KZ_USADOS');
        const aval = (
          await tx.query<{ id: string; eval_number: string; status: string; version: number }>('SELECT id, eval_number, status, version FROM crm.kz_tradein_evaluations WHERE workspace_id = $1 AND id = $2 FOR UPDATE', [p.workspaceId, avalId])
        ).rows[0];
        if (!aval) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(aval, input.expected_version);
        if (aval.status !== 'avaliada') throw new DomainError('INVALID_STATE', 409);
        const row = (
          await tx.query<KzRow>(
            `UPDATE crm.kz_tradein_evaluations
             SET status = $3, decision_note = $4, decided_at = now(), decided_by = $5,
                 stocked_unit_ref = COALESCE($6, stocked_unit_ref), version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING *`,
            [p.workspaceId, avalId, destino, input.decision_note ?? null, p.actorId, destino === 'aprovada' ? ((input as { unit_ref?: string }).unit_ref ?? null) : null],
          )
        ).rows[0];
        await kzEvent(tx, p, destino === 'aprovada' ? 'kz.usado.aprovado' : 'kz.usado.recusado', avalId, `kz.usado.${destino}:${avalId}`, {
          eval_number: aval.eval_number,
          unit_ref: (row as unknown as { stocked_unit_ref: string | null }).stocked_unit_ref ?? null,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: destino === 'aprovada' ? 'kz.usado.aprovado' : 'kz.usado.recusado',
          entityId: avalId,
          payload: { eval_number: aval.eval_number },
        });
        return row;
      }),
    );
  }

  // ------------------------------ termo ------------------------------

  async termo(p: KzPrincipal, id: string): Promise<unknown> {
    kzAssertRead(p);
    const avalId = kzUuid.parse(id);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'usados');
      await kzReady(tx, 'kz_tradein_terms', 'KZ_USADOS');
      const aval = (
        await tx.query<KzRow>('SELECT * FROM crm.kz_tradein_evaluations WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL', [p.workspaceId, avalId])
      ).rows[0] as KzAvaliacaoRow | undefined;
      if (!aval) throw new DomainError('NOT_FOUND', 404);
      if (aval.status === 'cancelada') throw new DomainError('INVALID_STATE', 409);
      let termo = (
        await tx.query<KzRow>('SELECT * FROM crm.kz_tradein_terms WHERE workspace_id = $1 AND evaluation_id = $2', [p.workspaceId, avalId])
      ).rows[0];
      if (!termo) {
        const nomeLoja = (await kzGetSetting(tx, p.workspaceId, 'store_name')) ?? 'a loja';
        const texto = this.renderTermo(aval, nomeLoja);
        termo = (
          await tx.query<KzRow>(
            `INSERT INTO crm.kz_tradein_terms (workspace_id, evaluation_id, template_version, rendered_text, created_by)
             VALUES ($1, $2, 1, $3, $4) ON CONFLICT (workspace_id, evaluation_id) DO NOTHING RETURNING *`,
            [p.workspaceId, avalId, texto, p.actorId],
          )
        ).rows[0];
        if (termo) {
          await kzEvent(tx, p, 'kz.usado.termo_gerado', avalId, `kz.usado.termo:${avalId}`, { eval_number: aval.eval_number });
          await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.usado.termo_gerado', entityId: avalId, payload: { eval_number: aval.eval_number } });
        } else {
          termo = (await tx.query<KzRow>('SELECT * FROM crm.kz_tradein_terms WHERE workspace_id = $1 AND evaluation_id = $2', [p.workspaceId, avalId])).rows[0];
        }
      }
      return { ...termo, avaliacao: this.resumoAvaliacao(aval) };
    });
  }

  async aceitarTermo(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/usados/:id/termo/aceitar');
    const avalId = kzUuid.parse(id);
    const input = kzUsadosTermoAceitarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.usado.termo_aceitar', input.idempotency_key, { ...input, id: avalId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'usados');
        await kzReady(tx, 'kz_tradein_terms', 'KZ_USADOS');
        const termo = (
          await tx.query<KzRow>('SELECT * FROM crm.kz_tradein_terms WHERE workspace_id = $1 AND evaluation_id = $2 FOR UPDATE', [p.workspaceId, avalId])
        ).rows[0];
        if (!termo) throw new DomainError('TERM_NOT_FOUND', 404);
        if (termo.accepted_at) throw new DomainError('INVALID_STATE', 409);
        kzSameVersion(termo, input.expected_version);
        const row = (
          await tx.query<KzRow>(
            'UPDATE crm.kz_tradein_terms SET accepted_at = now(), version = version + 1, updated_at = now() WHERE workspace_id = $1 AND evaluation_id = $2 RETURNING *',
            [p.workspaceId, avalId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.usado.termo_aceito', avalId, `kz.usado.termo_aceito:${avalId}`, {});
        await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.usado.termo_aceito', entityId: avalId, payload: {} });
        return row;
      }),
    );
  }

  // ------------------------------ consultas ------------------------------

  async listar(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzUsadosListQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'usados');
      await kzReady(tx, 'kz_tradein_evaluations', 'KZ_USADOS');
      const filtros: string[] = ['workspace_id = $1', 'archived_at IS NULL'];
      const params: unknown[] = [p.workspaceId];
      if (query.status) {
        params.push(query.status);
        filtros.push(`status = $${params.length}`);
      }
      params.push(query.dias);
      filtros.push(`created_at >= now() - ($${params.length} || ' days')::interval`);
      return (
        await tx.query(
          `SELECT id, eval_number, contact_id, device_brand, device_model, grade, status, out_of_range, suggested_value_cents, version, created_at, updated_at
           FROM crm.kz_tradein_evaluations WHERE ${filtros.join(' AND ')} ORDER BY created_at DESC LIMIT 200`,
          params,
        )
      ).rows;
    });
  }

  async detalhe(p: KzPrincipal, id: string): Promise<unknown> {
    kzAssertRead(p);
    const avalId = kzUuid.parse(id);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'usados');
      await kzReady(tx, 'kz_tradein_evaluations', 'KZ_USADOS');
      const aval = (
        await tx.query<KzRow>('SELECT * FROM crm.kz_tradein_evaluations WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL', [p.workspaceId, avalId])
      ).rows[0];
      if (!aval) throw new DomainError('NOT_FOUND', 404);
      const termo = (
        await tx.query('SELECT id, template_version, accepted_at, version, created_at FROM crm.kz_tradein_terms WHERE workspace_id = $1 AND evaluation_id = $2', [p.workspaceId, avalId])
      ).rows[0] ?? null;
      return { ...aval, termo };
    });
  }

  // ------------------------------ apoio ------------------------------

  private renderTermo(aval: KzAvaliacaoRow, nomeLoja: string): string {
    const checklist = Array.isArray(aval.checklist) ? (aval.checklist as Array<{ label: string; ok: boolean }>) : [];
    const linhas = checklist.map((item) => `- ${item.label}: ${item.ok ? 'OK' : 'PENDENTE/NAO OK'}`).join('\n');
    return KZ_USADOS_TERMO_MODELO.replace('{{loja}}', nomeLoja)
      .replace('{{data}}', kzTodayISO(KZ_USADOS_TZ))
      .replace('{{numero}}', aval.eval_number)
      .replace('{{marca}}', aval.device_brand)
      .replace('{{modelo}}', aval.device_model)
      .replace('{{armazenamento}}', aval.storage_label ? ` (${aval.storage_label})` : '')
      .replace('{{imei}}', aval.imei ?? 'nao informado')
      .replace('{{grau}}', aval.grade)
      .replace('{{valor}}', kzFormatBRL(Number(aval.suggested_value_cents ?? 0)))
      .replace('{{checklist}}', linhas || '- (sem checklist)');
  }

  private resumoAvaliacao(aval: KzAvaliacaoRow): Record<string, unknown> {
    return {
      id: aval.id,
      eval_number: aval.eval_number,
      status: aval.status,
      device_brand: aval.device_brand,
      device_model: aval.device_model,
      grade: aval.grade,
      imei: aval.imei,
      suggested_value_cents: aval.suggested_value_cents === null ? null : Number(aval.suggested_value_cents),
    };
  }
}
