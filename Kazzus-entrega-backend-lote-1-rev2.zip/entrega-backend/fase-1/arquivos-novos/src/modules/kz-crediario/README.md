# kz-crediario

Carne do cliente: plano de parcelas, baixa manual de parcela e limite de credito
por cliente. Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Cria plano com numero legivel (`CR-00001`), parcelas mensais com data de vencimento
  (ajuste de fim de mes: 31/01 + 1 mes = 28/02) e divisao inteira dos centavos
  (o resto vai nas primeiras parcelas).
- Limite por cliente: soma dos planos ativos (total - pago) + novo plano nao pode
  passar do limite (`CREDIT_LIMIT_EXCEEDED` 409). Sem limite definido, nao bloqueia.
- Baixa de parcela (manual; data opcional); quando a ultima parcela e paga o plano
  vira `quitado`.
- Cancelamento so com plano sem pagamento (`INVALID_STATE` com parcela paga; estorno
  fica para o Lote 2).
- Posicao do cliente: em aberto, ja pago, atrasadas e proximos 30 dias.
- Job diario (PREPARADO, registra na Fase 2): emite `kz.parcela.vence_amanha` e
  `kz.parcela.atrasada` com dedupe por parcela/vencimento, atras das flags
  `KAZZUS_KZ_CREDIARIO`, linha da loja e `KAZZUS_KZ_AUTOMATIONS`.

## O que NAO faz (de proposito)

- Nao cobra, nao envia cobranca nem mensagem (R2): os eventos sao avisos internos.
- Nao move dinheiro (R3): a baixa e um registro manual.
- Nao grava preco/desconto (R1): o total financiado vem do pedido ja fechado.

## Tabelas (migracao 100)

- `crm.kz_credit_limits`, `crm.kz_credit_plans`, `crm.kz_credit_installments`.

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| POST | `kz/crediario` | `{contact_id, total_cents, installments_count, first_due (YYYY-MM-DD), order_kind?, order_id?, notes?, idempotency_key}` |
| POST | `kz/crediario/limite` | `{contact_id, limit_cents, expected_version?, idempotency_key}` |
| POST | `kz/crediario/parcela/:id/baixa` | `{paid_at?, idempotency_key}` |
| POST | `kz/crediario/:id/cancelar` | `{expected_version, idempotency_key}` |
| GET | `kz/crediario?status=&atrasadas=true` | lista planos |
| GET | `kz/crediario/cliente/:id` | posicao do cliente |
| GET | `kz/crediario/:id` | plano + parcelas (com flag `atrasada`) |

Erros: `CREDIT_LIMIT_EXCEEDED` 409, `INVALID_STATE` 409, `VERSION_CONFLICT` 409,
`NOT_FOUND` 404, `MODULE_DISABLED` 404, `FORBIDDEN` 403,
`KZ_CREDIARIO_MIGRATION_REQUIRED` 503.

## Eventos

`kz.crediario.criado`, `kz.parcela.paga`, `kz.crediario.quitado`,
`kz.crediario.cancelado`, `kz.crediario.limite_definido`, `kz.parcela.vence_amanha`
(job), `kz.parcela.atrasada` (job).

## Flags

- Processo: `KAZZUS_KZ_CREDIARIO=YES`; Loja: linha `crediario`; jobs exigem tambem
  `KAZZUS_KZ_AUTOMATIONS=YES`.

## Exige autorizacao do Anderson

- Politica de limite por cliente (valores iniciais).
- Estorno de parcela paga (Lote 2).
- O que fazer com atrasadas (hoje: so evento/alerta interno).
