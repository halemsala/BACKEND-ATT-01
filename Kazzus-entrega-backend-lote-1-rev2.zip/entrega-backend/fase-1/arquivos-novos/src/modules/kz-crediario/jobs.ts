// Jobs do kz-crediario (PREPARADOS; o registro no agendador real acontece na Fase 2
// via src/main.ts, atras de KAZZUS_KZ_CREDIARIO + KAZZUS_KZ_AUTOMATIONS, ambos "YES").
// Deterministico: nao chama modelo, nao envia nada; so emite eventos de aviso com
// dedupe (um evento por parcela por dia).

import type { KzDb } from '../kz-common.js';
import { kzAutomationsOn, kzModuleEnabled, kzProcessFlagOn } from '../kz-flags.js';
import { kzEvent } from '../kz-common.js';

const KZ_CREDIARIO_TZ = 'America/Fortaleza';

export interface KzJobDefinition {
  name: string;
  intervalMs: number;
  window?: string;
  run: () => Promise<unknown>;
}

/**
 * Varre as parcelas da loja: vencem amanha -> kz.parcela.vence_amanha;
 * atrasadas -> kz.parcela.atrasada (uma vez por parcela, dedupe por vencimento).
 * Respeita flag de processo, flag da loja e o kill switch KAZZUS_KZ_AUTOMATIONS.
 */
export async function scanCrediarioInstallments(
  db: KzDb,
  workspaceId: string,
  actorId = 'kz-crediario-job',
): Promise<{ vence_amanha: number; atrasadas: number; desligado: boolean }> {
  return db.workspace(workspaceId, async (tx) => {
    if (!kzProcessFlagOn('crediario') || !kzAutomationsOn() || !(await kzModuleEnabled(tx, workspaceId, 'crediario'))) {
      return { vence_amanha: 0, atrasadas: 0, desligado: true };
    }
    const amanha = (
      await tx.query<{ id: string; due_date: string; number: number; plan_number: string }>(
        `SELECT i.id, i.due_date::text AS due_date, i.number, pl.plan_number
         FROM crm.kz_credit_installments i
         JOIN crm.kz_credit_plans pl ON pl.workspace_id = i.workspace_id AND pl.id = i.plan_id
         WHERE i.workspace_id = $1 AND i.status = 'aberta' AND pl.status = 'ativo'
           AND i.due_date = ((now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date + 1)`,
        [workspaceId],
      )
    ).rows;
    const atrasadas = (
      await tx.query<{ id: string; due_date: string; number: number; plan_number: string }>(
        `SELECT i.id, i.due_date::text AS due_date, i.number, pl.plan_number
         FROM crm.kz_credit_installments i
         JOIN crm.kz_credit_plans pl ON pl.workspace_id = i.workspace_id AND pl.id = i.plan_id
         WHERE i.workspace_id = $1 AND i.status = 'aberta' AND pl.status = 'ativo'
           AND i.due_date < (now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date`,
        [workspaceId],
      )
    ).rows;
    const p = { workspaceId, actorId };
    for (const parcela of amanha) {
      await kzEvent(tx, p, 'kz.parcela.vence_amanha', parcela.id, `kz.parcela.vence_amanha:${parcela.id}:${parcela.due_date}`, {
        plan_number: parcela.plan_number,
        number: Number(parcela.number),
        due_date: parcela.due_date,
      });
    }
    for (const parcela of atrasadas) {
      await kzEvent(tx, p, 'kz.parcela.atrasada', parcela.id, `kz.parcela.atrasada:${parcela.id}:${parcela.due_date}`, {
        plan_number: parcela.plan_number,
        number: Number(parcela.number),
        due_date: parcela.due_date,
      });
    }
    return { vence_amanha: amanha.length, atrasadas: atrasadas.length, desligado: false };
  });
}

/** Definicao pronta para registerJob() do agendador do projeto (Fase 2). */
export function createKzCrediarioJob(db: KzDb, workspaceId: string): KzJobDefinition {
  return {
    name: 'kz-crediario-scan',
    intervalMs: 60 * 60 * 1000,
    run: () => scanCrediarioInstallments(db, workspaceId),
  };
}
