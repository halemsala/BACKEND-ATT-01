// Schemas zod do kz-crediario.

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzText, kzVersion } from '../kz-common.js';

export const kzCrediarioCriarSchema = z
  .object({
    contact_id: z.uuid(),
    total_cents: kzCents(1),
    installments_count: z.number().int().min(1).max(48),
    first_due: z.iso.date(),
    order_kind: z.enum(['order', 'quote']).optional(),
    order_id: z.uuid().optional(),
    notes: kzText(1, 500).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict()
  // Revisao 2: o vinculo com pedido/cotacao e sempre o PAR (ambos ou nenhum),
  // espelhando o CHECK kz_credit_vinculo_coerente da migracao 100.
  .refine((v) => (v.order_kind === undefined) === (v.order_id === undefined), 'order_kind e order_id andam juntos (ambos ou nenhum)');

export const kzCrediarioLimiteSchema = z
  .object({
    contact_id: z.uuid(),
    limit_cents: kzCents(0),
    expected_version: kzVersion.optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzCrediarioBaixaSchema = z
  .object({
    paid_at: z.iso.datetime({ offset: true }).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzCrediarioCancelarSchema = z
  .object({ expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzCrediarioListQuery = z
  .object({
    status: z.enum(['ativo', 'quitado', 'cancelado']).optional(),
    atrasadas: z.enum(['true', 'false']).optional(),
  })
  .strict();
