// Rotas do kz-crediario. Ordem importa: rotas literais antes de :id.

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzCrediario } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzCrediarioController {
  constructor(@Inject('KZ:CREDIARIO') private readonly crediario: KzCrediario) {}

  @Post('kz/crediario')
  criar(@Req() r: Request, @Body() b: unknown) {
    return this.crediario.criar(r.principal, b);
  }

  @Post('kz/crediario/limite')
  limite(@Req() r: Request, @Body() b: unknown) {
    return this.crediario.limite(r.principal, b);
  }

  @Post('kz/crediario/parcela/:id/baixa')
  baixar(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.crediario.baixar(r.principal, id, b);
  }

  @Get('kz/crediario')
  @Header('Cache-Control', 'private, no-store')
  listar(@Req() r: Request, @Query() q: unknown) {
    return this.crediario.listar(r.principal, q);
  }

  @Get('kz/crediario/cliente/:id')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  posicaoCliente(@Req() r: Request, @Param('id') id: string) {
    return this.crediario.posicaoCliente(r.principal, id);
  }

  @Get('kz/crediario/:id')
  @Header('Cache-Control', 'private, no-store')
  detalhe(@Req() r: Request, @Param('id') id: string) {
    return this.crediario.detalhe(r.principal, id);
  }

  @Post('kz/crediario/:id/cancelar')
  cancelar(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.crediario.cancelar(r.principal, id, b);
  }
}

export const KZ_CREDIARIO_PROVIDER: Provider = {
  provide: 'KZ:CREDIARIO',
  useFactory: (management: { db: KzDb }) => new KzCrediario(management.db),
  inject: ['MANAGEMENT'],
};
