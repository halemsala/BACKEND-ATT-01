// Eventos do kz-crediario.

export const KZ_CREDIARIO_EVENTS = [
  'kz.crediario.criado',
  'kz.crediario.quitado',
  'kz.crediario.cancelado',
  'kz.crediario.limite_definido',
  'kz.parcela.paga',
  'kz.parcela.vence_amanha',
  'kz.parcela.atrasada',
] as const;

export interface KzCrediarioCriadoPayload {
  plan_number: string;
  contact_id: string;
  total_cents: number;
  installments_count: number;
  first_due: string;
}

export interface KzParcelaPagaPayload {
  plan_number: string;
  number: number;
  amount_cents: number;
}
