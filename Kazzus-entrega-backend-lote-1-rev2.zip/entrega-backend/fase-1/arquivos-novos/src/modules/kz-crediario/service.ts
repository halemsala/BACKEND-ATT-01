// kz-crediario: carne (plano de parcelas), baixa de parcela e limite de credito
// por cliente. Valores em centavos, divisao inteira (resto nas primeiras parcelas)
// e vencimentos mensais com ajuste de fim de mes. Nao cobra nada automaticamente
// (R2/R3): a baixa e manual e o job diario so EMITE EVENTOS de aviso.

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzReady,
  kzSameVersion,
  kzSplitCents,
  kzUuid,
  type KzRow,
} from '../kz-common.js';
import { kzNextCounter, kzRequireModule } from '../kz-flags.js';
import {
  kzCrediarioBaixaSchema,
  kzCrediarioCancelarSchema,
  kzCrediarioCriarSchema,
  kzCrediarioLimiteSchema,
  kzCrediarioListQuery,
} from './schema.js';

const KZ_CREDIARIO_TZ = 'America/Fortaleza';

/** Soma N meses a uma data ISO (YYYY-MM-DD) com ajuste de fim de mes. */
export function kzAddMonthsISO(iso: string, meses: number): string {
  const [ano, mes, dia] = iso.split('-').map(Number);
  const alvo = new Date(Date.UTC(ano, mes - 1 + meses, 1));
  const ultimoDia = new Date(Date.UTC(alvo.getUTCFullYear(), alvo.getUTCMonth() + 1, 0)).getUTCDate();
  alvo.setUTCDate(Math.min(dia, ultimoDia));
  return alvo.toISOString().slice(0, 10);
}

interface KzPlanoRow {
  id: string;
  plan_number: string;
  contact_id: string;
  status: string;
  version: number;
  total_cents: string | number;
  paid_cents: string | number;
  [key: string]: unknown;
}

export class KzCrediario {
  constructor(private readonly db: KzDb) {}

  async criar(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/crediario');
    const input = kzCrediarioCriarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.crediario.criar', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'crediario');
        await kzReady(tx, 'kz_credit_plans', 'KZ_CREDIARIO');
        // limite por cliente (se definido): saldo aberto + novo total nao pode passar
        const limite = (
          await tx.query<{ limit_cents: string | number }>('SELECT limit_cents FROM crm.kz_credit_limits WHERE workspace_id = $1 AND contact_id = $2', [
            p.workspaceId,
            input.contact_id,
          ])
        ).rows[0];
        if (limite) {
          const aberto = (
            await tx.query<{ total: string | number }>(
              `SELECT COALESCE(sum(total_cents - paid_cents), 0) AS total FROM crm.kz_credit_plans
               WHERE workspace_id = $1 AND contact_id = $2 AND status = 'ativo' AND archived_at IS NULL`,
              [p.workspaceId, input.contact_id],
            )
          ).rows[0];
          if (Number(aberto.total) + input.total_cents > Number(limite.limit_cents)) {
            throw new DomainError('CREDIT_LIMIT_EXCEEDED', 409);
          }
        }
        const numero = `CR-${String(await kzNextCounter(tx, p.workspaceId, 'kz_crediario')).padStart(5, '0')}`;
        const plano = (
          await tx.query<KzRow>(
            `INSERT INTO crm.kz_credit_plans (workspace_id, plan_number, contact_id, order_kind, order_id, total_cents, installments_count, first_due, notes, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
            [
              p.workspaceId,
              numero,
              input.contact_id,
              input.order_kind ?? null,
              input.order_id ?? null,
              input.total_cents,
              input.installments_count,
              input.first_due,
              input.notes ?? null,
              p.actorId,
            ],
          )
        ).rows[0];
        const valores = kzSplitCents(input.total_cents, input.installments_count);
        const parcelas: Record<string, unknown>[] = [];
        for (let i = 0; i < valores.length; i++) {
          parcelas.push(
            (
              await tx.query<KzRow>(
                `INSERT INTO crm.kz_credit_installments (workspace_id, plan_id, number, due_date, amount_cents, created_by)
                 VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
                [p.workspaceId, plano.id, i + 1, kzAddMonthsISO(input.first_due, i), valores[i], p.actorId],
              )
            ).rows[0],
          );
        }
        await kzEvent(tx, p, 'kz.crediario.criado', plano.id, `kz.crediario.criado:${plano.id}`, {
          plan_number: numero,
          contact_id: input.contact_id,
          total_cents: input.total_cents,
          installments_count: input.installments_count,
          first_due: input.first_due,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.crediario.criado',
          entityId: plano.id,
          payload: { plan_number: numero, total_cents: input.total_cents, installments_count: input.installments_count },
        });
        return { ...plano, parcelas };
      }),
    );
  }

  async limite(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/crediario/limite');
    const input = kzCrediarioLimiteSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.crediario.limite', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'crediario');
        await kzReady(tx, 'kz_credit_limits', 'KZ_CREDIARIO');
        const existente = (
          await tx.query<{ version: number }>('SELECT version FROM crm.kz_credit_limits WHERE workspace_id = $1 AND contact_id = $2 FOR UPDATE', [
            p.workspaceId,
            input.contact_id,
          ])
        ).rows[0];
        let row: Record<string, unknown>;
        if (existente) {
          kzSameVersion(existente, input.expected_version);
          row = (
            await tx.query<KzRow>(
              'UPDATE crm.kz_credit_limits SET limit_cents = $3, version = version + 1, updated_at = now() WHERE workspace_id = $1 AND contact_id = $2 RETURNING *',
              [p.workspaceId, input.contact_id, input.limit_cents],
            )
          ).rows[0];
        } else {
          row = (
            await tx.query<KzRow>(
              'INSERT INTO crm.kz_credit_limits (workspace_id, contact_id, limit_cents, created_by) VALUES ($1, $2, $3, $4) RETURNING *',
              [p.workspaceId, input.contact_id, input.limit_cents, p.actorId],
            )
          ).rows[0];
        }
        await kzEvent(tx, p, 'kz.crediario.limite_definido', input.contact_id, `kz.crediario.limite:${input.contact_id}:${row.version}`, {
          contact_id: input.contact_id,
          limit_cents: input.limit_cents,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.crediario.limite_definido',
          entityId: input.contact_id,
          payload: { limit_cents: input.limit_cents },
        });
        return row;
      }),
    );
  }

  async baixar(p: KzPrincipal, parcelaId: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/crediario/parcela/:id/baixa');
    const id = kzUuid.parse(parcelaId);
    const input = kzCrediarioBaixaSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.crediario.baixa', input.idempotency_key, { ...input, id }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'crediario');
        await kzReady(tx, 'kz_credit_installments', 'KZ_CREDIARIO');
        const parcela = (
          await tx.query<{
            id: string;
            plan_id: string;
            number: number;
            amount_cents: string | number;
            status: string;
            [key: string]: unknown;
          }>('SELECT * FROM crm.kz_credit_installments WHERE workspace_id = $1 AND id = $2 FOR UPDATE', [p.workspaceId, id])
        ).rows[0];
        if (!parcela) throw new DomainError('NOT_FOUND', 404);
        const plano = (
          await tx.query<KzRow>('SELECT * FROM crm.kz_credit_plans WHERE workspace_id = $1 AND id = $2 FOR UPDATE', [p.workspaceId, parcela.plan_id])
        ).rows[0] as KzPlanoRow;
        if (!plano) throw new DomainError('NOT_FOUND', 404);
        if (parcela.status !== 'aberta') throw new DomainError('INVALID_STATE', 409);
        if (plano.status !== 'ativo') throw new DomainError('INVALID_STATE', 409);
        const parcelaPaga = (
          await tx.query<KzRow>(
            `UPDATE crm.kz_credit_installments
             SET status = 'paga', paid_cents = $3, paid_at = COALESCE($4::timestamptz, now()), paid_by = $5, version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING *`,
            [p.workspaceId, id, parcela.amount_cents, input.paid_at ?? null, p.actorId],
          )
        ).rows[0];
        const novoPago = Number(plano.paid_cents) + Number(parcela.amount_cents);
        const restantes = (
          await tx.query<{ c: number }>("SELECT count(*)::int AS c FROM crm.kz_credit_installments WHERE workspace_id = $1 AND plan_id = $2 AND status = 'aberta'", [
            p.workspaceId,
            plano.id,
          ])
        ).rows[0];
        const quitado = Number(restantes.c) === 0;
        const planoAtualizado = (
          await tx.query<KzRow>(
            `UPDATE crm.kz_credit_plans
             SET paid_cents = $3, status = CASE WHEN $4 THEN 'quitado' ELSE status END, version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING *`,
            [p.workspaceId, plano.id, novoPago, quitado],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.parcela.paga', parcela.id, `kz.parcela.paga:${parcela.id}`, {
          plan_number: plano.plan_number,
          number: Number(parcela.number),
          amount_cents: Number(parcela.amount_cents),
        });
        if (quitado) {
          await kzEvent(tx, p, 'kz.crediario.quitado', plano.id, `kz.crediario.quitado:${plano.id}`, { plan_number: plano.plan_number });
        }
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.parcela.paga',
          entityId: parcela.id,
          payload: { plan_number: plano.plan_number, number: Number(parcela.number) },
        });
        return { parcela: parcelaPaga, plano: planoAtualizado };
      }),
    );
  }

  async cancelar(p: KzPrincipal, planoId: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/crediario/:id/cancelar');
    const id = kzUuid.parse(planoId);
    const input = kzCrediarioCancelarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.crediario.cancelar', input.idempotency_key, { ...input, id }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'crediario');
        await kzReady(tx, 'kz_credit_plans', 'KZ_CREDIARIO');
        const plano = (
          await tx.query<KzRow>('SELECT * FROM crm.kz_credit_plans WHERE workspace_id = $1 AND id = $2 FOR UPDATE', [p.workspaceId, id])
        ).rows[0] as KzPlanoRow;
        if (!plano) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(plano, input.expected_version);
        if (plano.status !== 'ativo') throw new DomainError('INVALID_STATE', 409);
        if (Number(plano.paid_cents) > 0) {
          throw new DomainError('INVALID_STATE', 409); // com parcela paga exige estorno (Lote 2)
        }
        const row = (
          await tx.query<KzRow>(
            "UPDATE crm.kz_credit_plans SET status = 'cancelado', version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2 RETURNING *",
            [p.workspaceId, id],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.crediario.cancelado', id, `kz.crediario.cancelado:${id}`, { plan_number: plano.plan_number });
        await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.crediario.cancelado', entityId: id, payload: { plan_number: plano.plan_number } });
        return row;
      }),
    );
  }

  async posicaoCliente(p: KzPrincipal, contactId: string): Promise<unknown> {
    kzAssertRead(p);
    const contato = kzUuid.parse(contactId);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'crediario');
      await kzReady(tx, 'kz_credit_plans', 'KZ_CREDIARIO');
      const limite = (
        await tx.query<{ limit_cents: string | number }>('SELECT limit_cents FROM crm.kz_credit_limits WHERE workspace_id = $1 AND contact_id = $2', [p.workspaceId, contato])
      ).rows[0];
      const planos = (
        await tx.query<KzRow>(
          `SELECT * FROM crm.kz_credit_plans WHERE workspace_id = $1 AND contact_id = $2 AND archived_at IS NULL ORDER BY created_at DESC`,
          [p.workspaceId, contato],
        )
      ).rows;
      const resumo = (
        await tx.query(
          `SELECT
             COALESCE(sum(CASE WHEN p.status = 'ativo' THEN p.total_cents - p.paid_cents ELSE 0 END), 0) AS em_aberto,
             COALESCE(sum(CASE WHEN p.status = 'ativo' THEN p.paid_cents ELSE 0 END), 0) AS ja_pago
           FROM crm.kz_credit_plans p WHERE p.workspace_id = $1 AND p.contact_id = $2`,
          [p.workspaceId, contato],
        )
      ).rows[0];
      const atrasadas = (
        await tx.query(
          `SELECT i.* FROM crm.kz_credit_installments i
           JOIN crm.kz_credit_plans pl ON pl.workspace_id = i.workspace_id AND pl.id = i.plan_id
           WHERE i.workspace_id = $1 AND pl.contact_id = $2 AND i.status = 'aberta'
             AND i.due_date < (now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date
           ORDER BY i.due_date`,
          [p.workspaceId, contato],
        )
      ).rows;
      const proximas = (
        await tx.query(
          `SELECT i.* FROM crm.kz_credit_installments i
           JOIN crm.kz_credit_plans pl ON pl.workspace_id = i.workspace_id AND pl.id = i.plan_id
           WHERE i.workspace_id = $1 AND pl.contact_id = $2 AND i.status = 'aberta'
             AND i.due_date >= (now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date
             AND i.due_date <= ((now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date + 30)
           ORDER BY i.due_date`,
          [p.workspaceId, contato],
        )
      ).rows;
      return {
        contact_id: contato,
        limite_cents: limite ? Number(limite.limit_cents) : null,
        em_aberto_cents: Number(resumo.em_aberto),
        ja_pago_cents: Number(resumo.ja_pago),
        parcelas_atrasadas: atrasadas,
        parcelas_proximas_30_dias: proximas,
        planos,
      };
    });
  }

  async listar(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzCrediarioListQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'crediario');
      await kzReady(tx, 'kz_credit_plans', 'KZ_CREDIARIO');
      const filtros: string[] = ['workspace_id = $1', 'archived_at IS NULL'];
      const params: unknown[] = [p.workspaceId];
      if (query.status) {
        params.push(query.status);
        filtros.push(`status = $${params.length}`);
      }
      if (query.atrasadas === 'true') {
        filtros.push(
          `EXISTS (SELECT 1 FROM crm.kz_credit_installments i WHERE i.workspace_id = crm.kz_credit_plans.workspace_id AND i.plan_id = crm.kz_credit_plans.id AND i.status = 'aberta' AND i.due_date < (now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date)`,
        );
      }
      return (
        await tx.query(
          `SELECT id, plan_number, contact_id, total_cents, paid_cents, installments_count, first_due, status, version, created_at, updated_at
           FROM crm.kz_credit_plans WHERE ${filtros.join(' AND ')} ORDER BY created_at DESC LIMIT 200`,
          params,
        )
      ).rows;
    });
  }

  async detalhe(p: KzPrincipal, planoId: string): Promise<unknown> {
    kzAssertRead(p);
    const id = kzUuid.parse(planoId);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'crediario');
      await kzReady(tx, 'kz_credit_plans', 'KZ_CREDIARIO');
      const plano = (
        await tx.query<KzRow>('SELECT * FROM crm.kz_credit_plans WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL', [p.workspaceId, id])
      ).rows[0];
      if (!plano) throw new DomainError('NOT_FOUND', 404);
      const parcelas = (
        await tx.query(
          `SELECT *, (status = 'aberta' AND due_date < (now() AT TIME ZONE '${KZ_CREDIARIO_TZ}')::date) AS atrasada
           FROM crm.kz_credit_installments WHERE workspace_id = $1 AND plan_id = $2 AND archived_at IS NULL ORDER BY number`,
          [p.workspaceId, id],
        )
      ).rows;
      return { ...plano, parcelas };
    });
  }
}
