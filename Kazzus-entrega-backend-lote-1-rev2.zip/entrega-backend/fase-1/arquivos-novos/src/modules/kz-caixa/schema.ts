// Schemas zod do kz-caixa (entrada strict, no padrao do projeto).

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzText, kzVersion } from '../kz-common.js';

export const kzCaixaAberturaSchema = z
  .object({
    opening_cents: kzCents(0),
    note: kzText(1, 500).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzCaixaMovimentoSchema = z
  .object({
    session_id: z.uuid(),
    amount_cents: kzCents(1),
    reason: kzText(1, 500),
    expected_version: kzVersion,
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzCaixaFechamentoSchema = z
  .object({
    session_id: z.uuid(),
    counted_cents: kzCents(0),
    declared_sales_cash_cents: kzCents(0).optional(),
    note: kzText(1, 500).optional(),
    expected_version: kzVersion,
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzCaixaHistoricoQuery = z
  .object({ dias: z.coerce.number().int().min(1).max(90).default(30) })
  .strict();

export type KzCaixaAbertura = z.infer<typeof kzCaixaAberturaSchema>;
export type KzCaixaMovimento = z.infer<typeof kzCaixaMovimentoSchema>;
export type KzCaixaFechamento = z.infer<typeof kzCaixaFechamentoSchema>;
