# kz-caixa

Caixa do dia: abertura (troco inicial), sangria (retirada), reforco e fechamento com
conferencia cega. Faz parte do Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Uma sessao de caixa aberta por loja (indice unico parcial garante a regra no banco).
- Sangria/reforco com motivo obrigatorio e concorrencia otimista (`expected_version`).
- Fechamento com conferencia cega: o operador informa a contagem e as vendas em
  dinheiro declaradas; o esperado e a diferenca so sao calculados e devolvidos depois.
- `esperado = troco inicial + reforcos - sangrias + vendas em dinheiro declaradas`.
- Toda escrita segue o padrao do contrato: uuid, papel, zod strict com
  `idempotency_key`, RLS por loja, recibo de idempotencia, evento no outbox kz e
  registro na trilha de auditoria kz.

## O que NAO faz (de proposito)

- Nao move dinheiro real, nao chama gateway/banco (R3).
- Nao lanca no financeiro atual (`finance_entries`); integracao fica para o Lote 2
  apos confirmar o schema real (duvida D4).
- Nao envia nada para fora (R2) e nao toca preco/desconto/cupom (R1).

## Tabelas (migracao 095)

- `crm.kz_cash_sessions` - sessao (abertura, status, contagem, esperado, diferenca).
- `crm.kz_cash_movements` - sangrias e reforcos com motivo.

## Rotas

| Metodo | Rota |Descricao|
|---|---|---|
| GET | `kz/caixa/hoje` | sessao aberta + fechadas de hoje (fuso America/Fortaleza) |
| GET | `kz/caixa/historico?dias=30` | sessoes dos ultimos N dias (1..90) |
| GET | `kz/caixa/:id` | sessao + movimentos |
| POST | `kz/caixa/abrir` | `{opening_cents, note?, idempotency_key}` |
| POST | `kz/caixa/sangria` | `{session_id, amount_cents, reason, expected_version, idempotency_key}` |
| POST | `kz/caixa/reforco` | idem sangria |
| POST | `kz/caixa/fechar` | `{session_id, counted_cents, declared_sales_cash_cents?, note?, expected_version, idempotency_key}` |

Erros: `CAIXA_ALREADY_OPEN` 409, `INVALID_STATE` 409, `VERSION_CONFLICT` 409,
`NOT_FOUND` 404, `MODULE_DISABLED` 404, `FORBIDDEN` 403, `KZ_CAIXA_MIGRATION_REQUIRED` 503.

## Eventos (outbox kz)

`kz.caixa.aberto`, `kz.caixa.movimento`, `kz.caixa.fechado`, `kz.caixa.diferenca`
(esta ultima so quando a diferenca nao e zero).

## Flags

- Processo: `KAZZUS_KZ_CAIXA=YES`
- Loja: linha `caixa` habilitada em `crm.kz_feature_flags` (via `POST kz/flags`)
- Desligado por padrao em ambos os niveis.

## Exige autorizacao do Anderson

- Ajustar `vendas em dinheiro declaradas` para ler dos pedidos reais (adaptador).
- Integrar fechamento com o financeiro atual.
- Aprovacao de sangria acima de um limite (futuro passo de PIN via kz-seguranca).
