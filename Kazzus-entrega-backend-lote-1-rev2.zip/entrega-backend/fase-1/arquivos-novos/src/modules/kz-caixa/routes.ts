// Rotas do kz-caixa (controller fino, padrao do projeto: recebe principal e repassa).

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzCaixa } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzCaixaController {
  constructor(@Inject('KZ:CAIXA') private readonly caixa: KzCaixa) {}

  @Get('kz/caixa/hoje')
  @Header('Cache-Control', 'private, no-store')
  hoje(@Req() r: Request) {
    return this.caixa.hoje(r.principal);
  }

  @Get('kz/caixa/historico')
  @Header('Cache-Control', 'private, no-store')
  historico(@Req() r: Request, @Query() q: unknown) {
    return this.caixa.historico(r.principal, q);
  }

  @Get('kz/caixa/:id')
  @Header('Cache-Control', 'private, no-store')
  detalhe(@Req() r: Request, @Param('id') id: string) {
    return this.caixa.detalhe(r.principal, id);
  }

  @Post('kz/caixa/abrir')
  abrir(@Req() r: Request, @Body() b: unknown) {
    return this.caixa.abrir(r.principal, b);
  }

  @Post('kz/caixa/sangria')
  sangria(@Req() r: Request, @Body() b: unknown) {
    return this.caixa.sangria(r.principal, b);
  }

  @Post('kz/caixa/reforco')
  reforco(@Req() r: Request, @Body() b: unknown) {
    return this.caixa.reforco(r.principal, b);
  }

  @Post('kz/caixa/fechar')
  fechar(@Req() r: Request, @Body() b: unknown) {
    return this.caixa.fechar(r.principal, b);
  }
}

export const KZ_CAIXA_PROVIDER: Provider = {
  provide: 'KZ:CAIXA',
  useFactory: (management: { db: KzDb }) => new KzCaixa(management.db),
  inject: ['MANAGEMENT'],
};
