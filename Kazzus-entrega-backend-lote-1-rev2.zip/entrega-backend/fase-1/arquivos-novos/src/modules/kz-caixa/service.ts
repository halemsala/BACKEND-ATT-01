// kz-caixa: caixa do dia com abertura, sangria, reforco e fechamento com conferencia
// cega (o esperado e a diferenca so aparecem DEPOIS de informar a contagem).
// Nao move dinheiro real (R3: pagamentos seguem em modo demo) e nao integra
// lancamentos no financeiro atual (isso fica para o Lote 2, com o schema real).

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzReady,
  kzSameVersion,
  kzTodayISO,
  kzUuid,
  type KzRow,
} from '../kz-common.js';
import { kzRequireModule } from '../kz-flags.js';
import {
  kzCaixaAberturaSchema,
  kzCaixaFechamentoSchema,
  kzCaixaHistoricoQuery,
  kzCaixaMovimentoSchema,
} from './schema.js';

/** Fuso usado para definir o "dia" do caixa (Paraiba = America/Fortaleza). */
export const KZ_CAIXA_TZ = 'America/Fortaleza';

interface KzCaixaSessaoRow {
  id: string;
  status: string;
  version: number;
  opening_cents: string | number;
  [key: string]: unknown;
}

export class KzCaixa {
  constructor(private readonly db: KzDb) {}

  async abrir(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/caixa/abrir');
    const input = kzCaixaAberturaSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.caixa.abrir', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'caixa');
        await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
        const aberta = (
          await tx.query<{ id: string }>(
            "SELECT id FROM crm.kz_cash_sessions WHERE workspace_id = $1 AND status = 'aberta' AND archived_at IS NULL FOR UPDATE",
            [p.workspaceId],
          )
        ).rows[0];
        if (aberta) throw new DomainError('CAIXA_ALREADY_OPEN', 409);
        const row = (
          await tx.query<KzRow>(
            'INSERT INTO crm.kz_cash_sessions (workspace_id, opening_cents, opened_by, note, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [p.workspaceId, input.opening_cents, p.actorId, input.note ?? null, p.actorId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.caixa.aberto', row.id, `kz.caixa.aberto:${row.id}`, {
          opening_cents: input.opening_cents,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.caixa.aberto',
          entityId: row.id,
          payload: { opening_cents: input.opening_cents },
        });
        return row;
      }),
    );
  }

  async sangria(p: KzPrincipal, raw: unknown): Promise<unknown> {
    return this.movimento(p, raw, 'sangria');
  }

  async reforco(p: KzPrincipal, raw: unknown): Promise<unknown> {
    return this.movimento(p, raw, 'reforco');
  }

  private async movimento(p: KzPrincipal, raw: unknown, type: 'sangria' | 'reforco'): Promise<unknown> {
    kzAssertWrite(p, 'POST', `/kz/caixa/${type}`);
    const input = kzCaixaMovimentoSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, `kz.caixa.${type}`, input.idempotency_key, { ...input, type }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'caixa');
        await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
        const sessao = (
          await tx.query<{ id: string; version: number; status: string }>(
            'SELECT id, version, status FROM crm.kz_cash_sessions WHERE workspace_id = $1 AND id = $2 FOR UPDATE',
            [p.workspaceId, input.session_id],
          )
        ).rows[0];
        if (!sessao) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(sessao, input.expected_version);
        if (sessao.status !== 'aberta') throw new DomainError('INVALID_STATE', 409);
        const mov = (
          await tx.query<KzRow>(
            'INSERT INTO crm.kz_cash_movements (workspace_id, session_id, type, amount_cents, reason, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [p.workspaceId, input.session_id, type, input.amount_cents, input.reason, p.actorId],
          )
        ).rows[0];
        await tx.query(
          'UPDATE crm.kz_cash_sessions SET version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2',
          [p.workspaceId, input.session_id],
        );
        await kzEvent(tx, p, 'kz.caixa.movimento', mov.id, `kz.caixa.movimento:${mov.id}`, {
          session_id: input.session_id,
          type,
          amount_cents: input.amount_cents,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.caixa.movimento',
          entityId: mov.id,
          payload: { session_id: input.session_id, type, amount_cents: input.amount_cents },
        });
        return mov;
      }),
    );
  }

  async fechar(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/caixa/fechar');
    const input = kzCaixaFechamentoSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.caixa.fechar', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'caixa');
        await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
        const sessao = (
          await tx.query<KzCaixaSessaoRow>(
            'SELECT id, version, status, opening_cents FROM crm.kz_cash_sessions WHERE workspace_id = $1 AND id = $2 FOR UPDATE',
            [p.workspaceId, input.session_id],
          )
        ).rows[0];
        if (!sessao) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(sessao, input.expected_version);
        if (sessao.status !== 'aberta') throw new DomainError('INVALID_STATE', 409);
        const liquido = (
          await tx.query<{ total: string | number }>(
            `SELECT COALESCE(sum(CASE WHEN type = 'reforco' THEN amount_cents ELSE -amount_cents END), 0) AS total
             FROM crm.kz_cash_movements WHERE workspace_id = $1 AND session_id = $2 AND archived_at IS NULL`,
            [p.workspaceId, input.session_id],
          )
        ).rows[0];
        const vendas = input.declared_sales_cash_cents ?? 0;
        const esperado = Number(sessao.opening_cents) + Number(liquido.total) + vendas;
        const diferenca = input.counted_cents - esperado;
        const row = (
          await tx.query<KzRow>(
            `UPDATE crm.kz_cash_sessions
             SET status = 'fechada', closed_at = now(), closed_by = $3, counted_cents = $4,
                 declared_sales_cash_cents = $5, expected_cents = $6, difference_cents = $7,
                 close_note = $8, version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING *`,
            [p.workspaceId, input.session_id, p.actorId, input.counted_cents, vendas, esperado, diferenca, input.note ?? null],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.caixa.fechado', row.id, `kz.caixa.fechado:${row.id}`, {
          expected_cents: esperado,
          counted_cents: input.counted_cents,
          difference_cents: diferenca,
        });
        if (diferenca !== 0) {
          await kzEvent(tx, p, 'kz.caixa.diferenca', row.id, `kz.caixa.diferenca:${row.id}`, {
            expected_cents: esperado,
            counted_cents: input.counted_cents,
            difference_cents: diferenca,
          });
        }
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.caixa.fechado',
          entityId: row.id,
          payload: { expected_cents: esperado, counted_cents: input.counted_cents, difference_cents: diferenca },
        });
        return row;
      }),
    );
  }

  async hoje(p: KzPrincipal): Promise<unknown> {
    kzAssertRead(p);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'caixa');
      await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
      const colunas = `s.*,
        (SELECT COALESCE(sum(CASE WHEN m.type = 'reforco' THEN m.amount_cents ELSE -m.amount_cents END), 0)
         FROM crm.kz_cash_movements m WHERE m.workspace_id = s.workspace_id AND m.session_id = s.id AND m.archived_at IS NULL) AS movements_net_cents`;
      const aberta = (
        await tx.query(
          `SELECT ${colunas} FROM crm.kz_cash_sessions s
           WHERE s.workspace_id = $1 AND s.status = 'aberta' AND s.archived_at IS NULL
           ORDER BY s.opened_at DESC LIMIT 1`,
          [p.workspaceId],
        )
      ).rows[0] ?? null;
      const fechadasHoje = (
        await tx.query(
          `SELECT ${colunas} FROM crm.kz_cash_sessions s
           WHERE s.workspace_id = $1 AND s.status = 'fechada' AND s.archived_at IS NULL
             AND (s.closed_at AT TIME ZONE '${KZ_CAIXA_TZ}')::date = (now() AT TIME ZONE '${KZ_CAIXA_TZ}')::date
           ORDER BY s.closed_at DESC LIMIT 50`,
          [p.workspaceId],
        )
      ).rows;
      return { hoje: kzTodayISO(KZ_CAIXA_TZ), aberta, fechadas_hoje: fechadasHoje };
    });
  }

  async historico(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzCaixaHistoricoQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'caixa');
      await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
      return (
        await tx.query(
          `SELECT s.*,
             (SELECT count(*)::int FROM crm.kz_cash_movements m WHERE m.workspace_id = s.workspace_id AND m.session_id = s.id AND m.archived_at IS NULL) AS movements_count
           FROM crm.kz_cash_sessions s
           WHERE s.workspace_id = $1 AND s.archived_at IS NULL
             AND s.opened_at >= now() - ($2 || ' days')::interval
           ORDER BY s.opened_at DESC LIMIT 120`,
          [p.workspaceId, String(query.dias)],
        )
      ).rows;
    });
  }

  async detalhe(p: KzPrincipal, id: string): Promise<unknown> {
    kzAssertRead(p);
    const sessionId = kzUuid.parse(id);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'caixa');
      await kzReady(tx, 'kz_cash_sessions', 'KZ_CAIXA');
      const sessao = (
        await tx.query(
          `SELECT s.*,
             (SELECT COALESCE(sum(CASE WHEN m.type = 'reforco' THEN m.amount_cents ELSE -m.amount_cents END), 0)
              FROM crm.kz_cash_movements m WHERE m.workspace_id = s.workspace_id AND m.session_id = s.id AND m.archived_at IS NULL) AS movements_net_cents
           FROM crm.kz_cash_sessions s WHERE s.workspace_id = $1 AND s.id = $2 AND s.archived_at IS NULL`,
          [p.workspaceId, sessionId],
        )
      ).rows[0];
      if (!sessao) throw new DomainError('NOT_FOUND', 404);
      const movimentos = (
        await tx.query<KzRow>(
          'SELECT * FROM crm.kz_cash_movements WHERE workspace_id = $1 AND session_id = $2 AND archived_at IS NULL ORDER BY created_at',
          [p.workspaceId, sessionId],
        )
      ).rows;
      return { ...sessao, movimentos };
    });
  }
}
