// Eventos do kz-caixa (prefixo kz.caixa.*, dedupe por (workspace, dedupe_key)).

export const KZ_CAIXA_EVENTS = [
  'kz.caixa.aberto',
  'kz.caixa.movimento',
  'kz.caixa.fechado',
  'kz.caixa.diferenca',
] as const;

export interface KzCaixaAbertoPayload {
  opening_cents: number;
  opened_at: string;
}

export interface KzCaixaMovimentoPayload {
  session_id: string;
  type: 'sangria' | 'reforco';
  amount_cents: number;
}

export interface KzCaixaFechadoPayload {
  expected_cents: number;
  counted_cents: number;
  difference_cents: number;
}

export interface KzCaixaDiferencaPayload extends KzCaixaFechadoPayload {}
