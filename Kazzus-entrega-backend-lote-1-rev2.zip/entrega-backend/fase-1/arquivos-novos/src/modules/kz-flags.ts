// kz-flags: plano de controle dos modulos kz.
// - Flags por processo (KAZZUS_KZ_<MODULO> = "YES") E por loja (crm.kz_feature_flags):
//   um modulo so funciona com as duas ligadas (padrao do safety-gates, regra R6).
// - Kill switch geral de automacoes: KAZZUS_KZ_AUTOMATIONS = "YES" (Fase 2).
// - Ajustes da loja (crm.kz_settings) e contadores (crm.kz_counters).
// O plano de controle NAO tem flag propria: sem ele seria impossivel ligar qualquer
// modulo por loja (duvida D9 do mapa, pendente de OK do Anderson).
// Escrita so para operator/admin; leitura para qualquer humano; agentes bloqueados.

import { Body, Controller, Get, Header, Inject, Param, Post, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import { z } from 'zod';
import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  type KzTx,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzIdempotencyKey,
  kzReady,
  kzSameVersion,
  kzText,
  kzVersion,
} from './kz-common.js';

/** Registro unico de modulos kz (mantido em sincronia com as pastas de src/modules). */
export const KZ_MODULES = ['caixa', 'taxas', 'os', 'usados', 'pagamento-misto', 'crediario', 'seguranca'] as const;
export type KzModule = (typeof KZ_MODULES)[number];

const KZ_PROCESS_PREFIX = 'KAZZUS_KZ_';
const KZ_AUTOMATIONS_ENV = 'KAZZUS_KZ_AUTOMATIONS';

export function kzProcessFlagOn(module: string): boolean {
  const name = `${KZ_PROCESS_PREFIX}${module.toUpperCase().replace(/-/g, '_')}`;
  return process.env[name] === 'YES';
}

/** Kill switch geral das automacoes (jobs). Desligado por padrao. */
export function kzAutomationsOn(): boolean {
  return process.env[KZ_AUTOMATIONS_ENV] === 'YES';
}

async function kzFlagsTableExists(tx: KzTx): Promise<boolean> {
  const row = (await tx.query<{ ok: boolean | null }>(`SELECT to_regclass('crm.kz_feature_flags') IS NOT NULL AS ok`))
    .rows[0];
  return row?.ok === true;
}

/** Modulo habilitado = flag de processo LIGADA E linha habilitada na loja. */
export async function kzModuleEnabled(tx: KzTx, workspaceId: string, module: string): Promise<boolean> {
  if (!kzProcessFlagOn(module)) return false;
  if (!(await kzFlagsTableExists(tx))) return false;
  const row = (
    await tx.query<{ enabled: boolean }>('SELECT enabled FROM crm.kz_feature_flags WHERE workspace_id = $1 AND module = $2', [
      workspaceId,
      module,
    ])
  ).rows[0];
  return row?.enabled === true;
}

/** Lanca MODULE_DISABLED (404) quando o modulo esta desligado para a loja. */
export async function kzRequireModule(tx: KzTx, workspaceId: string, module: string): Promise<void> {
  if (!(await kzModuleEnabled(tx, workspaceId, module))) throw new DomainError('MODULE_DISABLED', 404);
}

/** Contador por loja (numeros legiveis de OS, carnes e avaliacoes). */
export async function kzNextCounter(tx: KzTx, workspaceId: string, name: string): Promise<number> {
  const row = (
    await tx.query<{ value: string | number }>(
      `INSERT INTO crm.kz_counters (workspace_id, name, value) VALUES ($1, $2, 1)
       ON CONFLICT (workspace_id, name) DO UPDATE SET value = crm.kz_counters.value + 1, updated_at = now()
       RETURNING value`,
      [workspaceId, name],
    )
  ).rows[0];
  return Number(row.value);
}

/** Le um ajuste da loja (ex.: nome para o termo). Devolve null quando inexistente. */
export async function kzGetSetting(tx: KzTx, workspaceId: string, key: string): Promise<string | null> {
  const row = (
    await tx.query<{ value: string }>('SELECT value FROM crm.kz_settings WHERE workspace_id = $1 AND key = $2', [
      workspaceId,
      key,
    ])
  ).rows[0];
  return row?.value ?? null;
}

// ------------------------------ schemas ------------------------------

const kzModuleSchema = z.enum(KZ_MODULES);
const kzFlagSetSchema = z
  .object({ module: kzModuleSchema, enabled: z.boolean(), expected_version: kzVersion.optional(), idempotency_key: kzIdempotencyKey })
  .strict();
const kzSettingSetSchema = z
  .object({
    key: kzText(1, 60).regex(/^[a-z0-9_.-]+$/),
    value: kzText(1, 500),
    expected_version: kzVersion.optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

// ------------------------------ servico ------------------------------

export class KzFlags {
  constructor(private readonly db: KzDb) {}

  async list(p: KzPrincipal): Promise<unknown> {
    kzAssertRead(p);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzReady(tx, 'kz_feature_flags', 'KZ_FLAGS');
      const rows = (
        await tx.query<{ module: string; enabled: boolean; version: number }>(
          'SELECT module, enabled, version FROM crm.kz_feature_flags WHERE workspace_id = $1',
          [p.workspaceId],
        )
      ).rows;
      const porModulo = new Map(rows.map((r) => [r.module, r]));
      return {
        automations_enabled: kzAutomationsOn(),
        modules: KZ_MODULES.map((module) => {
          const row = porModulo.get(module);
          const process_enabled = kzProcessFlagOn(module);
          const store_enabled = row?.enabled === true;
          return {
            module,
            process_enabled,
            store_enabled,
            enabled: process_enabled && store_enabled,
            version: row?.version ?? null,
          };
        }),
      };
    });
  }

  async set(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/flags');
    const input = kzFlagSetSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.flags.set', input.idempotency_key, input, async () => {
        await kzReady(tx, 'kz_feature_flags', 'KZ_FLAGS');
        const existing = (
          await tx.query<{ version: number }>(
            'SELECT version FROM crm.kz_feature_flags WHERE workspace_id = $1 AND module = $2 FOR UPDATE',
            [p.workspaceId, input.module],
          )
        ).rows[0];
        let row: { module: string; enabled: boolean; version: number };
        if (existing) {
          kzSameVersion(existing, input.expected_version);
          row = (
            await tx.query<{ module: string; enabled: boolean; version: number }>(
              'UPDATE crm.kz_feature_flags SET enabled = $3, version = version + 1, updated_at = now() WHERE workspace_id = $1 AND module = $2 RETURNING module, enabled, version',
              [p.workspaceId, input.module, input.enabled],
            )
          ).rows[0];
        } else {
          row = (
            await tx.query<{ module: string; enabled: boolean; version: number }>(
              'INSERT INTO crm.kz_feature_flags (workspace_id, module, enabled, created_by) VALUES ($1, $2, $3, $4) RETURNING module, enabled, version',
              [p.workspaceId, input.module, input.enabled, p.actorId],
            )
          ).rows[0];
        }
        await kzEvent(tx, p, 'kz.flags.alteradas', input.module, `kz.flags.alteradas:${input.module}:${row.version}`, {
          module: input.module,
          enabled: input.enabled,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.flags.alteradas',
          entityId: input.module,
          payload: { module: input.module, enabled: input.enabled },
        });
        return row;
      }),
    );
  }

  async listSettings(p: KzPrincipal): Promise<unknown> {
    kzAssertRead(p);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzReady(tx, 'kz_settings', 'KZ_FLAGS');
      return (
        await tx.query<{ key: string; value: string; version: number }>(
          'SELECT key, value, version FROM crm.kz_settings WHERE workspace_id = $1 AND archived_at IS NULL ORDER BY key',
          [p.workspaceId],
        )
      ).rows;
    });
  }

  async getSetting(p: KzPrincipal, key: string): Promise<unknown> {
    kzAssertRead(p);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzReady(tx, 'kz_settings', 'KZ_FLAGS');
      const row = (
        await tx.query<{ key: string; value: string; version: number }>(
          'SELECT key, value, version FROM crm.kz_settings WHERE workspace_id = $1 AND key = $2',
          [p.workspaceId, key],
        )
      ).rows[0];
      if (!row) throw new DomainError('SETTING_NOT_FOUND', 404);
      return row;
    });
  }

  async setSetting(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/settings');
    const input = kzSettingSetSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.settings.set', input.idempotency_key, input, async () => {
        await kzReady(tx, 'kz_settings', 'KZ_FLAGS');
        const existing = (
          await tx.query<{ version: number }>('SELECT version FROM crm.kz_settings WHERE workspace_id = $1 AND key = $2 FOR UPDATE', [
            p.workspaceId,
            input.key,
          ])
        ).rows[0];
        let row: { key: string; value: string; version: number };
        if (existing) {
          kzSameVersion(existing, input.expected_version);
          row = (
            await tx.query<{ key: string; value: string; version: number }>(
              'UPDATE crm.kz_settings SET value = $3, version = version + 1, updated_at = now() WHERE workspace_id = $1 AND key = $2 RETURNING key, value, version',
              [p.workspaceId, input.key, input.value],
            )
          ).rows[0];
        } else {
          row = (
            await tx.query<{ key: string; value: string; version: number }>(
              'INSERT INTO crm.kz_settings (workspace_id, key, value, created_by) VALUES ($1, $2, $3, $4) RETURNING key, value, version',
              [p.workspaceId, input.key, input.value, p.actorId],
            )
          ).rows[0];
        }
        await kzEvent(tx, p, 'kz.settings.alteradas', input.key, `kz.settings.alteradas:${input.key}:${row.version}`, {
          key: input.key,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.settings.alteradas',
          entityId: input.key,
          payload: { key: input.key },
        });
        return row;
      }),
    );
  }
}

// ------------------------------ rotas ------------------------------

type Request = { principal: KzPrincipal };

@Controller()
export class KzFlagsController {
  constructor(@Inject('KZ:FLAGS') private readonly flags: KzFlags) {}

  @Get('kz/flags')
  @Header('Cache-Control', 'private, no-store')
  listar(@Req() r: Request) {
    return this.flags.list(r.principal);
  }

  @Post('kz/flags')
  definir(@Req() r: Request, @Body() b: unknown) {
    return this.flags.set(r.principal, b);
  }

  @Get('kz/settings')
  @Header('Cache-Control', 'private, no-store')
  listarAjustes(@Req() r: Request) {
    return this.flags.listSettings(r.principal);
  }

  @Get('kz/settings/:key')
  verAjuste(@Req() r: Request, @Param('key') key: string) {
    return this.flags.getSetting(r.principal, key);
  }

  @Post('kz/settings')
  definirAjuste(@Req() r: Request, @Body() b: unknown) {
    return this.flags.setSetting(r.principal, b);
  }
}

export const KZ_FLAGS_PROVIDER: Provider = {
  provide: 'KZ:FLAGS',
  useFactory: (management: { db: KzDb }) => new KzFlags(management.db),
  inject: ['MANAGEMENT'],
};
