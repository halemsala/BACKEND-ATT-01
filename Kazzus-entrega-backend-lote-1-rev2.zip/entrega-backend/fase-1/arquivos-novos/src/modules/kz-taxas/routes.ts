// Rotas do kz-taxas.

import { Body, Controller, Get, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzTaxas } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzTaxasController {
  constructor(@Inject('KZ:TAXAS') private readonly taxas: KzTaxas) {}

  @Get('kz/taxas')
  listar(@Req() r: Request, @Query() q: unknown) {
    return this.taxas.listar(r.principal, q);
  }

  @Post('kz/taxas')
  definir(@Req() r: Request, @Body() b: unknown) {
    return this.taxas.set(r.principal, b);
  }

  @Post('kz/taxas/simular')
  simular(@Req() r: Request, @Body() b: unknown) {
    return this.taxas.simular(r.principal, b);
  }

  @Post('kz/taxas/:id/arquivar')
  arquivar(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.taxas.arquivar(r.principal, id, b);
  }
}

export const KZ_TAXAS_PROVIDER: Provider = {
  provide: 'KZ:TAXAS',
  useFactory: (management: { db: KzDb }) => new KzTaxas(management.db),
  inject: ['MANAGEMENT'],
};
