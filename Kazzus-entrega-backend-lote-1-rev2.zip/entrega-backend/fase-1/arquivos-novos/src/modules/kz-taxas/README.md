# kz-taxas

Tabela de taxas da maquininha (por bandeira e parcela) e simulador de parcelas,
liquido e lucro real. Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Cadastro/editacao/arquivamento de taxas por (bandeira, parcelas) - editado pelo
  Anderson (`operator`/`admin`), com concorrencia otimista e idempotencia.
- Simulacao pura: dado o preco de tabela, calcula taxa da maquininha, valor liquido,
  valor de cada parcela e, se informado o custo, o lucro real.
- Matematica inteira em centavos (sem erro de ponto flutuante): a taxa usa
  `floor(preco * percentual / 100)` e o resto da divisao de parcelas vai nas primeiras.

## O que NAO faz (de proposito)

- Nao grava preco, desconto ou cupom em nenhuma tabela (R1): a simulacao e somente
  leitura e nao gera evento/auditoria de escrita.
- Nao negocia taxa automaticamente nem chama a maquininha.

## Tabelas (migracao 096)

- `crm.kz_card_fee_tables` - uma linha ativa por (bandeira, parcelas) por loja.

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| GET | `kz/taxas?brand=&ativos=true` | lista taxas da loja |
| POST | `kz/taxas` | `{brand, installments, percent, fixed_cents?, active?, expected_version?, idempotency_key}` |
| POST | `kz/taxas/simular` | `{price_cents, brand, installments, cost_cents?}` |
| POST | `kz/taxas/:id/arquivar` | `{expected_version, idempotency_key}` |

Erros: `FEE_NOT_FOUND` 404, `VERSION_CONFLICT` 409, `NOT_FOUND` 404, `MODULE_DISABLED`
404, `FORBIDDEN` 403, `KZ_TAXAS_MIGRATION_REQUIRED` 503. Corrida de insercao dupla
sai como `DATA_CONSTRAINT` 409 (indice unico parcial).

## Eventos

`kz.taxas.alteradas` (criacao, edicao e arquivamento).

## Flags

- Processo: `KAZZUS_KZ_TAXAS=YES`; Loja: linha `taxas` em `crm.kz_feature_flags`.
- Desligado por padrao.

## Exige autorizacao do Anderson

- Toda manutencao da tabela de taxas (so operator/admin escreve).
- Conferir percentuais reais contratados com a maquininha antes de usar em decisao.
