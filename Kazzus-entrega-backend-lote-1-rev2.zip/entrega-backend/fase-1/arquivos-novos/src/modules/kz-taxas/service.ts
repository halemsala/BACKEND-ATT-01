// kz-taxas: tabela de taxas da maquininha por bandeira e parcela, editada pelo
// Anderson, e simulador (taxa, liquido, valor da parcela e lucro real).
// A simulacao e SOMENTE LEITURA: nenhum preco, desconto ou cupom e gravado (R1).

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzReady,
  kzSameVersion,
  kzSplitCents,
  kzUuid,
} from '../kz-common.js';
import { kzRequireModule } from '../kz-flags.js';
import {
  kzTaxaArquivarSchema,
  kzTaxaListQuery,
  kzTaxaSetSchema,
  kzTaxaSimularSchema,
} from './schema.js';

interface KzTaxaRow {
  id: string;
  brand: string;
  installments: number;
  percent: string;
  fixed_cents: string | number;
  active: boolean;
  version: number;
}

export class KzTaxas {
  constructor(private readonly db: KzDb) {}

  async set(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/taxas');
    const input = kzTaxaSetSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.taxas.set', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'taxas');
        await kzReady(tx, 'kz_card_fee_tables', 'KZ_TAXAS');
        const existente = (
          await tx.query<KzTaxaRow>(
            'SELECT id, version FROM crm.kz_card_fee_tables WHERE workspace_id = $1 AND brand = $2 AND installments = $3 AND archived_at IS NULL FOR UPDATE',
            [p.workspaceId, input.brand, input.installments],
          )
        ).rows[0];
        let row: KzTaxaRow;
        if (existente) {
          kzSameVersion(existente, input.expected_version);
          row = (
            await tx.query<KzTaxaRow>(
              `UPDATE crm.kz_card_fee_tables
               SET percent = $3, fixed_cents = $4, active = $5, version = version + 1, updated_at = now()
               WHERE workspace_id = $1 AND id = $2
               RETURNING id, brand, installments, percent, fixed_cents, active, version`,
              [p.workspaceId, existente.id, input.percent, input.fixed_cents ?? 0, input.active ?? true],
            )
          ).rows[0];
        } else {
          row = (
            await tx.query<KzTaxaRow>(
              `INSERT INTO crm.kz_card_fee_tables (workspace_id, brand, installments, percent, fixed_cents, active, created_by)
               VALUES ($1, $2, $3, $4, $5, $6, $7)
               RETURNING id, brand, installments, percent, fixed_cents, active, version`,
              [p.workspaceId, input.brand, input.installments, input.percent, input.fixed_cents ?? 0, input.active ?? true, p.actorId],
            )
          ).rows[0];
        }
        await kzEvent(tx, p, 'kz.taxas.alteradas', row.id, `kz.taxas.alteradas:${row.id}:${row.version}`, {
          brand: row.brand,
          installments: Number(row.installments),
          percent: Number(row.percent),
          active: row.active,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.taxas.alteradas',
          entityId: row.id,
          payload: { brand: row.brand, installments: Number(row.installments), percent: Number(row.percent), active: row.active },
        });
        return row;
      }),
    );
  }

  async arquivar(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/taxas/:id/arquivar');
    const taxaId = kzUuid.parse(id);
    const input = kzTaxaArquivarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.taxas.arquivar', input.idempotency_key, { ...input, id: taxaId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'taxas');
        await kzReady(tx, 'kz_card_fee_tables', 'KZ_TAXAS');
        const existente = (
          await tx.query<KzTaxaRow>('SELECT id, version FROM crm.kz_card_fee_tables WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL FOR UPDATE', [
            p.workspaceId,
            taxaId,
          ])
        ).rows[0];
        if (!existente) throw new DomainError('NOT_FOUND', 404);
        kzSameVersion(existente, input.expected_version);
        const row = (
          await tx.query<KzTaxaRow>(
            `UPDATE crm.kz_card_fee_tables SET active = false, archived_at = now(), version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING id, brand, installments, percent, fixed_cents, active, version`,
            [p.workspaceId, taxaId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.taxas.alteradas', row.id, `kz.taxas.alteradas:${row.id}:${row.version}`, {
          brand: row.brand,
          installments: Number(row.installments),
          percent: Number(row.percent),
          active: false,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.taxas.arquivada',
          entityId: row.id,
          payload: { brand: row.brand },
        });
        return row;
      }),
    );
  }

  async listar(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzTaxaListQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'taxas');
      await kzReady(tx, 'kz_card_fee_tables', 'KZ_TAXAS');
      const filtros: string[] = ['workspace_id = $1', 'archived_at IS NULL'];
      const params: unknown[] = [p.workspaceId];
      if (query.brand) {
        params.push(query.brand);
        filtros.push(`brand = $${params.length}`);
      }
      if (query.ativos === 'true') filtros.push('active = true');
      if (query.ativos === 'false') filtros.push('active = false');
      return (
        await tx.query(
          `SELECT id, brand, installments, percent, fixed_cents, active, version, updated_at
           FROM crm.kz_card_fee_tables WHERE ${filtros.join(' AND ')} ORDER BY brand, installments`,
          params,
        )
      ).rows;
    });
  }

  /** Simulacao pura: nao grava nada (guarda R1). */
  async simular(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertRead(p);
    const input = kzTaxaSimularSchema.parse(raw);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'taxas');
      await kzReady(tx, 'kz_card_fee_tables', 'KZ_TAXAS');
      const taxa = (
        await tx.query<KzTaxaRow>(
          `SELECT id, brand, installments, percent, fixed_cents, active, version
           FROM crm.kz_card_fee_tables
           WHERE workspace_id = $1 AND brand = $2 AND installments = $3 AND active AND archived_at IS NULL`,
          [p.workspaceId, input.brand, input.installments],
        )
      ).rows[0];
      if (!taxa) throw new DomainError('FEE_NOT_FOUND', 404);
      const percentualCentavos = Math.round(Number(taxa.percent) * 100);
      const taxaCentavos = Math.floor((input.price_cents * percentualCentavos) / 10000) + Number(taxa.fixed_cents);
      const liquido = input.price_cents - taxaCentavos;
      return {
        brand: taxa.brand,
        installments: Number(taxa.installments),
        percent: Number(taxa.percent),
        fixed_cents: Number(taxa.fixed_cents),
        price_cents: input.price_cents,
        fee_cents: taxaCentavos,
        liquid_cents: liquido,
        installments_cents: kzSplitCents(input.price_cents, Number(taxa.installments)),
        lucro_real_cents: input.cost_cents === undefined ? null : liquido - input.cost_cents,
      };
    });
  }
}
