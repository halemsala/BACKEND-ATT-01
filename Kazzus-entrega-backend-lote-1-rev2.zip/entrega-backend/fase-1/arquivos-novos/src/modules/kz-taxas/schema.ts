// Schemas zod do kz-taxas (tabela de taxas da maquininha e simulacao).

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzVersion } from '../kz-common.js';

export const kzTaxaBrand = z.string().regex(/^[a-z0-9 -]{2,30}$/, 'bandeira em minusculas, 2 a 30 caracteres');
export const kzTaxaPercentual = z
  .number()
  .min(0)
  .max(100)
  .refine((v) => Math.round(v * 100) / 100 === v, 'percentual com no maximo 2 decimais');

export const kzTaxaSetSchema = z
  .object({
    brand: kzTaxaBrand,
    installments: z.number().int().min(1).max(24),
    percent: kzTaxaPercentual,
    fixed_cents: kzCents(0).optional(),
    active: z.boolean().optional(),
    expected_version: kzVersion.optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzTaxaArquivarSchema = z
  .object({ expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzTaxaSimularSchema = z
  .object({
    price_cents: kzCents(1),
    brand: kzTaxaBrand,
    installments: z.number().int().min(1).max(24),
    cost_cents: kzCents(0).optional(),
  })
  .strict();

export const kzTaxaListQuery = z
  .object({
    brand: kzTaxaBrand.optional(),
    ativos: z.enum(['true', 'false']).optional(),
  })
  .strict();

export type KzTaxaSet = z.infer<typeof kzTaxaSetSchema>;
export type KzTaxaSimular = z.infer<typeof kzTaxaSimularSchema>;
