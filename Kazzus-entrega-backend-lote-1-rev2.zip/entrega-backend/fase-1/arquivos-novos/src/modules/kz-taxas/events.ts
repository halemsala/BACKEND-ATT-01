// Eventos do kz-taxas.

export const KZ_TAXAS_EVENTS = ['kz.taxas.alteradas'] as const;

export interface KzTaxasAlteradasPayload {
  brand: string;
  installments: number;
  percent: number;
  active: boolean;
}
