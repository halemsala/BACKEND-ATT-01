// Rotas do kz-pagamento-misto.

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzPagamentoMisto } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzPagamentoMistoController {
  constructor(@Inject('KZ:PAGAMENTO_MISTO') private readonly pagamentos: KzPagamentoMisto) {}

  @Post('kz/pagamentos/:pedido/dividir')
  dividir(@Req() r: Request, @Param('pedido') pedido: string, @Body() b: unknown) {
    return this.pagamentos.dividir(r.principal, pedido, b);
  }

  @Get('kz/pagamentos/:pedido')
  @Header('Cache-Control', 'private, no-store')
  consultar(@Req() r: Request, @Param('pedido') pedido: string, @Query() q: unknown) {
    return this.pagamentos.consultar(r.principal, pedido, q);
  }
}

export const KZ_PAGAMENTO_MISTO_PROVIDER: Provider = {
  provide: 'KZ:PAGAMENTO_MISTO',
  useFactory: (management: { db: KzDb }) => new KzPagamentoMisto(management.db),
  inject: ['MANAGEMENT'],
};
