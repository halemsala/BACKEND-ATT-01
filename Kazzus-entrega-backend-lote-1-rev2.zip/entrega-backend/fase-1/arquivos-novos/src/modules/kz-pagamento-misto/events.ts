// Eventos do kz-pagamento-misto.

export const KZ_PAGAMENTO_MISTO_EVENTS = ['kz.pagamento.dividido'] as const;

export interface KzPagamentoDivididoPayload {
  order_kind: 'order' | 'quote';
  order_id: string;
  order_total_cents: number;
  payments_total_cents: number;
  change_cents: number;
  methods: string[];
}
