// Schemas zod do kz-pagamento-misto.

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzText } from '../kz-common.js';

export const KZ_PAGAMENTO_METODOS = ['dinheiro', 'pix', 'debito', 'credito', 'crediario', 'vale_troca', 'outro'] as const;

export const kzPagamentoItem = z
  .object({
    method: z.enum(KZ_PAGAMENTO_METODOS),
    amount_cents: kzCents(1),
    installments: z.number().int().min(1).max(24).optional(),
  })
  .strict()
  .refine((v) => v.installments === undefined || v.method === 'credito' || v.method === 'crediario', {
    message: 'parcelas so fazem sentido em credito ou crediario',
  });

export const kzPagamentoDividirSchema = z
  .object({
    order_kind: z.enum(['order', 'quote']),
    order_total_cents: kzCents(1),
    change_cents: kzCents(0).optional(),
    payments: z.array(kzPagamentoItem).min(1).max(12),
    note: kzText(1, 500).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzPagamentoConsultarQuery = z
  .object({ kind: z.enum(['order', 'quote']).default('order') })
  .strict();

export type KzPagamentoDividir = z.infer<typeof kzPagamentoDividirSchema>;
