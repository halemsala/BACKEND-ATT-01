// kz-pagamento-misto: registra a divisao do pagamento de um pedido em varias
// formas (com troco). Nenhum dinheiro e movido: Pix e maquininha seguem em modo
// demo (R3) e a confirmacao e manual. O total do pedido vem declarado pela
// chamada; um adaptador opcional (orderTotalSource) pode conferir contra o pedido
// real quando o schema de orders for confirmado (duvida D4) - sem o adaptador,
// valida-se apenas a consistencia interna (soma - troco = total).

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  type KzTx,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzReady,
  kzUuid,
  type KzRow,
} from '../kz-common.js';
import { kzRequireModule } from '../kz-flags.js';
import { kzPagamentoConsultarQuery, kzPagamentoDividirSchema } from './schema.js';

/** Adaptador opcional: devolve o total real do pedido ou null quando nao souber. */
export type KzOrderTotalSource = (
  tx: KzTx,
  workspaceId: string,
  orderKind: 'order' | 'quote',
  orderId: string,
) => Promise<number | null>;

export class KzPagamentoMisto {
  constructor(
    private readonly db: KzDb,
    private readonly orderTotalSource?: KzOrderTotalSource,
  ) {}

  async dividir(p: KzPrincipal, pedidoId: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/pagamentos/:pedido/dividir');
    const orderId = kzUuid.parse(pedidoId);
    const input = kzPagamentoDividirSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.pagamento.dividir', input.idempotency_key, { ...input, order_id: orderId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'pagamento-misto');
        await kzReady(tx, 'kz_payment_sets', 'KZ_PAGAMENTO_MISTO');
        const totalPago = input.payments.reduce((soma, item) => soma + item.amount_cents, 0);
        const troco = input.change_cents ?? 0;
        if (totalPago - troco !== input.order_total_cents) {
          throw new DomainError('PAYMENT_SPLIT_MISMATCH', 422);
        }
        if (this.orderTotalSource) {
          const totalReal = await this.orderTotalSource(tx, p.workspaceId, input.order_kind, orderId);
          if (totalReal !== null && totalReal !== input.order_total_cents) {
            throw new DomainError('ORDER_TOTAL_MISMATCH', 422);
          }
        }
        // arquiva o conjunto ativo anterior do mesmo pedido (redivisao)
        await tx.query(
          'UPDATE crm.kz_payment_sets SET archived_at = now(), version = version + 1, updated_at = now() WHERE workspace_id = $1 AND order_kind = $2 AND order_id = $3 AND archived_at IS NULL',
          [p.workspaceId, input.order_kind, orderId],
        );
        const set = (
          await tx.query<KzRow>(
            `INSERT INTO crm.kz_payment_sets (workspace_id, order_kind, order_id, order_total_cents, payments_total_cents, change_cents, note, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
            [p.workspaceId, input.order_kind, orderId, input.order_total_cents, totalPago, troco, input.note ?? null, p.actorId],
          )
        ).rows[0];
        const splits: Record<string, unknown>[] = [];
        for (let i = 0; i < input.payments.length; i++) {
          const item = input.payments[i];
          splits.push(
            (
              await tx.query<KzRow>(
                `INSERT INTO crm.kz_payment_splits (workspace_id, set_id, split_index, method, amount_cents, installments, created_by)
                 VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
                [p.workspaceId, set.id, i + 1, item.method, item.amount_cents, item.installments ?? null, p.actorId],
              )
            ).rows[0],
          );
        }
        await kzEvent(tx, p, 'kz.pagamento.dividido', set.id, `kz.pagamento.dividido:${set.id}`, {
          order_kind: input.order_kind,
          order_id: orderId,
          order_total_cents: input.order_total_cents,
          payments_total_cents: totalPago,
          change_cents: troco,
          methods: input.payments.map((item) => item.method),
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.pagamento.dividido',
          entityId: set.id,
          payload: { order_kind: input.order_kind, order_id: orderId, order_total_cents: input.order_total_cents },
        });
        return { ...set, splits };
      }),
    );
  }

  async consultar(p: KzPrincipal, pedidoId: string, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const orderId = kzUuid.parse(pedidoId);
    const query = kzPagamentoConsultarQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'pagamento-misto');
      await kzReady(tx, 'kz_payment_sets', 'KZ_PAGAMENTO_MISTO');
      const set = (
        await tx.query<KzRow>(
          'SELECT * FROM crm.kz_payment_sets WHERE workspace_id = $1 AND order_kind = $2 AND order_id = $3 AND archived_at IS NULL',
          [p.workspaceId, query.kind, orderId],
        )
      ).rows[0];
      if (!set) throw new DomainError('PAYMENT_SET_NOT_FOUND', 404);
      const splits = (
        await tx.query<KzRow>('SELECT * FROM crm.kz_payment_splits WHERE workspace_id = $1 AND set_id = $2 AND archived_at IS NULL ORDER BY split_index', [
          p.workspaceId,
          set.id,
        ])
      ).rows;
      return { ...set, splits };
    });
  }
}
