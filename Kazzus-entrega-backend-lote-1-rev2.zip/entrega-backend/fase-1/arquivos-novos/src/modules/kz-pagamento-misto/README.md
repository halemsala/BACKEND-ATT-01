# kz-pagamento-misto

Divisao do pagamento de um pedido em varias formas (dinheiro, Pix, debito,
credito, crediario, vale-troca) com troco. Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Registra o conjunto de pagamentos de um pedido/cotacao existente: total declarado,
  formas, parcelas (so para credito/crediario) e troco.
- Consistencia interna obrigatoria: `soma dos pagamentos - troco = total do pedido`
  (`PAYMENT_SPLIT_MISMATCH` 422 quando nao fecha).
- Adaptador opcional `orderTotalSource` no construtor: quando ligado (Lote 2, com o
  schema real de `orders`), confere o total declarado contra o pedido real
  (`ORDER_TOTAL_MISMATCH` 422). Sem o adaptador, valida a consistencia interna.
- Redivisao: criar um novo conjunto para o mesmo pedido arquiva o anterior
  (historico preservado).

## O que NAO faz (de proposito)

- Nao move dinheiro: sem gateway, sem banco, sem maquininha (R3, modo demo; Pix
  confirmado manualmente).
- Nao altera o pedido, o preco nem o desconto (R1): e um registro de como o
  cliente pagou.
- Nao envia comprovante para fora (R2).

## Tabelas (migracao 099)

- `crm.kz_payment_sets` (um conjunto ativo por pedido, indice unico parcial) e
  `crm.kz_payment_splits` (as formas, na ordem).

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| POST | `kz/pagamentos/:pedido/dividir` | `{order_kind: "order"\|"quote", order_total_cents, change_cents?, payments: [{method, amount_cents, installments?}], note?, idempotency_key}` |
| GET | `kz/pagamentos/:pedido?kind=order` | conjunto ativo + formas |

Erros: `PAYMENT_SPLIT_MISMATCH` 422, `ORDER_TOTAL_MISMATCH` 422 (com adaptador),
`PAYMENT_SET_NOT_FOUND` 404, `MODULE_DISABLED` 404, `FORBIDDEN` 403,
`KZ_PAGAMENTO_MISTO_MIGRATION_REQUIRED` 503.

## Eventos

`kz.pagamento.dividido` (metodos, total, troco).

## Flags

- Processo: `KAZZUS_KZ_PAGAMENTO_MISTO=YES`; Loja: linha `pagamento-misto` em
  `crm.kz_feature_flags`.

## Exige autorizacao do Anderson

- Ligar o adaptador de total real do pedido (quando o schema de orders for
  confirmado) - ja previsto no construtor do servico.
- Definir quando um conjunto pago "fecha" o pedido (integracao com o fluxo
  existente de pedidos).
