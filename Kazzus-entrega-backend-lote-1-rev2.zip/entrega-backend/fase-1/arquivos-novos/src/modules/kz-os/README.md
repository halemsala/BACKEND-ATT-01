# kz-os

Ordens de servico de assistencia tecnica: checklist, pecas, fotos e senha do
aparelho cifrada. Lote 1 dos modulos kz do Kazzus CRM.

## O que faz

- Cria OS com numero legivel por loja (`OS-00001`, contador proprio), cliente
  (referencia logica por `contact_id`), aparelho, problema relatado e checklist inicial.
- Fluxo de status com transicoes fechadas (veja o mapa em `schema.ts`): aberta ->
  em_analise -> aguardando_aprovacao/aguardando_peca -> em_reparo -> pronta ->
  entregue (com reabertura de `pronta` para `aberta`).
- Checklist: adicionar itens, marcar/desmarcar com quem e quando.
- Pecas usadas (descricao, quantidade, custo interno e origem) e fotos por
  referencia de armazenamento (`storage_ref`).
- Senha do aparelho: cifrada com AES-256-GCM (chave `KAZZUS_KZ_DATA_KEY`, 32 bytes
  em base64). Nunca e devolvida, nunca vai para evento, auditoria ou log; a
  resposta so informa `has_password`.
- Toda escrita com idempotencia, concorrencia otimista, RLS e trilha kz.

## O que NAO faz (de proposito)

- Nao grava preco de servico nem desconto (R1): o valor segue pelo fluxo existente
  de orcamento quando o Anderson aprovar.
- Nao envia a OS nem avisa o cliente por mensagem (R2): nada sai do sistema.
- `contact_id` e referencia logica (sem FK para `crm.contacts`) ate confirmar o
  schema real (duvida D4).

## Tabelas (migracao 097)

- `crm.kz_service_orders`, `crm.kz_service_order_checklists`,
  `crm.kz_service_order_parts`, `crm.kz_service_order_photos`.

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| POST | `kz/os` | `{device_brand, device_model, problem_reported, contact_id?, device_password?, checklist?: [{label}], idempotency_key}` |
| GET | `kz/os?status=&limit=&offset=` | lista |
| GET | `kz/os/:id` | detalhe (checklist + pecas + fotos; sem senha) |
| POST | `kz/os/:id/status` | `{status, note?, expected_version, idempotency_key}` |
| POST | `kz/os/:id/diagnostico` | `{diagnosis, expected_version, idempotency_key}` |
| POST | `kz/os/:id/checklist` | `{items: [{label}], idempotency_key}` |
| POST | `kz/os/:id/checklist/:itemId/marcar` | `{done, expected_version, idempotency_key}` |
| POST | `kz/os/:id/pecas` | `{description, quantity, unit_cost_cents, cost_source, idempotency_key}` |
| POST | `kz/os/:id/fotos` | `{kind, storage_ref, note?, idempotency_key}` |
| POST | `kz/os/:id/senha` | `{device_password, expected_version, idempotency_key}` |

Erros: `INVALID_STATE` 409 (transicao/estado), `VERSION_CONFLICT` 409, `NOT_FOUND`
404, `MODULE_DISABLED` 404, `FORBIDDEN` 403, `DATA_KEY_REQUIRED` 503 (senha sem
chave configurada), `KZ_OS_MIGRATION_REQUIRED` 503.

## Eventos

`kz.os.criada`, `kz.os.status`, `kz.os.pronta`, `kz.os.diagnostico`,
`kz.os.checklist_alterado`, `kz.os.peca_adicionada`, `kz.os.foto_adicionada`,
`kz.os.senha_definida` (payloads sem senha).

## Flags

- Processo: `KAZZUS_KZ_OS=YES`; Loja: linha `os` em `crm.kz_feature_flags`.

## Exige autorizacao do Anderson

- Definir a chave `KAZZUS_KZ_DATA_KEY` no processo da API (gerar com
  `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`).
- Conferir se `inspections`/`intake_forms` atuais devem receber copia da OS.
- Integrar fotos ao armazenamento existente (product-photos) no Lote 2.
