// kz-os: ordens de servico com checklist, pecas, fotos e senha do aparelho CIFRADA
// (AES-256-GCM via KAZZUS_KZ_DATA_KEY; a senha nunca sai na resposta, no evento ou
// na auditoria). Nao grava preco de servico (R1): valor do servico segue pelo fluxo
// existente de orcamento, se o Anderson quiser.

import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  type KzTx,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEncryptSecret,
  kzEvent,
  kzReady,
  kzSameVersion,
  kzUuid,
} from '../kz-common.js';
import { kzNextCounter, kzRequireModule } from '../kz-flags.js';
import {
  KZ_OS_TRANSICOES,
  kzOsChecklistAddSchema,
  kzOsChecklistMarcarSchema,
  kzOsCriarSchema,
  kzOsDiagnosticoSchema,
  kzOsFotoSchema,
  kzOsListQuery,
  kzOsPecaSchema,
  kzOsSenhaSchema,
  kzOsStatusSchema,
} from './schema.js';

interface KzOsRow {
  id: string;
  os_number: string;
  status: string;
  version: number;
  [key: string]: unknown;
}

export class KzOs {
  constructor(private readonly db: KzDb) {}

  async criar(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os');
    const input = kzOsCriarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.criar', input.idempotency_key, input, async () => {
        await kzRequireModule(tx, p.workspaceId, 'os');
        await kzReady(tx, 'kz_service_orders', 'KZ_OS');
        const numero = `OS-${String(await kzNextCounter(tx, p.workspaceId, 'kz_os')).padStart(5, '0')}`;
        const senhaCifrada = input.device_password === undefined ? null : kzEncryptSecret(input.device_password);
        const row = (
          await tx.query(
            `INSERT INTO crm.kz_service_orders
             (workspace_id, os_number, contact_id, device_brand, device_model, device_password_enc, problem_reported, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
            [
              p.workspaceId,
              numero,
              input.contact_id ?? null,
              input.device_brand,
              input.device_model,
              senhaCifrada,
              input.problem_reported,
              p.actorId,
            ],
          )
        ).rows[0] as KzOsRow;
        const itens = input.checklist ?? [];
        for (let i = 0; i < itens.length; i++) {
          await tx.query(
            'INSERT INTO crm.kz_service_order_checklists (workspace_id, order_id, label, position, created_by) VALUES ($1, $2, $3, $4, $5)',
            [p.workspaceId, row.id, itens[i].label, i + 1, p.actorId],
          );
        }
        await kzEvent(tx, p, 'kz.os.criada', row.id, `kz.os.criada:${row.id}`, {
          os_number: numero,
          device_brand: input.device_brand,
          device_model: input.device_model,
          status: row.status,
          has_password: senhaCifrada !== null,
          checklist_count: itens.length,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.criada',
          entityId: row.id,
          payload: { os_number: numero, has_password: senhaCifrada !== null },
        });
        return { ...this.semSenha(row), has_password: senhaCifrada !== null };
      }),
    );
  }

  async status(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/status');
    const osId = kzUuid.parse(id);
    const input = kzOsStatusSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.status', input.idempotency_key, { ...input, id: osId }, async () => {
        const row = await this.lock(tx, p, osId);
        kzSameVersion(row, input.expected_version);
        const destino = input.status as keyof typeof KZ_OS_TRANSICOES;
        if (!KZ_OS_TRANSICOES[row.status as keyof typeof KZ_OS_TRANSICOES].includes(destino)) {
          throw new DomainError('INVALID_STATE', 409);
        }
        const atualizada = (
          await tx.query(
            `UPDATE crm.kz_service_orders
             SET status = $3, delivered_at = CASE WHEN $3 = 'entregue' THEN now() ELSE delivered_at END,
                 version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND id = $2 RETURNING *`,
            [p.workspaceId, osId, input.status],
          )
        ).rows[0] as KzOsRow;
        await kzEvent(tx, p, 'kz.os.status', osId, `kz.os.status:${osId}:${atualizada.version}`, {
          from: row.status,
          to: input.status,
        });
        if (input.status === 'pronta') {
          await kzEvent(tx, p, 'kz.os.pronta', osId, `kz.os.pronta:${osId}`, { os_number: row.os_number });
        }
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.status',
          entityId: osId,
          payload: { from: row.status, to: input.status },
        });
        return { ...this.semSenha(atualizada), has_password: !!atualizada.device_password_enc };
      }),
    );
  }

  async diagnostico(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/diagnostico');
    const osId = kzUuid.parse(id);
    const input = kzOsDiagnosticoSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.diagnostico', input.idempotency_key, { ...input, id: osId }, async () => {
        const row = await this.lock(tx, p, osId);
        kzSameVersion(row, input.expected_version);
        const atualizada = (
          await tx.query(
            'UPDATE crm.kz_service_orders SET diagnosis = $3, version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2 RETURNING *',
            [p.workspaceId, osId, input.diagnosis],
          )
        ).rows[0] as KzOsRow;
        await kzEvent(tx, p, 'kz.os.diagnostico', osId, `kz.os.diagnostico:${osId}:${atualizada.version}`, { os_number: row.os_number });
        await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.os.diagnostico', entityId: osId, payload: {} });
        return { ...this.semSenha(atualizada), has_password: !!atualizada.device_password_enc };
      }),
    );
  }

  async checklistAdd(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/checklist');
    const osId = kzUuid.parse(id);
    const input = kzOsChecklistAddSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.checklist_add', input.idempotency_key, { ...input, id: osId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'os');
        await kzReady(tx, 'kz_service_order_checklists', 'KZ_OS');
        const row = await this.lock(tx, p, osId);
        // Revisao 2: checklist so em OS ativa (antes bloqueava apenas cancelada;
        // entregue tambem e estado final sem edicao).
        if (row.status === 'entregue' || row.status === 'cancelada') throw new DomainError('INVALID_STATE', 409);
        const ultima = (
          await tx.query<{ maximo: number | null }>(
            'SELECT max(position) AS maximo FROM crm.kz_service_order_checklists WHERE workspace_id = $1 AND order_id = $2',
            [p.workspaceId, osId],
          )
        ).rows[0];
        let posicao = Number(ultima?.maximo ?? 0);
        for (const item of input.items) {
          posicao += 1;
          await tx.query(
            'INSERT INTO crm.kz_service_order_checklists (workspace_id, order_id, label, position, created_by) VALUES ($1, $2, $3, $4, $5)',
            [p.workspaceId, osId, item.label, posicao, p.actorId],
          );
        }
        await tx.query('UPDATE crm.kz_service_orders SET version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2', [p.workspaceId, osId]);
        await kzEvent(tx, p, 'kz.os.checklist_alterado', osId, `kz.os.checklist_add:${osId}:${posicao}`, {
          os_number: row.os_number,
          adicionados: input.items.length,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.checklist_alterado',
          entityId: osId,
          payload: { adicionados: input.items.length },
        });
        return { ok: true, adicionados: input.items.length, posicao_final: posicao };
      }),
    );
  }

  async checklistMarcar(p: KzPrincipal, id: string, itemId: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/checklist/:itemId/marcar');
    const osId = kzUuid.parse(id);
    const itemUuid = kzUuid.parse(itemId);
    const input = kzOsChecklistMarcarSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.checklist_marcar', input.idempotency_key, { ...input, id: osId, item_id: itemUuid }, async () => {
        const row = await this.lock(tx, p, osId);
        kzSameVersion(row, input.expected_version);
        const item = (
          await tx.query('SELECT id, done FROM crm.kz_service_order_checklists WHERE workspace_id = $1 AND order_id = $2 AND id = $3 FOR UPDATE', [
            p.workspaceId,
            osId,
            itemUuid,
          ])
        ).rows[0];
        if (!item) throw new DomainError('NOT_FOUND', 404);
        const atualizado = (
          await tx.query(
            `UPDATE crm.kz_service_order_checklists
             SET done = $4, done_at = CASE WHEN $4 THEN now() ELSE NULL END, done_by = CASE WHEN $4 THEN $5 ELSE NULL END,
                 version = version + 1, updated_at = now()
             WHERE workspace_id = $1 AND order_id = $2 AND id = $3 RETURNING *`,
            [p.workspaceId, osId, itemUuid, input.done, p.actorId],
          )
        ).rows[0];
        await tx.query('UPDATE crm.kz_service_orders SET version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2', [p.workspaceId, osId]);
        await kzEvent(tx, p, 'kz.os.checklist_alterado', osId, `kz.os.checklist_marcar:${itemUuid}:${input.done}`, {
          os_number: row.os_number,
          item_id: itemUuid,
          done: input.done,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.checklist_marcar',
          entityId: osId,
          payload: { item_id: itemUuid, done: input.done },
        });
        return atualizado;
      }),
    );
  }

  async pecas(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/pecas');
    const osId = kzUuid.parse(id);
    const input = kzOsPecaSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.peca', input.idempotency_key, { ...input, id: osId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'os');
        await kzReady(tx, 'kz_service_order_parts', 'KZ_OS');
        const row = await this.lock(tx, p, osId);
        if (row.status === 'entregue' || row.status === 'cancelada') throw new DomainError('INVALID_STATE', 409);
        const peca = (
          await tx.query(
            'INSERT INTO crm.kz_service_order_parts (workspace_id, order_id, description, quantity, unit_cost_cents, cost_source, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
            [p.workspaceId, osId, input.description, input.quantity, input.unit_cost_cents, input.cost_source, p.actorId],
          )
        ).rows[0];
        await tx.query('UPDATE crm.kz_service_orders SET version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2', [p.workspaceId, osId]);
        await kzEvent(tx, p, 'kz.os.peca_adicionada', osId, `kz.os.peca:${peca.id}`, {
          os_number: row.os_number,
          description: input.description,
          quantity: input.quantity,
          unit_cost_cents: input.unit_cost_cents,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.peca_adicionada',
          entityId: osId,
          payload: { description: input.description, quantity: input.quantity },
        });
        return peca;
      }),
    );
  }

  async fotos(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/fotos');
    const osId = kzUuid.parse(id);
    const input = kzOsFotoSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.foto', input.idempotency_key, { ...input, id: osId }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'os');
        await kzReady(tx, 'kz_service_order_photos', 'KZ_OS');
        const row = await this.lock(tx, p, osId);
        // Revisao 2: foto so em OS ativa (a peca ja bloqueava entregue/cancelada;
        // a foto nao bloqueava nenhuma).
        if (row.status === 'entregue' || row.status === 'cancelada') throw new DomainError('INVALID_STATE', 409);
        const foto = (
          await tx.query(
            'INSERT INTO crm.kz_service_order_photos (workspace_id, order_id, kind, storage_ref, note, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [p.workspaceId, osId, input.kind, input.storage_ref, input.note ?? null, p.actorId],
          )
        ).rows[0];
        await tx.query('UPDATE crm.kz_service_orders SET version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2', [p.workspaceId, osId]);
        await kzEvent(tx, p, 'kz.os.foto_adicionada', osId, `kz.os.foto:${foto.id}`, { os_number: row.os_number, kind: input.kind });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.foto_adicionada',
          entityId: osId,
          payload: { kind: input.kind },
        });
        return foto;
      }),
    );
  }

  async senha(p: KzPrincipal, id: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/os/:id/senha');
    const osId = kzUuid.parse(id);
    const input = kzOsSenhaSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.os.senha', input.idempotency_key, { ...input, id: osId }, async () => {
        const row = await this.lock(tx, p, osId);
        kzSameVersion(row, input.expected_version);
        const cifrada = kzEncryptSecret(input.device_password);
        const atualizada = (
          await tx.query(
            'UPDATE crm.kz_service_orders SET device_password_enc = $3, version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2 RETURNING *',
            [p.workspaceId, osId, cifrada],
          )
        ).rows[0] as KzOsRow;
        // payload sem a senha (a redacao automatica tambem garantiria)
        await kzEvent(tx, p, 'kz.os.senha_definida', osId, `kz.os.senha:${osId}:${atualizada.version}`, { has_password: true });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.os.senha_definida',
          entityId: osId,
          payload: { has_password: true },
        });
        return { ...this.semSenha(atualizada), has_password: true };
      }),
    );
  }

  async listar(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzOsListQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'os');
      await kzReady(tx, 'kz_service_orders', 'KZ_OS');
      const filtros: string[] = ['workspace_id = $1', 'archived_at IS NULL'];
      const params: unknown[] = [p.workspaceId];
      if (query.status) {
        params.push(query.status);
        filtros.push(`status = $${params.length}`);
      }
      params.push(query.limit, query.offset);
      return (
        await tx.query(
          `SELECT os_number, id, contact_id, device_brand, device_model, status, created_at, updated_at, version,
             (device_password_enc IS NOT NULL) AS has_password
           FROM crm.kz_service_orders WHERE ${filtros.join(' AND ')}
           ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
          params,
        )
      ).rows;
    });
  }

  async detalhe(p: KzPrincipal, id: string): Promise<unknown> {
    kzAssertRead(p);
    const osId = kzUuid.parse(id);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'os');
      await kzReady(tx, 'kz_service_orders', 'KZ_OS');
      const row = (
        await tx.query('SELECT * FROM crm.kz_service_orders WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL', [p.workspaceId, osId])
      ).rows[0] as KzOsRow | undefined;
      if (!row) throw new DomainError('NOT_FOUND', 404);
      const checklist = (
        await tx.query('SELECT id, label, position, done, done_at, done_by FROM crm.kz_service_order_checklists WHERE workspace_id = $1 AND order_id = $2 AND archived_at IS NULL ORDER BY position', [p.workspaceId, osId])
      ).rows;
      const pecas = (
        await tx.query('SELECT * FROM crm.kz_service_order_parts WHERE workspace_id = $1 AND order_id = $2 AND archived_at IS NULL ORDER BY created_at', [p.workspaceId, osId])
      ).rows;
      const fotos = (
        await tx.query('SELECT id, kind, storage_ref, note, created_at FROM crm.kz_service_order_photos WHERE workspace_id = $1 AND order_id = $2 AND archived_at IS NULL ORDER BY created_at', [p.workspaceId, osId])
      ).rows;
      return { ...this.semSenha(row), has_password: !!row.device_password_enc, checklist, pecas, fotos };
    });
  }

  private semSenha(row: KzOsRow): Record<string, unknown> {
    const { device_password_enc, ...segura } = row;
    return segura;
  }

  private async lock(tx: KzTx, p: KzPrincipal, osId: string): Promise<KzOsRow> {
    await kzRequireModule(tx, p.workspaceId, 'os');
    await kzReady(tx, 'kz_service_orders', 'KZ_OS');
    const row = (
      await tx.query<KzOsRow>('SELECT * FROM crm.kz_service_orders WHERE workspace_id = $1 AND id = $2 FOR UPDATE', [p.workspaceId, osId])
    ).rows[0];
    if (!row) throw new DomainError('NOT_FOUND', 404);
    return row;
  }
}
