// Rotas do kz-os.

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzOs } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzOsController {
  constructor(@Inject('KZ:OS') private readonly os: KzOs) {}

  @Post('kz/os')
  criar(@Req() r: Request, @Body() b: unknown) {
    return this.os.criar(r.principal, b);
  }

  @Get('kz/os')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  listar(@Req() r: Request, @Query() q: unknown) {
    return this.os.listar(r.principal, q);
  }

  @Get('kz/os/:id')
  @Header('Cache-Control', 'private, no-store')
  @Header('Vary', 'Authorization, Cookie')
  detalhe(@Req() r: Request, @Param('id') id: string) {
    return this.os.detalhe(r.principal, id);
  }

  @Post('kz/os/:id/status')
  status(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.status(r.principal, id, b);
  }

  @Post('kz/os/:id/diagnostico')
  diagnostico(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.diagnostico(r.principal, id, b);
  }

  @Post('kz/os/:id/checklist')
  checklist(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.checklistAdd(r.principal, id, b);
  }

  @Post('kz/os/:id/checklist/:itemId/marcar')
  marcar(@Req() r: Request, @Param('id') id: string, @Param('itemId') itemId: string, @Body() b: unknown) {
    return this.os.checklistMarcar(r.principal, id, itemId, b);
  }

  @Post('kz/os/:id/pecas')
  pecas(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.pecas(r.principal, id, b);
  }

  @Post('kz/os/:id/fotos')
  fotos(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.fotos(r.principal, id, b);
  }

  @Post('kz/os/:id/senha')
  senha(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.os.senha(r.principal, id, b);
  }
}

export const KZ_OS_PROVIDER: Provider = {
  provide: 'KZ:OS',
  useFactory: (management: { db: KzDb }) => new KzOs(management.db),
  inject: ['MANAGEMENT'],
};
