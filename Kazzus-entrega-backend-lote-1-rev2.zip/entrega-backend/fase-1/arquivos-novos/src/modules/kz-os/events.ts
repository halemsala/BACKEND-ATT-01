// Eventos do kz-os. Nenhum payload carrega senha do aparelho (redacao automatica).

export const KZ_OS_EVENTS = [
  'kz.os.criada',
  'kz.os.status',
  'kz.os.pronta',
  'kz.os.diagnostico',
  'kz.os.checklist_alterado',
  'kz.os.peca_adicionada',
  'kz.os.foto_adicionada',
  'kz.os.senha_definida',
] as const;

export interface KzOsCriadaPayload {
  os_number: string;
  device_brand: string;
  device_model: string;
  status: string;
  has_password: boolean;
  checklist_count: number;
}

export interface KzOsStatusPayload {
  from: string;
  to: string;
}

export interface KzOsPecaAdicionadaPayload {
  os_number: string;
  description: string;
  quantity: number;
  unit_cost_cents: number;
}
