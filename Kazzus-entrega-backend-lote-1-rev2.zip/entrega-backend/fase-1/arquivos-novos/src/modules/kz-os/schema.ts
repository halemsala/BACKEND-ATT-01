// Schemas zod do kz-os.

import { z } from 'zod';
import { kzCents, kzIdempotencyKey, kzText, kzVersion } from '../kz-common.js';

export const KZ_OS_STATUS = [
  'aberta',
  'em_analise',
  'aguardando_aprovacao',
  'aguardando_peca',
  'em_reparo',
  'pronta',
  'entregue',
  'cancelada',
] as const;

export type KzOsStatus = (typeof KZ_OS_STATUS)[number];

/** Transicoes permitidas (lista fechada; entregue e cancelada sao finais). */
export const KZ_OS_TRANSICOES: Record<KzOsStatus, KzOsStatus[]> = {
  aberta: ['em_analise', 'aguardando_aprovacao', 'cancelada'],
  em_analise: ['aguardando_aprovacao', 'aguardando_peca', 'em_reparo', 'cancelada'],
  aguardando_aprovacao: ['aguardando_peca', 'em_reparo', 'cancelada'],
  aguardando_peca: ['em_reparo', 'cancelada'],
  em_reparo: ['pronta', 'cancelada'],
  pronta: ['entregue', 'aberta'],
  entregue: [],
  cancelada: [],
};

export const kzOsItemChecklist = z.object({ label: kzText(1, 200) }).strict();

export const kzOsCriarSchema = z
  .object({
    contact_id: z.uuid().optional(),
    device_brand: kzText(1, 60),
    device_model: kzText(1, 80),
    device_password: kzText(1, 64).optional(),
    problem_reported: kzText(1, 2000),
    checklist: z.array(kzOsItemChecklist).max(50).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzOsStatusSchema = z
  .object({
    status: z.enum(KZ_OS_STATUS),
    note: kzText(1, 500).optional(),
    expected_version: kzVersion,
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzOsDiagnosticoSchema = z
  .object({
    diagnosis: kzText(1, 2000),
    expected_version: kzVersion,
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzOsChecklistAddSchema = z
  .object({ items: z.array(kzOsItemChecklist).min(1).max(50), idempotency_key: kzIdempotencyKey })
  .strict();

export const kzOsChecklistMarcarSchema = z
  .object({ done: z.boolean(), expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzOsPecaSchema = z
  .object({
    description: kzText(1, 200),
    quantity: z.number().int().min(1).max(1000),
    unit_cost_cents: kzCents(0),
    cost_source: z.enum(['loja', 'terceiro', 'cliente']),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

/** Referencia de armazenamento da foto: chave relativa fechada (Revisao 2). */
export const kzOsStorageRef = z
  .string()
  .min(1)
  .max(500)
  .regex(/^[A-Za-z0-9][A-Za-z0-9._/-]*$/, 'referencia de armazenamento invalida (sem espaco, acento, barra invertida ou caminho absoluto)')
  .refine((v) => !v.includes('..'), 'referencia de armazenamento nao pode conter ..');

export const kzOsFotoSchema = z
  .object({
    kind: z.enum(['entrada', 'durante', 'saida']),
    storage_ref: kzOsStorageRef,
    note: kzText(1, 500).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzOsSenhaSchema = z
  .object({ device_password: kzText(1, 64), expected_version: kzVersion, idempotency_key: kzIdempotencyKey })
  .strict();

export const kzOsListQuery = z
  .object({
    status: z.enum(KZ_OS_STATUS).optional(),
    limit: z.coerce.number().int().min(1).max(200).default(50),
    offset: z.coerce.number().int().min(0).default(0),
  })
  .strict();
