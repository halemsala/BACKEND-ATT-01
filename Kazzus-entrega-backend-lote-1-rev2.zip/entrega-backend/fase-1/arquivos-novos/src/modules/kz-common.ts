// kz-common: helpers compartilhados dos modulos kz, copiados do padrao do Kazzus
// (secao 2.4 do contrato) sem importar de v21-writes.ts, para nao acoplar com o
// codigo existente. Nenhuma dependencia nova: so zod e node:crypto.
//
// Pontos de atencao documentados no RELATORIO (duvidas D1 a D3):
// - DomainError e a checagem de papel sao copias fieis do padrao documentado; se o
//   filtro real usar instanceof da classe original, basta trocar o import (1 linha).
// - Recibos de idempotencia, eventos e auditoria gravam nas tabelas kz_* proprias
//   (migracao 094) para nao depender de colunas nao documentadas das tabelas oficiais.

import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { z } from 'zod';

/** Erro de dominio no padrao do Kazzus: corpo { "code": "CODIGO" } com status HTTP. */
export class DomainError extends Error {
  readonly code: string;
  readonly status: number;

  constructor(code: string, status = 409) {
    super(code);
    this.name = 'DomainError';
    this.code = code;
    this.status = status;
  }
}

/** Linha generica das tabelas kz (todas tem id, version e colunas extras). */
export interface KzRow {
  id: string;
  version: number;
  [key: string]: unknown;
}

/** Transacao com RLS ativa (app.workspace_id definido). */
export interface KzTx {
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<{ rows: T[] }>;
}

/** Database minimo estrutural: qualquer db com workspace() serve. */
export interface KzDb {
  workspace<T>(workspaceId: string, fn: (tx: KzTx) => Promise<T>): Promise<T>;
}

/** Principal minimo estrutural (o tipo real vive em src/contracts.ts). */
export interface KzPrincipal {
  workspaceId: string;
  actorId: string;
  providerAccountId?: string;
  role?: string;
  agentId?: string;
}

// ---------- schemas basicos (zod 4, padrao do projeto) ----------

export const kzUuid = z.uuid();
export const kzIdempotencyKey = z.string().min(1).max(120);
export const kzVersion = z.number().int().min(1).max(2_000_000_000);
export const kzCents = (min = 0, max = 1_000_000_000_000) => z.number().int().min(min).max(max);
export const kzText = (min: number, max: number) => z.string().min(min).max(max);

// ---------- serializacao estavel e hash ----------

export function kzNormalize(value: unknown): unknown {
  if (value === null || typeof value === 'number' || typeof value === 'string' || typeof value === 'boolean') {
    return value;
  }
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map((item) => kzNormalize(item));
  if (typeof value === 'object' && value !== null) {
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(value as Record<string, unknown>).sort()) {
      const normalized = kzNormalize((value as Record<string, unknown>)[key]);
      if (normalized !== undefined) out[key] = normalized;
    }
    return out;
  }
  return null;
}

export function kzStableStringify(value: unknown): string {
  return JSON.stringify(kzNormalize(value));
}

export function kzSha256(text: string): string {
  return createHash('sha256').update(text, 'utf8').digest('hex');
}

// ---------- redacao de segredos (nunca vai para evento, auditoria ou log) ----------

const KZ_SECRET_KEY_RE = /senha|password|secret|token|(?:^|[^a-z])pin(?:$|[^a-z])/i;

export function kzRedact<T>(value: T): T {
  if (Array.isArray(value)) return value.map((item) => kzRedact(item)) as unknown as T;
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      out[key] = KZ_SECRET_KEY_RE.test(key) ? '[redatado]' : kzRedact(val);
    }
    return out as T;
  }
  return value;
}

// ---------- migracao e versao ----------

/** Confere com to_regclass se a tabela do modulo existe; senao responde 503. */
export async function kzReady(tx: KzTx, table: string, moduleCode: string): Promise<void> {
  const row = (await tx.query<{ ok: boolean | null }>('SELECT to_regclass($1) IS NOT NULL AS ok', [`crm.${table}`]))
    .rows[0];
  if (!row || row.ok !== true) throw new DomainError(`${moduleCode}_MIGRATION_REQUIRED`, 503);
}

/** Concorrencia otimista no padrao do projeto: VERSION_CONFLICT quando divergente. */
export function kzSameVersion(row: { version: number }, expected: number | null | undefined): void {
  if (typeof expected !== 'number' || expected !== Number(row.version)) {
    throw new DomainError('VERSION_CONFLICT', 409);
  }
}

// ---------- papeis (copia conservadora da regra documentada, secao 2.6) ----------
// Escrita kz so para operator/admin (authorization.ts e holdout). Agentes e
// simuladores nunca escrevem nem leem rotas kz.

const KZ_WRITE_ROLES = new Set(['operator', 'admin']);

export function kzAssertWrite(p: KzPrincipal, _method: string, _path: string): void {
  if (p.agentId !== undefined || p.role === 'agent' || p.role === 'simulator-finance') {
    throw new DomainError('FORBIDDEN', 403);
  }
  if (!KZ_WRITE_ROLES.has(p.role ?? '')) throw new DomainError('FORBIDDEN', 403);
}

export function kzAssertRead(p: KzPrincipal): void {
  if (p.agentId !== undefined || p.role === 'agent' || p.role === 'simulator-finance') {
    throw new DomainError('FORBIDDEN', 403);
  }
}

// ---------- idempotencia (recibos em crm.kz_command_receipts) ----------

export async function kzCommand<T>(
  tx: KzTx,
  p: { workspaceId: string; actorId: string },
  action: string,
  idempotencyKey: string,
  input: unknown,
  fn: () => Promise<T>,
): Promise<T> {
  await kzReady(tx, 'kz_command_receipts', 'KZ');
  const requestHash = kzSha256(kzStableStringify({ action, input }));
  // Revisao 2: serializacao por advisory lock de transacao (mesmo padrao do kzAudit).
  // O SELECT ... FOR UPDATE anterior exigiria privilegio de UPDATE na tabela, que
  // e append-only desde a revisao 2 (grant so SELECT, INSERT).
  await tx.query('SELECT pg_advisory_xact_lock(9450, hashtext($1 || \':\' || $2))', [p.workspaceId, idempotencyKey]);
  const existing = (
    await tx.query<{ request_hash: string; response: unknown }>(
      'SELECT request_hash, response FROM crm.kz_command_receipts WHERE workspace_id = $1 AND idempotency_key = $2',
      [p.workspaceId, idempotencyKey],
    )
  ).rows[0];
  if (existing) {
    if (existing.request_hash !== requestHash) throw new DomainError('IDEMPOTENCY_CONFLICT', 409);
    return existing.response as T;
  }
  const result = await fn();
  await tx.query(
    'INSERT INTO crm.kz_command_receipts (workspace_id, action, idempotency_key, actor_id, request_hash, response) VALUES ($1, $2, $3, $4, $5, $6::jsonb)',
    [p.workspaceId, action, idempotencyKey, p.actorId, requestHash, kzStableStringify(result === undefined ? null : result)],
  );
  return result;
}

// ---------- eventos (outbox kz com dedupe) ----------

export async function kzEvent(
  tx: KzTx,
  p: { workspaceId: string; actorId: string },
  type: string,
  aggregateId: string,
  dedupeKey: string,
  payload: Record<string, unknown>,
): Promise<void> {
  await tx.query(
    "INSERT INTO crm.kz_outbox_events (workspace_id, type, aggregate_id, dedupe_key, actor_id, payload) VALUES ($1, $2, $3, $4, $5, $6::jsonb) ON CONFLICT (workspace_id, dedupe_key) DO NOTHING",
    [p.workspaceId, type, aggregateId, dedupeKey, p.actorId, kzStableStringify(kzRedact(payload))],
  );
}

// ---------- auditoria append-only com hash encadeado (tabela kz propria) ----------

export interface KzAuditOptions {
  workspaceId: string;
  actorId: string;
  action: string;
  entityId?: string;
  category?: string;
  payload?: Record<string, unknown>;
}

export async function kzAudit(tx: KzTx, o: KzAuditOptions): Promise<void> {
  await tx.query('SELECT pg_advisory_xact_lock(9449, hashtext($1))', [o.workspaceId]);
  const last = (
    await tx.query<{ seq: string | number; hash: string }>(
      'SELECT seq, hash FROM crm.kz_audit_events WHERE workspace_id = $1 ORDER BY seq DESC LIMIT 1',
      [o.workspaceId],
    )
  ).rows[0];
  const seq = last ? Number(last.seq) + 1 : 1;
  const prevHash = last?.hash ?? '';
  const payloadJson = kzStableStringify(kzRedact(o.payload ?? {}));
  const hash = kzSha256(`${o.workspaceId}|${seq}|${prevHash}|${o.actorId}|${o.action}|${o.entityId ?? ''}|${payloadJson}`);
  await tx.query(
    'INSERT INTO crm.kz_audit_events (workspace_id, seq, actor_id, action, entity_id, category, payload, prev_hash, hash) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9)',
    [o.workspaceId, seq, o.actorId, o.action, o.entityId ?? null, o.category ?? null, payloadJson, prevHash, hash],
  );
}

export async function kzVerifyAuditChain(
  tx: KzTx,
  workspaceId: string,
): Promise<{ ok: boolean; checked: number; broken_seq: number | null }> {
  const rows = (
    await tx.query<{ seq: string | number; actor_id: string; action: string; entity_id: string | null; payload: unknown; prev_hash: string; hash: string }>(
      'SELECT seq, actor_id, action, entity_id, payload, prev_hash, hash FROM crm.kz_audit_events WHERE workspace_id = $1 ORDER BY seq',
      [workspaceId],
    )
  ).rows;
  let prevHash = '';
  for (const row of rows) {
    const seq = Number(row.seq);
    const expected = kzSha256(
      `${workspaceId}|${seq}|${prevHash}|${row.actor_id}|${row.action}|${row.entity_id ?? ''}|${kzStableStringify(row.payload)}`,
    );
    if (row.prev_hash !== prevHash || row.hash !== expected) {
      return { ok: false, checked: rows.length, broken_seq: seq };
    }
    prevHash = row.hash;
  }
  return { ok: true, checked: rows.length, broken_seq: null };
}

// ---------- criptografia de campos sensiveis (node:crypto, AES-256-GCM) ----------
// A chave vem de KAZZUS_KZ_DATA_KEY (32 bytes em base64). Nada vai para log.

const KZ_DATA_KEY_ENV = 'KAZZUS_KZ_DATA_KEY';

export function kzRequireDataKey(): Buffer {
  const raw = process.env[KZ_DATA_KEY_ENV];
  if (!raw) throw new DomainError('DATA_KEY_REQUIRED', 503);
  const key = Buffer.from(raw, 'base64');
  if (key.length !== 32) throw new DomainError('DATA_KEY_INVALID', 503);
  return key;
}

export function kzEncryptSecret(plain: string): string {
  const key = kzRequireDataKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return 'kz1.' + Buffer.concat([iv, tag, ct]).toString('base64');
}

export function kzDecryptSecret(enc: string): string {
  const key = kzRequireDataKey();
  if (!enc.startsWith('kz1.')) throw new DomainError('DATA_INVALID', 422);
  const raw = Buffer.from(enc.slice(4), 'base64');
  if (raw.length < 29) throw new DomainError('DATA_INVALID', 422);
  const iv = raw.subarray(0, 12);
  const tag = raw.subarray(12, 28);
  const ct = raw.subarray(28);
  const decipher = createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]).toString('utf8');
}

// ---------- dinheiro e utilidades (matematica inteira exata em centavos) ----------

/** Divide um total em centavos em n parcelas inteiras; o resto vai nas primeiras. */
export function kzSplitCents(totalCents: number, parts: number): number[] {
  if (!Number.isSafeInteger(totalCents) || parts < 1) throw new DomainError('INVALID_INPUT', 422);
  const base = Math.floor(totalCents / parts);
  const resto = totalCents - base * parts;
  return Array.from({ length: parts }, (_, i) => (i < resto ? base + 1 : base));
}

/** IMEI com 15 digitos e digito verificador Luhn valido. */
export function kzValidImei(imei: string): boolean {
  if (!/^[0-9]{15}$/.test(imei)) return false;
  let soma = 0;
  for (let i = 0; i < 15; i++) {
    let d = imei.charCodeAt(i) - 48;
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    soma += d;
  }
  return soma % 10 === 0;
}

/** Formata centavos como moeda brasileira sem depender de ICU: 1234567 -> "12.345,67". */
export function kzFormatBRL(cents: number): string {
  const negativo = cents < 0;
  const abs = Math.abs(cents);
  const inteiro = Math.floor(abs / 100).toString();
  const centavos = String(abs % 100).padStart(2, '0');
  const comPontos = inteiro.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${negativo ? '-' : ''}${comPontos},${centavos}`;
}

/** Data local (YYYY-MM-DD) no fuso da loja. */
export function kzTodayISO(tz = 'America/Fortaleza'): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date());
}
