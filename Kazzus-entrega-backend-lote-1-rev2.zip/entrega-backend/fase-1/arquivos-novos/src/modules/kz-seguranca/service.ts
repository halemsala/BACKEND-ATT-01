// kz-seguranca: PIN de acao sensivel (scrypt) com concessoes de curta validade
// (5 minutos por padrao) e trilha de tentativas. Camada NOVA em cima dos fluxos
// existentes, sem tocar em authorization.ts (holdout): os modulos que precisarem
// de passo a mais consultam as concessoes por kzGrantValido()/consumir.
// O PIN nunca aparece em resposta, evento, auditoria ou log (R9).

import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import {
  DomainError,
  type KzDb,
  type KzPrincipal,
  type KzTx,
  kzAssertRead,
  kzAssertWrite,
  kzAudit,
  kzCommand,
  kzEvent,
  kzReady,
  kzUuid} from '../kz-common.js';
import { kzRequireModule } from '../kz-flags.js';
import { kzSegurancaConfirmarSchema, kzSegurancaConsumirSchema, kzSegurancaHistoricoQuery, kzSegurancaPinSchema } from './schema.js';

const KZ_PIN_MAX_TENTATIVAS = 5;
const KZ_PIN_JANELA_MINUTOS = 15;
const KZ_PIN_TTL_PADRAO = 300;

function kzHashPin(pin: string, salHex: string): string {
  return scryptSync(pin, Buffer.from(salHex, 'hex'), 64, { N: 16384, r: 8, p: 1 }).toString('hex');
}

export class KzSeguranca {
  constructor(private readonly db: KzDb) {}

  async definirPin(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/seguranca/pin');
    const input = kzSegurancaPinSchema.parse(raw);
    // fase 1 fora da transacao principal: a tentativa precisa PERSISTIR mesmo quando
    // o PIN esta errado (se gravasse na mesma transacao, o rollback apagaria a falha)
    const erroPin = await this.tentarPin(p, input.current_pin, true);
    if (erroPin === 'PIN_LOCKED') throw new DomainError('PIN_LOCKED', 403);
    if (erroPin === 'INVALID_PIN') throw new DomainError('INVALID_PIN', 403);
    const jaTinha = erroPin !== 'SEM_PIN';
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.seguranca.pin', input.idempotency_key, { ...input, pin: '[segredo]' }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'seguranca');
        await kzReady(tx, 'kz_stepup_pins', 'KZ_SEGURANCA');
        const sal = randomBytes(16).toString('hex');
        const row = (
          await tx.query(
            `INSERT INTO crm.kz_stepup_pins (workspace_id, actor_id, pin_hash, pin_salt, created_by)
             VALUES ($1, $2, $3, $4, $5)
             ON CONFLICT (workspace_id, actor_id) DO UPDATE
               SET pin_hash = EXCLUDED.pin_hash, pin_salt = EXCLUDED.pin_salt, version = crm.kz_stepup_pins.version + 1, updated_at = now()
             RETURNING workspace_id, actor_id, pin_ver, version, updated_at`,
            [p.workspaceId, p.actorId, kzHashPin(input.pin, sal), sal, p.actorId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.seguranca.pin_definido', p.actorId, `kz.seguranca.pin:${p.actorId}:${row.version}`, {
          rotacionado: jaTinha,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.seguranca.pin_definido',
          entityId: p.actorId,
          payload: { rotacionado: jaTinha },
        });
        return { ok: true, rotacionado: jaTinha, version: Number(row.version) };
      }),
    );
  }

  async confirmar(p: KzPrincipal, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/seguranca/confirmar');
    const input = kzSegurancaConfirmarSchema.parse(raw);
    const erroPin = await this.tentarPin(p, input.pin, false);
    if (erroPin === 'PIN_LOCKED') throw new DomainError('PIN_LOCKED', 403);
    if (erroPin === 'PIN_NOT_SET') throw new DomainError('PIN_NOT_SET', 404);
    if (erroPin === 'INVALID_PIN') throw new DomainError('INVALID_PIN', 403);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.seguranca.confirmar', input.idempotency_key, { ...input, pin: '[segredo]' }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'seguranca');
        await kzReady(tx, 'kz_stepup_pins', 'KZ_SEGURANCA');
        const ttl = input.ttl_seconds ?? KZ_PIN_TTL_PADRAO;
        const grant = (
          await tx.query<{ id: string; purpose: string; expires_at: string; used: boolean; [key: string]: unknown }>(
            `INSERT INTO crm.kz_stepup_grants (workspace_id, actor_id, purpose, expires_at, created_by)
             VALUES ($1, $2, $3, now() + ($4 || ' seconds')::interval, $5) RETURNING id, purpose, expires_at, used`,
            [p.workspaceId, p.actorId, input.purpose, String(ttl), p.actorId],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.seguranca.confirmado', grant.id, `kz.seguranca.confirmado:${grant.id}`, {
          purpose: input.purpose,
          grant_id: grant.id,
          expires_at: grant.expires_at,
        });
        await kzAudit(tx, {
          workspaceId: p.workspaceId,
          actorId: p.actorId,
          action: 'kz.seguranca.confirmado',
          entityId: grant.id,
          payload: { purpose: input.purpose },
        });
        return { grant_id: grant.id, purpose: grant.purpose, expires_at: grant.expires_at };
      }),
    );
  }

  async consumir(p: KzPrincipal, grantId: string, raw: unknown): Promise<unknown> {
    kzAssertWrite(p, 'POST', '/kz/seguranca/grants/:id/consumir');
    const id = kzUuid.parse(grantId);
    const input = kzSegurancaConsumirSchema.parse(raw);
    return this.db.workspace(p.workspaceId, (tx) =>
      kzCommand(tx, p, 'kz.seguranca.consumir', input.idempotency_key, { ...input, id }, async () => {
        await kzRequireModule(tx, p.workspaceId, 'seguranca');
        await kzReady(tx, 'kz_stepup_grants', 'KZ_SEGURANCA');
        const grant = (
          await tx.query<{ id: string; actor_id: string; purpose: string; used: boolean; expires_at: string; [key: string]: unknown }>(
            'SELECT * FROM crm.kz_stepup_grants WHERE workspace_id = $1 AND id = $2 FOR UPDATE',
            [p.workspaceId, id],
          )
        ).rows[0];
        if (!grant || grant.actor_id !== p.actorId || grant.used || new Date(grant.expires_at).getTime() <= Date.now()) {
          throw new DomainError('STEPUP_INVALID', 403);
        }
        if (input.purpose !== undefined && grant.purpose !== input.purpose) {
          throw new DomainError('STEPUP_INVALID', 403);
        }
        const row = (
          await tx.query(
            'UPDATE crm.kz_stepup_grants SET used = true, used_at = now(), version = version + 1, updated_at = now() WHERE workspace_id = $1 AND id = $2 RETURNING id, purpose, used, used_at, expires_at',
            [p.workspaceId, id],
          )
        ).rows[0];
        await kzEvent(tx, p, 'kz.seguranca.grant_consumido', id, `kz.seguranca.grant_consumido:${id}`, { purpose: grant.purpose });
        await kzAudit(tx, { workspaceId: p.workspaceId, actorId: p.actorId, action: 'kz.seguranca.grant_consumido', entityId: id, payload: { purpose: grant.purpose } });
        return row;
      }),
    );
  }

  async grantsAtivos(p: KzPrincipal): Promise<unknown> {
    kzAssertRead(p);
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'seguranca');
      await kzReady(tx, 'kz_stepup_grants', 'KZ_SEGURANCA');
      return (
        await tx.query(
          'SELECT id, purpose, expires_at, created_at FROM crm.kz_stepup_grants WHERE workspace_id = $1 AND actor_id = $2 AND used = false AND expires_at > now() ORDER BY created_at DESC LIMIT 50',
          [p.workspaceId, p.actorId],
        )
      ).rows;
    });
  }

  async historico(p: KzPrincipal, rawQuery: unknown): Promise<unknown> {
    kzAssertRead(p);
    const query = kzSegurancaHistoricoQuery.parse(rawQuery ?? {});
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'seguranca');
      await kzReady(tx, 'kz_stepup_grants', 'KZ_SEGURANCA');
      return (
        await tx.query(
          `SELECT payload, created_at FROM crm.kz_outbox_events
           WHERE workspace_id = $1 AND actor_id = $2 AND type = 'kz.seguranca.confirmado'
             AND created_at >= now() - ($3 || ' days')::interval
           ORDER BY created_at DESC LIMIT 200`,
          [p.workspaceId, p.actorId, String(query.dias)],
        )
      ).rows;
    });
  }

  /**
   * Fase 1 da verificacao, em transacao PROPRIA: conta falhas recentes, confere o
   * PIN e grava a tentativa com COMMIT (mesmo quando errada) antes de qualquer erro
   * ser lancado. Retornos: 'SEM_PIN' (nao ha PIN e permitirSemPin), 'PIN_NOT_SET',
   * 'PIN_LOCKED', 'INVALID_PIN' ou null quando o PIN confere.
   */
  private async tentarPin(
    p: KzPrincipal,
    pin: string | undefined,
    permitirSemPin: boolean,
  ): Promise<'SEM_PIN' | 'PIN_NOT_SET' | 'PIN_LOCKED' | 'INVALID_PIN' | null> {
    return this.db.workspace(p.workspaceId, async (tx) => {
      await kzRequireModule(tx, p.workspaceId, 'seguranca');
      await kzReady(tx, 'kz_stepup_pins', 'KZ_SEGURANCA');
      const falhas = (
        await tx.query<{ c: number }>(
          `SELECT count(*)::int AS c FROM crm.kz_stepup_attempts
           WHERE workspace_id = $1 AND actor_id = $2 AND ok = false AND created_at > now() - ($3 || ' minutes')::interval`,
          [p.workspaceId, p.actorId, String(KZ_PIN_JANELA_MINUTOS)],
        )
      ).rows[0];
      if (Number(falhas.c) >= KZ_PIN_MAX_TENTATIVAS) return 'PIN_LOCKED';
      const atual = (
        await tx.query<{ pin_hash: string; pin_salt: string }>(
          'SELECT pin_hash, pin_salt FROM crm.kz_stepup_pins WHERE workspace_id = $1 AND actor_id = $2 FOR UPDATE',
          [p.workspaceId, p.actorId],
        )
      ).rows[0];
      if (!atual) return permitirSemPin ? 'SEM_PIN' : 'PIN_NOT_SET';
      const valido =
        pin !== undefined &&
        timingSafeEqual(Buffer.from(atual.pin_hash, 'hex'), Buffer.from(kzHashPin(pin, atual.pin_salt), 'hex'));
      await tx.query('INSERT INTO crm.kz_stepup_attempts (workspace_id, actor_id, ok) VALUES ($1, $2, $3)', [
        p.workspaceId,
        p.actorId,
        valido,
      ]);
      return valido ? null : 'INVALID_PIN';
    });
  }
}

/** Helper para os proximos modulos: a concessao e valida e ainda esta no prazo? */
export async function kzGrantValido(
  tx: KzTx,
  workspaceId: string,
  actorId: string,
  grantId: string,
  proposito: string,
): Promise<boolean> {
  const grant = (
    await tx.query<{ actor_id: string; purpose: string; used: boolean; expires_at: string }>(
      'SELECT actor_id, purpose, used, expires_at FROM crm.kz_stepup_grants WHERE workspace_id = $1 AND id = $2',
      [workspaceId, grantId],
    )
  ).rows[0];
  return (
    !!grant &&
    grant.actor_id === actorId &&
    grant.purpose === proposito &&
    grant.used === false &&
    new Date(grant.expires_at).getTime() > Date.now()
  );
}
