# kz-seguranca

PIN de acao sensivel (camada nova, sem tocar em authorization.ts) com concessoes
de curta validade (5 minutos) e trilha de tentativas. Lote 1 dos modulos kz.

## O que faz

- Cada humano (operator/admin) define o proprio PIN (4 a 8 digitos), guardado como
  scrypt (N=16384) com sal aleatorio - nunca em texto, nunca em log.
- `POST kz/seguranca/confirmar` confere o PIN e devolve uma concessao (grant) com
  prazo (30 a 300 segundos, padrao 300) para um proposito (ex.: "estorno").
- Concessao pode ser consumida uma unica vez (`used`) e consulta valida purpose,
  dono e prazo (`STEPUP_INVALID` 403 fora disso).
- Trava: 5 tentativas erradas em 15 minutos bloqueiam por 15 minutos
  (`PIN_LOCKED` 403). As tentativas ficam em `crm.kz_stepup_attempts`.
- Historico proprio das confirmacoes (le o outbox kz; sem PIN no payload).

## O que NAO faz (de proposito)

- Nao substitui o fluxo de desconto/estorno existente: e um passo EXTRA que os
  modulos futuros podem exigir (helper `kzGrantValido` ja exportado).
- Nao envia nada, nao grava PIN em nenhum lugar além do hash scrypt (R9).
- A tabela de tentativas nao e limpa com DELETE (o papel crm_app nao tem DELETE,
  por projeto); em volume de loja ela e pequena e serve de trilha.

## Tabelas (migracao 101)

- `crm.kz_stepup_pins`, `crm.kz_stepup_grants`, `crm.kz_stepup_attempts`.

## Rotas

| Metodo | Rota | Entrada |
|---|---|---|
| POST | `kz/seguranca/pin` | `{pin, current_pin?, idempotency_key}` (rotacao exige o atual) |
| POST | `kz/seguranca/confirmar` | `{pin, purpose, ttl_seconds?, idempotency_key}` -> `{grant_id, expires_at}` |
| GET | `kz/seguranca/grants` | concessoes proprias ativas |
| GET | `kz/seguranca/historico?dias=30` | confirmacoes proprias |
| POST | `kz/seguranca/grants/:id/consumir` | `{purpose?, idempotency_key}` |

Erros: `INVALID_PIN` 403, `PIN_LOCKED` 403, `PIN_NOT_SET` 404, `STEPUP_INVALID`
403, `MODULE_DISABLED` 404, `FORBIDDEN` 403, `KZ_SEGURANCA_MIGRATION_REQUIRED` 503.

## Eventos

`kz.seguranca.pin_definido`, `kz.seguranca.confirmado` (payload com proposito e
concessao, SEM o PIN), `kz.seguranca.grant_consumido`.

## Flags

- Processo: `KAZZUS_KZ_SEGURANCA=YES`; Loja: linha `seguranca`.

## Exige autorizacao do Anderson

- Quais acoes vao exigir o PIN (sugestao do contrato: desconto, cancelamento,
  estorno) - a integracao com os fluxos existentes e o Lote 2.
- Politica de tentativas (hoje: 5 em 15 minutos).
