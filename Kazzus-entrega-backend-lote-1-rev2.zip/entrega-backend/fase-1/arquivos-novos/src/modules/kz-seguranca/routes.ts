// Rotas do kz-seguranca.

import { Body, Controller, Get, Header, Inject, Param, Post, Query, Req } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import type { KzDb, KzPrincipal } from '../kz-common.js';
import { KzSeguranca } from './service.js';

type Request = { principal: KzPrincipal };

@Controller()
export class KzSegurancaController {
  constructor(@Inject('KZ:SEGURANCA') private readonly seguranca: KzSeguranca) {}

  @Post('kz/seguranca/pin')
  definirPin(@Req() r: Request, @Body() b: unknown) {
    return this.seguranca.definirPin(r.principal, b);
  }

  @Post('kz/seguranca/confirmar')
  confirmar(@Req() r: Request, @Body() b: unknown) {
    return this.seguranca.confirmar(r.principal, b);
  }

  @Get('kz/seguranca/grants')
  @Header('Cache-Control', 'private, no-store')
  grantsAtivos(@Req() r: Request) {
    return this.seguranca.grantsAtivos(r.principal);
  }

  @Get('kz/seguranca/historico')
  @Header('Cache-Control', 'private, no-store')
  historico(@Req() r: Request, @Query() q: unknown) {
    return this.seguranca.historico(r.principal, q);
  }

  @Post('kz/seguranca/grants/:id/consumir')
  consumir(@Req() r: Request, @Param('id') id: string, @Body() b: unknown) {
    return this.seguranca.consumir(r.principal, id, b);
  }
}

export const KZ_SEGURANCA_PROVIDER: Provider = {
  provide: 'KZ:SEGURANCA',
  useFactory: (management: { db: KzDb }) => new KzSeguranca(management.db),
  inject: ['MANAGEMENT'],
};
