// Eventos do kz-seguranca. NUNCA carregam o PIN (redacao automatica + payload minimo).

export const KZ_SEGURANCA_EVENTS = [
  'kz.seguranca.pin_definido',
  'kz.seguranca.confirmado',
  'kz.seguranca.grant_consumido',
] as const;

export interface KzSegurancaConfirmadoPayload {
  purpose: string;
  grant_id: string;
  expires_at: string;
}
