// Schemas zod do kz-seguranca.

import { z } from 'zod';
import { kzIdempotencyKey, kzText } from '../kz-common.js';

export const kzPinValor = z.string().regex(/^[0-9]{4,8}$/, 'PIN com 4 a 8 digitos');

export const kzSegurancaPinSchema = z
  .object({
    pin: kzPinValor,
    current_pin: kzPinValor.optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzSegurancaConfirmarSchema = z
  .object({
    pin: kzPinValor,
    purpose: kzText(1, 60),
    ttl_seconds: z.number().int().min(30).max(300).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzSegurancaConsumirSchema = z
  .object({
    purpose: kzText(1, 60).optional(),
    idempotency_key: kzIdempotencyKey,
  })
  .strict();

export const kzSegurancaHistoricoQuery = z
  .object({ dias: z.coerce.number().int().min(1).max(90).default(30) })
  .strict();
