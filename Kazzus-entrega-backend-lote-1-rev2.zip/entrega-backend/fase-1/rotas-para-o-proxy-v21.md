# Rotas para o proxy do V21 repassar (Lote 1 - modulos kz)

O `serve-v21.py` NAO deve ser editado por esta entrega. Este arquivo lista o que o
front V21 vai precisar que o proxy repasse para a API (127.0.0.1:3100), no mesmo
esquema das rotas explicitas que ele ja repassa hoje (`/crm-data/<rota>`).

Regras gerais das rotas kz:

- Tudo com prefixo `kz/` (nenhum conflito com as rotas existentes).
- Leitura: qualquer humano logado. Escrita: so `operator`/`admin` (holdout de
  `authorization.ts`). Agentes: bloqueados nas rotas kz.
- Toda escrita exige `idempotency_key` (1 a 120 caracteres); repetir a mesma chave
  devolve o mesmo resultado.
- Com a flag do modulo desligada (processo OU loja), a rota responde 404 com
  `{"code":"MODULE_DISABLED"}`.
- Erros vem como `{"code":"CODIGO"}` com status 409/404/403/422/503; validacao
  quebrada responde 422 `{"code":"INVALID_INPUT","issues":[...]}`.
- Rotas com dado pessoal ja enviam `Cache-Control: private, no-store`.

## Plano de controle (sem flag propria - duvida D9)

| Metodo | Rota | Corpo (exemplo) |
|---|---|---|
| GET | `kz/flags` | - (lista modulos, flags de processo/loja e kill switch) |
| POST | `kz/flags` | `{"module":"caixa","enabled":true,"idempotency_key":"..."}` |
| GET | `kz/settings` | - |
| GET | `kz/settings/:key` | - |
| POST | `kz/settings` | `{"key":"store_name","value":"Kazzus Celulares","idempotency_key":"..."}` |

## kz-caixa (flag `caixa`)

| Metodo | Rota | Corpo |
|---|---|---|
| GET | `kz/caixa/hoje` | - |
| GET | `kz/caixa/historico?dias=30` | - |
| GET | `kz/caixa/:id` | - |
| POST | `kz/caixa/abrir` | `{"opening_cents":100000,"note":"...","idempotency_key":"..."}` |
| POST | `kz/caixa/sangria` | `{"session_id":"<uuid>","amount_cents":20000,"reason":"...","expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/caixa/reforco` | igual a sangria |
| POST | `kz/caixa/fechar` | `{"session_id":"<uuid>","counted_cents":478500,"declared_sales_cash_cents":350000,"expected_version":3,"idempotency_key":"..."}` |

Valores em centavos (inteiros). O fechamento devolve `expected_cents` e
`difference_cents` DEPOIS da contagem informada (conferencia cega).

## kz-taxas (flag `taxas`)

| Metodo | Rota | Corpo |
|---|---|---|
| GET | `kz/taxas?brand=visa&ativos=true` | - |
| POST | `kz/taxas` | `{"brand":"visa","installments":3,"percent":3.99,"fixed_cents":20,"expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/taxas/simular` | `{"price_cents":99900,"brand":"visa","installments":3,"cost_cents":70000}` (nao grava nada) |
| POST | `kz/taxas/:id/arquivar` | `{"expected_version":1,"idempotency_key":"..."}` |

## kz-os (flag `os`)

| Metodo | Rota | Corpo |
|---|---|---|
| POST | `kz/os` | `{"device_brand":"...","device_model":"...","problem_reported":"...","contact_id":"<uuid opcional>","checklist":[{"label":"Tela"}],"idempotency_key":"..."}` (ha tambem `device_password`, opcional: cifrado em AES-256-GCM e nunca devolvido na resposta) |
| GET | `kz/os?status=aberta&limit=50&offset=0` | - |
| GET | `kz/os/:id` | - (devolve `has_password`, nunca a senha) |
| POST | `kz/os/:id/status` | `{"status":"em_reparo","expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/os/:id/diagnostico` | `{"diagnosis":"...","expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/os/:id/checklist` | `{"items":[{"label":"..."}],"idempotency_key":"..."}` |
| POST | `kz/os/:id/checklist/:itemId/marcar` | `{"done":true,"expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/os/:id/pecas` | `{"description":"...","quantity":1,"unit_cost_cents":1500,"cost_source":"loja","idempotency_key":"..."}` |
| POST | `kz/os/:id/fotos` | `{"kind":"entrada","storage_ref":"...","note":"...","idempotency_key":"..."}` |
| POST | `kz/os/:id/senha` | `{"device_password":"...","expected_version":1,"idempotency_key":"..."}` |

## kz-usados (flag `usados`)

| Metodo | Rota | Corpo |
|---|---|---|
| GET | `kz/usados/referencia?model=&storage=&ativos=true` | - |
| POST | `kz/usados/referencia` | `{"model_label":"...","storage_label":"128GB","grade":"A","min_value_cents":150000,"max_value_cents":190000,"idempotency_key":"..."}` |
| POST | `kz/usados/referencia/:id/arquivar` | `{"expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/usados/avaliacao` | `{"device_brand":"...","device_model":"...","imei":"15 digitos opcional","grade":"A","checklist":[{"label":"Liga","ok":true}],"suggested_value_cents":175000,"idempotency_key":"..."}` |
| GET | `kz/usados?status=avaliada&dias=30` | - |
| GET | `kz/usados/:id` | - |
| POST | `kz/usados/:id/aprovar` | `{"expected_version":1,"unit_ref":"IMEI-... (obrigatorio)","decision_note":"...","idempotency_key":"..."}` |
| POST | `kz/usados/:id/recusar` | `{"expected_version":1,"decision_note":"...","idempotency_key":"..."}` |
| GET | `kz/usados/:id/termo` | - (gera o rascunho na primeira leitura) |
| POST | `kz/usados/:id/termo/aceitar` | `{"expected_version":1,"idempotency_key":"..."}` |

## kz-pagamento-misto (flag `pagamento-misto`)

| Metodo | Rota | Corpo |
|---|---|---|
| POST | `kz/pagamentos/:pedido/dividir` | `{"order_kind":"order","order_total_cents":250000,"change_cents":5000,"payments":[{"method":"dinheiro","amount_cents":100000},{"method":"credito","amount_cents":55000,"installments":3}],"idempotency_key":"..."}` |
| GET | `kz/pagamentos/:pedido?kind=order` | - |

Metodos aceitos: dinheiro, pix, debito, credito, crediario, vale_troca, outro
(o mesmo identificador do SQL e do zod; `installments` so em credito/crediario).

## kz-crediario (flag `crediario`)

| Metodo | Rota | Corpo |
|---|---|---|
| POST | `kz/crediario` | `{"contact_id":"<uuid>","total_cents":100000,"installments_count":3,"first_due":"2026-12-10","order_kind":"order","order_id":"<uuid>","idempotency_key":"..."}` (`order_kind` e `order_id` sao opcionais, mas andam juntos: ambos ou nenhum; `first_due` aceita data retroativa - carne real) |
| POST | `kz/crediario/limite` | `{"contact_id":"<uuid>","limit_cents":300000,"expected_version":1,"idempotency_key":"..."}` |
| POST | `kz/crediario/parcela/:id/baixa` | `{"idempotency_key":"..."}` |
| POST | `kz/crediario/:id/cancelar` | `{"expected_version":1,"idempotency_key":"..."}` |
| GET | `kz/crediario?status=ativo&atrasadas=true` | - |
| GET | `kz/crediario/cliente/:id` | - |
| GET | `kz/crediario/:id` | - |

## kz-seguranca (flag `seguranca`)

| Metodo | Rota | Corpo |
|---|---|---|
| POST | `kz/seguranca/pin` | `{"pin":"4321","current_pin":"... so na rotacao","idempotency_key":"..."}` |
| POST | `kz/seguranca/confirmar` | `{"pin":"...","purpose":"estorno","ttl_seconds":300,"idempotency_key":"..."}` |
| GET | `kz/seguranca/grants` | - |
| GET | `kz/seguranca/historico?dias=30` | - |
| POST | `kz/seguranca/grants/:id/consumir` | `{"purpose":"estorno","idempotency_key":"..."}` |

## Resumo para o proxy

Padrao unico a repassar: tudo que comecear com `kz/` (GET e POST), preservando
cabecalho de autenticacao e metodo. Total: 50 rotas (5 do plano de controle,
7 do caixa, 4 de taxas, 10 de OS, 10 de usados, 2 de pagamento misto, 7 de
crediario e 5 de seguranca).
