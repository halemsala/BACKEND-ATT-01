# Mapa da Fase 0 — inventário e decisões (Lote 1)

Data: 16/11/2026 (horário de Brasília, UTC-3). Base: commit 56f3aca. Fonte: Kazzus-prompt-backend-outra-IA.md (contrato) + decisões desta entrega.

## 1. Resumo executivo

Este mapa cobre as 30 entregas P1 definidas no contrato: as 15 funções da Fase 1 e as 15 automações da Fase 2. Para cada item: o que já existe (seção 2.10 do contrato), a decisão — REAPROVEITAR, ESTENDER com tabela nova ligada por chave ou CRIAR —, as tabelas `crm.` propostas, os endpoints `kz/...` e os eventos `kz.*`.

O Lote 1 entrega 8 dos 15 itens da Fase 1, em 7 módulos de domínio, porque os itens 5 e 6 (avaliação de usado e tabela de referência) formam um único módulo, o kz-usados. Estão entregues e testados: kz-caixa (migração 095, item 1), kz-pagamento-misto (099, item 2), kz-taxas (096, item 3), kz-os (097, item 4), kz-usados (098, itens 5 e 6), kz-crediario (100, item 8) e kz-seguranca (101, item 14). Acompanha a infraestrutura comum kz da migração 094 (flags, settings, contadores, recibos de idempotência, outbox kz, trilha de auditoria kz). Os itens 7, 9, 10, 11, 12, 13 e 15 ficam para o Lote 2, e todas as automações da Fase 2 ficam para o Lote 3. Motivo comum aos itens pendentes: dependem do schema real de tabelas existentes ou da assinatura real de serviços existentes (quotes, finance_entries, backup.ts), e o contrato manda parar e perguntar em vez de inventar.

Princípio geral aplicado em todo o mapa: nunca duplicar o que existe. Onde a seção 2.10 aponta serviço ou tabela que já cobre parte da função, a decisão é REAPROVEITAR chamando o fluxo existente, ou ESTENDER com tabela nova ligada por chave — nunca reescrever o módulo antigo. Integração com tabela existente só ocorre depois de confirmado o schema real (regra "não invente"). Enquanto isso, os vínculos com orders, quotes, contacts e inventory_units são lógicos: colunas de referência, sem chave estrangeira física.

## 2. Decisões da Fase 1 (as 15 funções P1)

| # | Função | O que já existe (arquivo/tabela, ref. seção 2.10) | Decisão | Tabelas novas (crm.) | Endpoints (kz/...) | Eventos | Situação no Lote 1 |
|---|---|---|---|---|---|---|---|
| 1 | Caixa do dia (abertura, sangria, reforço, fechamento, conferência cega) | Já existe financeiro (finance.ts, finance_opening, finance_entries), mas sem sessão de caixa por dia com sangria, reforço e conferência | CRIAR (integração opcional com finance_entries no Lote 2) | kz_cash_sessions, kz_cash_movements | GET kz/caixa/hoje, POST kz/caixa/abrir, POST kz/caixa/sangria, POST kz/caixa/reforco, POST kz/caixa/fechar (+GET kz/caixa/historico, GET kz/caixa/:id) | kz.caixa.aberto, kz.caixa.movimento, kz.caixa.fechado, kz.caixa.diferenca | ENTREGUE (095) |
| 2 | Pagamento misto (várias formas e troco) | Pedidos e cotações existem (commerce.ts) | CRIAR com referência lógica ao pedido + adaptador injetável de total do pedido (validação contra o total real fica para o Lote 2, ao confirmar o schema de orders) | kz_payment_sets, kz_payment_splits | POST kz/pagamentos/:pedido/dividir, GET kz/pagamentos/:pedido | kz.pagamento.dividido | ENTREGUE (099) |
| 3 | Simulador de taxas da maquininha e lucro real | Nada equivalente encontrado | CRIAR | kz_card_fee_tables | GET kz/taxas, POST kz/taxas, POST kz/taxas/simular, POST kz/taxas/:id/arquivar | kz.taxas.alteradas | ENTREGUE (096) |
| 4 | OS de serviço com checklist, fotos, senha cifrada, peças | inspections e intake_forms cobrem inspeção de entrada, não OS de reparo | CRIAR | kz_service_orders, kz_service_order_checklists, kz_service_order_parts, kz_service_order_photos | POST kz/os, GET kz/os, GET kz/os/:id, POST kz/os/:id/status, POST kz/os/:id/diagnostico, POST kz/os/:id/checklist, POST kz/os/:id/checklist/:itemId/marcar, POST kz/os/:id/pecas, POST kz/os/:id/fotos, POST kz/os/:id/senha | kz.os.criada, kz.os.status, kz.os.pronta (+ eventos auxiliares kz.os.*) | ENTREGUE (097) |
| 5 | Usado: avaliação, termo, entrada como unidade | inspections pode servir de referência, mas não cobre avaliação de trade-in com termo | CRIAR (a entrada como unidade serial "used" no estoque usa o fluxo existente; o módulo registra o vínculo via unit_ref e emite evento) | kz_tradein_evaluations, kz_tradein_terms | POST kz/usados/avaliacao, POST kz/usados/:id/aprovar, POST kz/usados/:id/recusar, GET kz/usados/:id, GET kz/usados/:id/termo, POST kz/usados/:id/termo/aceitar, GET kz/usados | kz.usado.avaliado, kz.usado.aprovado | ENTREGUE (098) |
| 6 | Tabela de referência de usados | Nada equivalente | CRIAR (mesmo módulo do item 5) | kz_tradein_reference | GET/POST kz/usados/referencia, POST kz/usados/referencia/:id/arquivar | kz.usado.referencia_alterada | ENTREGUE (098) |
| 7 | Orçamento → venda | Já existe: quotes, quote_items (commerce.ts) | REAPROVEITAR — a conversão deve chamar o fluxo existente | (nenhuma; kz_quote_meta só se faltar algo) | POST kz/orcamentos/:id/converter | kz.orcamento.convertido | LOTE 2 — precisa da assinatura real do serviço de quotes para chamar sem inventar |
| 8 | Crediário (carnê, parcelas, limite) | Nada equivalente | CRIAR | kz_credit_plans, kz_credit_installments, kz_credit_limits | POST kz/crediario, POST kz/crediario/limite, POST kz/crediario/parcela/:id/baixa, POST kz/crediario/:id/cancelar, GET kz/crediario/cliente/:id, GET kz/crediario/:id, GET kz/crediario | kz.crediario.criado, kz.parcela.vence_amanha, kz.parcela.atrasada, kz.parcela.paga (+ kz.crediario.quitado, kz.crediario.cancelado) | ENTREGUE (100), com job de varredura diária preparado (registro só na Fase 2, atrás de KAZZUS_KZ_AUTOMATIONS) |
| 9 | Financeiro: contas a pagar/receber e fluxo de 4 semanas | finance_entries já existe (finance.ts) | ESTENDER — reutilizar finance_entries e acrescentar recorrentes + previsão | kz_recurring_bills, kz_cashflow_forecasts | GET kz/financeiro/fluxo?semanas=4, POST kz/financeiro/conta | kz.conta.vence, kz.fluxo.alerta | LOTE 2 — o fluxo completo precisa do schema real de finance_entries |
| 10 | Vale-troca | returns-refunds.ts, return_cases e refund_requests já existem | ESTENDER — reaproveitar devoluções e criar vale | kz_store_credits | POST kz/vale-troca, POST kz/vale-troca/:id/usar, GET kz/vale-troca/cliente/:id | kz.vale.criado, kz.vale.usado | LOTE 2 — integra com o fluxo de devolução existente |
| 11 | Custos (custo médio, aquisição com frete e taxas) | variant_costs já existe | ESTENDER | kz_landed_costs | POST kz/custos/entrada, GET kz/custos/:variante | kz.custo.atualizado | LOTE 2 |
| 12 | Curva ABC e produto parado (só leitura) | Consultas sobre dados de vendas | CRIAR consultas (sem escrita; opcional kz_report_snapshots) | (nenhuma obrigatória) | GET kz/analise/abc, GET kz/analise/parados | nenhum | LOTE 2 — precisa do schema real das tabelas de venda |
| 13 | Estoque disponível (reservas) | inventory_reservations e inventory_balances já existem | REAPROVEITAR (leitura agregada) | (nenhuma) | GET kz/estoque/disponivel | nenhum | LOTE 2 — schema real |
| 14 | PIN para ação sensível e visão do log | Nada equivalente (authorization.ts é holdout) | CRIAR como camada própria kz-seguranca, sem tocar em authorization.ts | kz_stepup_pins, kz_stepup_grants, kz_stepup_attempts | POST kz/seguranca/pin, POST kz/seguranca/confirmar, GET kz/seguranca/grants, GET kz/seguranca/historico, POST kz/seguranca/grants/:id/consumir | kz.seguranca.confirmado (sem o PIN no payload) | ENTREGUE (101) |
| 15 | Teste de restauração de backup | backup.ts já tem createBackup, verifyBackup e restoreBackup | REAPROVEITAR | kz_backup_checks | POST kz/backup/testar, GET kz/backup/status | kz.backup.ok, kz.backup.falhou | LOTE 2 — precisa da assinatura real de backup.ts |

## 3. Decisões da Fase 2 (as 15 automações P1)

Nenhuma automação foi implementada no Lote 1; a tabela antecipa onde cada uma vai morar e em que base. O Lote 1 já deixa pronto para elas: eventos kz.* gravados em crm.kz_outbox_events com dedupe, trilha kz com verificação e validação Luhn de IMEI no kz-usados.

| # | Automação | Onde mora | Base para a decisão | Situação |
|---|---|---|---|---|
| 1 | Motor de regras se→então (kill switch, dry-run, desfazer) | kz-regras (novo) | Lê o outbox (oficial + kz) e executa só ações internas permitidas | LOTE 3. No Lote 1 os eventos kz.* já são gravados em crm.kz_outbox_events com dedupe |
| 2 | Fila de aprovação | Reaproveitar AiProposals (agent_proposals) | Agregar propostas + rascunhos | LOTE 3 |
| 3 | Pedido pago → separar | Regra pronta no kz-regras | Consome payment.* / pedido pago | LOTE 3 |
| 4 | Venda de celular → garantia + pós-venda | Regra pronta + serviços existentes (warranties.ts, message_drafts) | — | LOTE 3 |
| 5 | Previsão de ruptura + ponto de pedido | kz-previsao + stock-replenishment.ts existente | kz_stock_forecasts | LOTE 3 |
| 6 | Calendário sazonal da Paraíba | kz-previsao | kz_calendar_events — nenhuma data fixa sem confirmação do Anderson | LOTE 3 |
| 7 | Agente Auditor diário | kz-auditor | kz_audit_reports; usa verifyAuditChain existente + trilha kz | LOTE 3 |
| 8 | IMEI duplicado/inválido | kz-deteccao | No Lote 1 a validação Luhn de IMEI já entra em kz-usados (avaliação); a checagem de duplicidade no estoque depende do schema de inventory_units | LOTE 3 |
| 9 | Comprovante de Pix repetido | kz-deteccao | kz_pix_receipts (hash da imagem) | LOTE 3 |
| 10 | Anomalia no fechamento de caixa | kz-deteccao | Consome kz.caixa.fechado, já emitido no Lote 1 | LOTE 3 |
| 11 | Margem negativa / preço diferente (só alerta) | kz-deteccao | Leitura; nunca corrige preço (R1) | LOTE 3 |
| 12 | Acessório certo por modelo | kz-recomendacao | kz_basket_pairs recalculado por job | LOTE 3 |
| 13 | Lista do dia para contatar | kz-recomendacao | kz_daily_contacts → rascunhos em message_drafts (já existe) | LOTE 3 |
| 14 | Briefing da manhã + "Explique este número" | kz-copiloto | kz_briefings; LLM só local via ModelRuntime (LM Studio 127.0.0.1) | LOTE 3 |
| 15 | Memória do cliente/loja + feedback + LGPD | kz-memoria | kz_customer_memory, kz_store_rules, kz_suggestion_feedback | LOTE 3 |

## 4. Infraestrutura comum entregue no Lote 1 (migração 094)

A migração 094 cria a base comum de todos os módulos kz, no padrão do contrato: tabelas no esquema `crm`, colunas comuns (`workspace_id`, `id`, `version`, `created_by`, `created_at`/`updated_at`, `archived_at`), `ENABLE`/`FORCE ROW LEVEL SECURITY`, policy `workspace_scope` e `GRANT` sem `DELETE`. As migrações dos módulos (095 a 101) seguem o mesmo molde e só acrescentam as colunas do domínio. O acesso a flags, settings, contadores, recibos, eventos e auditoria fica concentrado no kz-common: trocar essas estruturas pelas oficiais mais tarde é mudança em um lugar só, não em sete módulos.

- `crm.kz_feature_flags`: flag por loja (`workspace_id`, `module`, `enabled`). Um módulo só responde quando a variável de processo `KAZZUS_KZ_<MODULO>` tem o valor exato "YES" e a linha da loja está habilitada; com a flag desligada, as rotas respondem `MODULE_DISABLED` 404 e os jobs não rodam.
- `crm.kz_settings`: chave/valor por loja para os módulos kz (ex.: nome da loja que sai no termo de usado).
- `crm.kz_counters`: numeração legível por loja, com prefixos OS- (ordem de serviço), CR- (crediário) e AT- (avaliação de usado). Desvio intencional do molde (sem version/created_by/archived_at): contador interno de numeração atômica (INSERT ... ON CONFLICT DO UPDATE), sem ator humano por incremento (Revisao 2).
- `crm.kz_command_receipts`: idempotência por `idempotency_key`; repetir a mesma chave devolve o mesmo resultado e, com outro input, o hash do payload detecta o conflito (`IDEMPOTENCY_CONFLICT`).
- `crm.kz_outbox_events`: eventos `kz.*` com dedupe por `dedupe_key`, no mesmo espírito do outbox oficial.
- `crm.kz_audit_events`: trilha append-only com hash encadeado e verificação, no mesmo espírito das migrações 086, 087 e 089.

Os módulos gravam em tabelas kz_* próprias, em vez das oficiais (outbox, recibos de comando, trilha de auditoria), porque os schemas reais dessas estruturas não foram enviados com o contrato. Espelhar para as oficiais depois, se o Anderson decidir, é um ponto único em kz-common (ver dúvida D2).

## 5. Decisões arquitetônicas do Lote 1 (resumo)

- Padrão de escrita obrigatório (seção 2.4) seguido em todo endpoint de escrita: `uuid.parse` do id → `requireHumano` → zod `strict()` com `idempotency_key` (e `expected_version` quando o registro já existe) → `db.workspace` com RLS → `command()` com recibo → `SELECT ... FOR UPDATE` com `version=version+1` → `event()` → auditoria.
- Erros como `DomainError` em CAIXAS com status 409 (padrão), 404, 403, 422 e 503. Flag desligada responde `MODULE_DISABLED` 404. Tabela ausente responde `<MODULO>_MIGRATION_REQUIRED` 503, conferido com `to_regclass('crm.<tabela>')`.
- Escrita kz só para `operator`/`admin`. `authorization.ts` é holdout e não foi tocado; abrir escrita para vendedor é a dúvida D7.
- R1 guardada: nenhum módulo grava preço, desconto, cupom ou qualquer valor comercial. A simulação de taxas e a faixa de referência de usados são somente leitura/sugestão; quem aplica é o Anderson pelo fluxo que já existe.
- Criptografia AES-256-GCM (`node:crypto`) para a senha do aparelho na OS, com chave via `KAZZUS_KZ_DATA_KEY`; PIN guardado com hash scrypt. Segredos nunca vão para log nem para a auditoria.
- Nenhum envio externo, nada fiscal, nada de IA em nuvem, nenhuma dependência nova. Todo módulo novo fica atrás de flag desligada por padrão.

## 6. Dúvidas consolidadas para o Anderson

- D1 — Caminhos reais de import de `DomainError` e `Database`. O contrato mostra o uso (seções 2.4 e 2.5), mas não o caminho exato dos arquivos. O Lote 1 usa cópias fiéis dos helpers em kz-common/kz-env; trocar pelas originais é uma linha por helper.
- D2 — Schemas reais de `crm.outbox_events`, dos recibos de comando e da trilha de auditoria. Por causa dessa lacuna, a infra kz criou `kz_outbox_events`, `kz_command_receipts` e `kz_audit_events` próprias. Espelhamos para as oficiais, ou mantemos as kz?
- D3 — Receita de hash da trilha oficial (migrações 086, 087 e 089). A trilha kz é própria e encadeada, e não mistura com a oficial. Confirmar a receita antes de unificar.
- D4 — Schemas de `orders`, `quotes`, `contacts` e `inventory_units`. Enquanto não confirmados, os vínculos são lógicos (colunas de referência, sem FK física). O kz-pagamento-misto já tem adaptador injetável de total do pedido, pronto para o Lote 2.
- D5 — Assinaturas reais de `backup.ts` (item 15) e do serviço de estoque (entrada do usado como unidade serial "used"). São necessárias para chamar sem inventar.
- D6 — A migração 094 está livre? O contrato avisa que outra sessão pode ter criado uma 094; conferir `.local/` e `migrations/historico` antes de aplicar.
- D7 — Escrita kz para vendedor. Hoje só `operator`/`admin` escrevem, porque `authorization.ts` está congelado (holdout). É a dúvida 2 do contrato: liberar vendedor exige editar esse arquivo.
- D8 — Porta da API de teste. Mesma dúvida 4 do contrato: sugestão 3200 para a API e 3201 para o V21. Confirmar.
- D9 — `kz/flags` e `kz/settings` como plano de controle sem flag própria. Sem isso é impossível ligar qualquer módulo por loja, porque a flag da loja mora na própria tabela. Confirmar.
- D10 — LGPD do termo de usado. O termo carrega IMEI e dados do cliente; definir retenção e descarte (o "apagar" volta na Fase 2, no kz-memoria).
- D11 — Contagem de testes: 474 (sua fala) vs 524 arquivos encontrados. É a dúvida 1 do contrato; vale rodar `npm test` na cópia isolada.
- D12 — Datas do calendário da Paraíba só com sua confirmação (dúvida 6 do contrato). Nenhuma data fixa entra sem OK.
- D13 — Uso de IA em nuvem para gerar este código (dúvida 5 do contrato). Este mapa foi produzido lendo apenas o contrato, sem enviar código do Kazzus para fora.
- D14 — Criptografia em repouso de IMEI e do termo de usado (LGPD). Hoje o IMEI fica em texto na avaliação (nunca vai para evento, auditoria ou log) e o termo é um documento que precisa ser exibido/impresso. Cifrar ambos com `KAZZUS_KZ_DATA_KEY` é possível; ligada à D10 (retenção). Decisão do Anderson (Revisão 2, achados 16/17).
- D15 — Cursor do consumidor do outbox kz. O outbox não tem `processed_at` por design: o consumidor da Fase 2 (kz-regras) guarda a própria posição em `kz_rule_cursors`, permitindo vários consumidores independentes sem marcação compartilhada. Confirmar na Fase 2 (Revisão 2, achado 4).

## 7. Riscos e mitigações

| Risco | Mitigação |
|---|---|
| RLS mal aplicada vaza dados entre lojas | Policy `workspace_scope` provada com papel `crm_app` no validador e isolamento com DEMO_A e DEMO_B |
| Retentativa duplica escrita (duplo clique, retry) | Recibos de idempotência com hash do payload; mesma chave devolve o mesmo resultado |
| Vazamento de segredo (senha do aparelho, PIN) | AES-256-GCM e scrypt, redação automática de payloads; nada de segredo em código, teste ou log |
| Conflito de rota com o backend existente | Prefixo `kz/` em tudo, checado estaticamente nas rotas declaradas dos módulos kz (conferência contra as rotas reais ao aplicar o patch) |
| Migração aplicada errada na base viva | Aplicação manual, com API parada, backup com SHA-256 e flag desligada |
| Regressão em arquivo existente | Nenhum arquivo existente editado; só o patch separado com as linhas de ligação (seção 2.11); holdouts com hash conferido |
| Módulo ligado sem querer | Flag desligada por padrão; liga só com "YES" exato no processo e linha habilitada na loja |
| Ação automática indevida na Fase 2 | Lista fechada de ações internas, `dedupe_key`, dry-run e kill switch `KAZZUS_KZ_AUTOMATIONS` |
